# ptc-swal

###`import { PtcSwalModule } from 'ptc-swal'`

###`npm install ptc-swal@latest`


## 描述


**用途** 錯誤及警告 的提示訊息

**整合內容** SweetAlert2

**參考文獻** 
> [SweetAlert2](https://sweetalert2.github.io/#handling-dismissals) SweetAlert官網



## 屬性

| 屬性定義           | 名稱 | 型態 | 預設值 | 描述
|--------------|:-----:|:-----:| :-------:|------------------------
| @Input()   | options | PtcSwalOption | null | SweetAlert的設定參數
| @Output()   | onConfirm | EventEmitter<any> |  | 確認回呼事件
| @Output()   | onCancel | EventEmitter<any> |  | 取消回呼事件



## 方法

**show(isloop?)** 
>顯示SweetAlert

| 名稱 | 型態 | 預設值 | 描述 |
|:-----:|:-----:|:-----:|-------|
| isloop | boolean | false | 是否為連續動作

**close()** 
>關閉SweetAlert




## 物件

### GlobalSubject ###

> 取得全域的Subject

| 屬性定義   | 名稱 | 型態 | 預設值 | 描述
|-----------|:-----:|:-----:| :-------:|------------------------
| static   | globalOnCancel | Subject<any> |  | 訂閱所有SweetAlert的取消事件


## type

### PtcSwalOption ###

> SweetAlert的設定參數


### PtcSweetAlertResult ###

> SweetAlert的回傳物件

| 名稱 | 型態 | 預設值 | 描述
|:-----:|:-----:| :-------:|------------------------
| value | any | undefined | 回傳的值
| dismiss | PtcDismissReason| undefined | 關閉視窗的狀態


## enum

### PtcDismissReason ###

> SweetAlert的關閉視窗狀態

| 名稱 | 預設值 | 描述
|:-----:|:-----:| :-------:|------------------------
| cancel | "cancel" | 取消按鈕
| backdrop | "backdrop" | 點擊背景
| close | "close" | 點擊 X 按鈕
| esc | "esc" | 鍵盤 ESC 按鍵
| timer | "timer" | 時間到關閉



## Operators

### function swalOperator<T>(someCallback: (val: T) => PtcSwalOption)  ###

> SweetAlert的Operator(用於連續訊息)

| 名稱 | 型態 | 描述
|:-----:|:-----:| :-------:|------------------------
| someCallback | (val: T) => PtcSwalOption | val是上一個Operator的回傳值, 必須回傳PtcSwalOptio物件




## 使用方式（範例）


> app.module.ts

```javascript
import { PtcSwalModule } from 'ptc-swal';

@NgModule({
  declarations: [
    AppComponent,
  ],
  
  imports: [  
	 ...
    PtcSwalModule //add this line.
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }


```


> app.component.ts

```javascript


import { PtcSwalComponent, PtcSwalOption, PtcSwalType } from 'ptc-swal';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
    
  /**
   * 取得 sweetAlert 實體
   */
  @ViewChild("Swal1") Swal1: PtcSwalComponent;

  
  /**
   *  SweetAlert 設定
   */
  swalOpt1: PtcSwalOption = {
    title: "sweetAlert",
    text: "測試sweetAlert",
    type: PtcSwalType.success,
    showCancelButton: true
  }

  
  constructor(){}

  /**
   * 顯示 SweetAlert
   */
  showSwal1(){
    this.Swal1.show();
  }

  /**
   * 監聽  SweetAlert Confirm 事件
   */
  swal1Confirm(data){
    console.log("你確認訊息視窗");
  }

  /**
   * 監聽  SweetAlert Cancel 事件
   */
  swal1Cancel(){
    console.log("你取消訊息視窗");
  }

  ...

}


```

> app.component.html


```html

<button (click)="showSwal1()" >彈出SweetAlert</button>

<ptc-swal #Swal1 [options]="swalOpt1" (onConfirm)="swal1Confirm($event)" (onCancel)="swal1Cancel()"></ptc-swal>  

```  