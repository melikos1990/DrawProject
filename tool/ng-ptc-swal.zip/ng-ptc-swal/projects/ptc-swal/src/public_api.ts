/*
 * Public API Surface of ptc-swal
 */

export * from './lib/ptc-swal.service';
export * from './lib/ptc-swal.component';
export * from './lib/ptc-swal.module';
export { PtcDismissReason, PtcSwalType } from './lib/enum';
