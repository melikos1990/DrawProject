


export enum PtcSwalType{
    error = 'error',
    success = 'success',
    warning = 'warning',
    info = 'info',
    question = 'question',
}


