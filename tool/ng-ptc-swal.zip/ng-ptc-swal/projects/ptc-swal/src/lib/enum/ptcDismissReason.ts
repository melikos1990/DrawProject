

export enum PtcDismissReason { 
    cancel = "cancel", 
    backdrop = "backdrop", 
    close  = "close", 
    esc  = "esc", 
    timer  = "timer"
}