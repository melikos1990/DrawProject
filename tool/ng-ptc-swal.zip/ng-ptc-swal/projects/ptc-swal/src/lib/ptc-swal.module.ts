import { NgModule } from '@angular/core';
import { PtcSwalComponent } from './ptc-swal.component';

@NgModule({
  imports: [
  ],
  declarations: [PtcSwalComponent],
  exports: [PtcSwalComponent]
})
export class PtcSwalModule { }
