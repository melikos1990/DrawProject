import { Injectable } from '@angular/core';


import Swal, { SweetAlertOptions, SweetAlertResult } from 'sweetalert2';


@Injectable({
  providedIn: 'root'
})
export class PtcSwalService {

  private nativeSwal = Swal;

  constructor() { }

  showSwal(option: SweetAlertOptions): Promise<SweetAlertResult>{
    return this.nativeSwal.fire(option);
  }

  closeSwal(){
    this.nativeSwal.close();
  }

}
