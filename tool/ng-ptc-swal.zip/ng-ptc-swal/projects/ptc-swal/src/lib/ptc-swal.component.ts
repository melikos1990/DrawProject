import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

import Swal, { SweetAlertOptions, SweetAlertResult } from 'sweetalert2';

import { PtcSwalService } from './ptc-swal.service';
import { Subject, Observable, from, of, empty } from 'rxjs';
import { catchError, switchMap, filter } from 'rxjs/operators';

import { PtcDismissReason } from './enum/ptcDismissReason';

export type PtcSwalOption = {
  [P in keyof SweetAlertOptions]: SweetAlertOptions[P]
};

export type PtcSweetAlertResult = {
  value?: any;
  dismiss?: PtcDismissReason;
};

export class GlobalSubject{
  
  // static globalOnConfirm: Subject<any> = new Subject<any>();
  
  static globalOnCancel: Subject<any> = new Subject<any>();

}

export function swalOperator<T>(someCallback: (val: T) => PtcSwalOption) { 

  // notice that we return a function here
  return function swalOperatorImplementation(source): Observable<any> {

    return source.pipe(switchMap( (x: any) => {

      let option = someCallback(x);

      return from(Swal.fire(option))
            .pipe(
              filter(x => {
                let hasCancel = isCancel(x);
                return hasCancel == false;
              })
            );

    }))
  }

}


function isCancel(swalVal: SweetAlertResult) {
  let hasCancel = false;
  if(swalVal.dismiss != undefined && 
  (
    swalVal.dismiss === Swal.DismissReason.cancel || 
    swalVal.dismiss === Swal.DismissReason.esc ||
    swalVal.dismiss === Swal.DismissReason.backdrop 
  )){
    GlobalSubject.globalOnCancel.next(swalVal);
    hasCancel = true;
  };

  return hasCancel;
}

@Component({
  selector: 'ptc-swal',
  templateUrl: './ptc-swal.component.html',
  exportAs: 'ptcSwal',
  styles: []
  //inputs: ['options']
})
export class PtcSwalComponent implements OnInit {

  /* #region  Inputs */

  get options() { return this._options; }

  @Input()
  set options(val: SweetAlertOptions) {
    this._options = val;
    //this._options = this.setParams(val);
  }

  @Input()
  test: SweetAlertOptions = null;

  /* #endregion */


  /* #region  Outputs */

  @Output()
  onConfirm: EventEmitter<any> = new EventEmitter();

  
  @Output()
  onCancel: EventEmitter<any> = new EventEmitter();

  /* #endregion */


  _onConfirm: Subject<any> = new Subject<any>();
  _onCancel: Subject<any> = new Subject<any>();


  private _options: SweetAlertOptions = null;

  
  private readonly _limitOptionProps = new Set<keyof SweetAlertOptions>();



  constructor(
    private swalService: PtcSwalService
  ) { }



  ngOnInit() {
    console.log("ptc-swal Init");
    //this.initParamsLimt();
  }

  /**
   * 顯示SweetAlert
   * @param isloop 是否連續顯示SwalAlert
   */
  show(isloop: boolean = false, confirm?: (res) => void, cancel?: () => void): Observable<SweetAlertResult> {
    

    if(this._options == null){
      throw new Error("option 不能為空值");
    }

    if(!isloop){
      from(this.swalService.showSwal(this._options))
            .subscribe(swalVal => {
              let hasCancel = isCancel(swalVal);
              if(hasCancel){
                if(cancel) cancel();
                this.cancelHandler();
              }
              else{
                if(confirm) confirm(swalVal);
                this.confirmHandler(swalVal);
              }

            })
      return empty();
    }
    else{
      return from(this.swalService.showSwal(this._options))
              .pipe(
                filter(x => {
                  let hasCancel = isCancel(x);
                  return hasCancel == false;
                }),
                catchError(err => { return of({error: err, value: ""} as SweetAlertResult) })
              )
    }
    
    

  }

  close(){
    this.swalService.closeSwal();    
  }


  private confirmHandler(swalVal: any){

    if(this.onConfirm)
      this.onConfirm.emit(swalVal);
    this._onConfirm.next(swalVal);

  }

  private cancelHandler(){

    if(this.onCancel)
      this.onCancel.emit();
    this._onCancel.next();

  }


  private setParams(options: SweetAlertOptions): SweetAlertOptions {

    let newOptions: SweetAlertOptions = {};

    for (var optionName in options) {

      if (newOptions.hasOwnProperty(optionName)) {
        newOptions[optionName] = options[optionName];
      }
    }

    return newOptions;

  }

  private initParamsLimt() {

    let options: SweetAlertOptions = {} as SweetAlertOptions;
    Object.assign({} as SweetAlertOptions, options);
    let addFun = this._limitOptionProps.add.bind({});

    Object.keys(options).forEach(prop => {
      addFun(prop);
    })

  }

}
