import { TestBed, inject } from '@angular/core/testing';

import { PtcSwalService } from './ptc-swal.service';

describe('PtcSwalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PtcSwalService]
    });
  });

  it('should be created', inject([PtcSwalService], (service: PtcSwalService) => {
    expect(service).toBeTruthy();
  }));
});
