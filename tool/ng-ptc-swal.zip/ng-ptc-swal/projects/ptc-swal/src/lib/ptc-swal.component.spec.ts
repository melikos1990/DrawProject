import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcSwalComponent } from './ptc-swal.component';

describe('PtcSwalComponent', () => {
  let component: PtcSwalComponent;
  let fixture: ComponentFixture<PtcSwalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcSwalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcSwalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
