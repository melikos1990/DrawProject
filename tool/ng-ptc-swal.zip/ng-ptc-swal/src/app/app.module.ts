import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

import { PtcSwalModule } from 'ptc-swal';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    PtcSwalModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
