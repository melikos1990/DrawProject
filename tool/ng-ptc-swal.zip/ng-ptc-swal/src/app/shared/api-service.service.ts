import { Injectable } from '@angular/core';

import { of } from 'rxjs'; 
import { delay, tap, map } from 'rxjs/operators'; 

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor() { }

  Get(url: string, data: string){
    
    return of({isSuc: true, data: [1,2,3]}).pipe(delay(3000), map(x => JSON.stringify(x.data)));

  }  

}
