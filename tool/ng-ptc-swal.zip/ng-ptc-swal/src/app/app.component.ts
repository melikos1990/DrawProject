import { Component, ViewChild, OnInit, AfterViewInit, AfterViewChecked, AfterContentChecked } from '@angular/core';

import { ApiService } from './shared/api-service.service';

import { PtcSwalComponent, PtcSwalOption, PtcSwalType, 
  swalOperator, PtcSweetAlertResult, GlobalSubject, PtcDismissReason, PtcSwalService } from 'ptc-swal';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ApiService]
})
export class AppComponent implements OnInit {

  testMode: string = 'general';
  
  title = 'ptcSwalExam';

  inputVal: string;

  isloading: boolean = false;

  /**
   * 取得所有 sweetAlert 實體
   */
  @ViewChild("Swal1") Swal1: PtcSwalComponent;
  @ViewChild("Swal") Swal: PtcSwalComponent;
  // @ViewChild("Swal3") Swal3: PtcSwalComponent;
  @ViewChild("cancelSwal") cancelSwal: PtcSwalComponent;


  /**
   * 第一個 SweetAlert 設定
   */
  swalOpt1: PtcSwalOption = {
    title: "sweetAlert",
    text: "測試sweetAlert",
    type: PtcSwalType.success,
    showCancelButton: true
  }


  /**
   * 第二個 SweetAlert 設定
   */
  swalOpt2: PtcSwalOption = {
    title: "實作 Swal ajax",
    text: "確定送出資料嗎?? 你輸入的資料為: ",
    type: PtcSwalType.question,
    showCancelButton: true,
    showLoaderOnConfirm: true,
    allowOutsideClick: false,
    preConfirm: (val) => {
      return this.ajaxSend(this.inputVal);
    }
  }


  /**
   * 第三個 SweetAlert 設定
   */
  swalOpt3: PtcSwalOption = {
    title: "連續詢問動作",
    text: "請輸入內容(請輸入: 123)",
    type: PtcSwalType.info,
    input: 'text',
    showCancelButton: true
  }

  /**
   * 第三個 SweetAlert 設定
   */
  cancelSwalOpt: PtcSwalOption = {
    title: "連續詢問動作",
    text: `你已取消目前動作`,
    type: PtcSwalType.info,
  }


  constructor(
    private api: ApiService,
    private swalService: PtcSwalService
  ){}


  ngOnInit(): void {

    // 監聽 SweetAlert的Cancel事件
    this.Swal1._onCancel.subscribe(() => console.log("cancel"));


    // 監聽 所有 連續詢問 SweetAlert的Cancel事件
    GlobalSubject.globalOnCancel.subscribe((x: any) => {

      if(x.dismiss != PtcDismissReason.cancel) return;

      console.log("globalOnCancel");

      this.cancelSwal.show();

    });


  }

  /**
   * show SweetAlert
   */
  showSwal(){
    //this.Swal1.show();

    switch (this.testMode) {
      case "general":
        this.generalSwal();
        break;
    
      case "ajax":
        this.ajaxSwal();
        break;

      case "continu":
        this.continuSwal();
        break;

      default:
        alert("錯誤");
        break;
    }


  }


  testService(){
    let opt: PtcSwalOption = {
      title: "測試",
      text: "測試sweetAlert",
      type: PtcSwalType.warning
    }
    this.swalService.showSwal(opt);


  }
  
    

  /**
   * 監聽 一般 SweetAlert Confirm 事件
   */
  swal1Confirm(data){
    console.log(data);
  }

  /**
   * 監聽 一般 SweetAlert Cancel 事件
   */
  swal1Cancel(){
    console.log("swal1Cancel");
  }


  /**
   * 一般 SweetAlert
   */
  generalSwal(){
    this.Swal1.show();
  }


  /**
   * ajax 行為
   */
  ajaxSwal(){
    
    this.Swal.options = {...this.swalOpt2};
    this.Swal.options.text = "確定送出資料嗎??";
    this.Swal.show(true)
      .pipe(
        swalOperator<PtcSweetAlertResult>(x => {
          console.log("ajax res data ", x);
          return {
            title: "取得成功",
            text: "回傳資料: " + x.value,
            type: PtcSwalType.success
          };
        })
      )
      .subscribe(x => x);
  }

  ajaxSend(val: string){
    console.log("data send => ", val);
    let url = "test";
    return this.api.Get(url, val).toPromise();
  }



  /**
   * 連續詢問
   */
  continuSwal(){
    this.Swal.options = {...this.swalOpt3};
    this.Swal.show(true).pipe(
      swalOperator<PtcSweetAlertResult>(x => {
        let opt = {};
        if(x.value != "123"){
          opt = {
            title: "連續詢問動作",
            text: `輸入錯誤!!!  你輸入的是: ${x.value}`,
            type: PtcSwalType.error,
          }
        }
        else{
          opt = {
            title: "連續詢問動作",
            text: `輸入正確!!!  你輸入的是: ${x.value}`,
            type: PtcSwalType.success,
          }
        }

        return opt;
      })
    ).subscribe(x => x);

  }


  

}
