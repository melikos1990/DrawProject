import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { Observable, fromEvent } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { INodes, ITreeOptions } from './treeview/Interfaces';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'treeview';

  @ViewChild('input') input: ElementRef;

  search$: Observable<any>;
  searchVal: string = null;

  nodes: INodes[] = [
    {
      name: 'root1',
      nodeAllowDrag: true,
      children: [
        { name: 'child1' },
        { name: 'child2' }
      ],
      //hasChildren: true,
      authItems: [
        {title: "新增", authType: 3},
        {title: "刪除", authType: 6},
        {title: "檢視", authType: 9}
      ],
    },
    {
      name: 'test2',
      nodeAllowDrag: true,
      children: [
        { name: 'childtyuiopoi6567890', children: [],authItems:[
          {title: "新增", authType: 3},
          {title: "刪除", authType: 6},
          {title: "檢視", authType: 9}
        ] },
        { name: 'child2.1', children: [] },
        { name: 'child2.2',  nodeAllowDrag: true,children: [
          {name: 'grandchild2.2.1'}
        ] }
      ]
    },
    { name: 'root3', nodeAllowDrag: false, isDisable: true },
    { name: 'root4', nodeAllowDrag: false, children: [] },
    { name: 'root5', nodeAllowDrag: true, children: null,
  
    authItems: [
      {title: "新增", authType: 3},
      {title: "刪除", authType: 6},
      {title: "檢視", authType: 9}
    ], }
  ];


  options: ITreeOptions = {
    allowDrag: false
  }


  constructor(){}

  ngOnInit(){
    this.search$ = fromEvent(this.input.nativeElement, 'keyup').pipe(
      debounceTime(300),
      distinctUntilChanged(),
      map((x: any) => x.target.value)
    );

    this.init();
  }


  init(){
    this.search$.subscribe(val => {
      console.log(val);
      this.searchVal = val;
    });
  }


  moveNode(ev){
    alert('moveNode');
  }

  copyNode(ev){
    alert("copyNode")
  }


  focus(ev){
    console.log("focus => ", ev);
    //alert("click node");
  }

}
