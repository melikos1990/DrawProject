
import { NgModule } from '@angular/core';
import { 
    MatButtonModule, 
    MatIconModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule
} from "@angular/material";

const material_modules = [
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule
]


@NgModule({
    
    imports: [
        ...material_modules
    ],

    exports: [
        ...material_modules
    ]

})
export class MaterialModule {
    
}

