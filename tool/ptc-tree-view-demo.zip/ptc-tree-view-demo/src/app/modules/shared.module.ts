
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MaterialModule } from './shared/material.module';
import { TreeviewComponent } from '../treeview/treeview.component';
import { TreeModule } from 'angular-tree-component';
import { FormsModule } from '@angular/forms';

@NgModule({
    declarations:[
        
    TreeviewComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        MaterialModule,
        TreeModule.forRoot()
    ],
    exports: [
        TreeviewComponent,
        MaterialModule,
        TreeModule
    ]

})
export class SharedModule {
    
}

