import { IAuthItem } from './auth.interface';



export interface INodes {

    id?: any;

    name: string;

    children?: INodes[];

    hasChildren?: boolean;

    authItems?: IAuthItem[];

    nodeAllowDrag?: boolean;

    isDisable?: boolean

}
