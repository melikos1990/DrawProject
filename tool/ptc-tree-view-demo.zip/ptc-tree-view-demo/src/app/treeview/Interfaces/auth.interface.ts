


export interface IAuthItem {

    title: string;

    authType: any;

    isEnable?: boolean;

}

