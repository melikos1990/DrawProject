import { 
    Component, OnInit, ViewChild, AfterViewInit, ContentChild, TemplateRef, 
    AfterContentInit, Output, Input,
    OnChanges, EventEmitter, SimpleChanges
  } from '@angular/core';

import { ITreeOptions, TreeComponent, TREE_ACTIONS, IActionMapping, TreeNode, TreeModel } from 'angular-tree-component';
import { INodes } from './Interfaces';
import { cloneNode } from './common/util';


const defaulNode: INodes = {
  name: '',
  nodeAllowDrag: false,
  children: null,
  authItems: null,
  isDisable: false
}


const actionMapping: IActionMapping = {
  mouse: {
    dblClick: (tree, node, $event) => {
      if(node.hasChildren) return TREE_ACTIONS.TOGGLE_EXPANDED(tree, node, $event)
    },
    drop: (tree:TreeModel, node:TreeNode, $event:any, {from, to}) => {
      // console.log("from =>", from);
      // console.log("to =>", to);
      // console.log("node =>", node);
      // console.log("$event =>", $event);
      
      let copyNode = cloneNode(from);
      from.data = copyNode;
      
      return TREE_ACTIONS.MOVE_NODE(tree, node, $event, {from, to});
    },
  }
}

const defaultOptions: ITreeOptions = {
  allowDrag: (node) => {
    return node.data.nodeAllowDrag;
  },
  actionMapping: actionMapping,
  nodeClass: (node: TreeNode) => {
    return node.hasChildren ? 'hasChilren' : '';
  }
}



@Component({
  selector: 'app-treeview',
  templateUrl: './treeview.component.html',
  styleUrls: ['./treeview.component.scss']
})
export class TreeviewComponent implements OnInit, OnChanges, AfterViewInit, AfterContentInit {


  _searchVal: string;


  @ViewChild('defaultTreeNodeTemplate') defaultTemplate: TemplateRef<any>;
  @ViewChild('loadingTemplate') loadingTemplate: TemplateRef<any>;
  

  @ContentChild('treeNodeTemplate') treeNodeTemplate: TemplateRef<any>;

  @Input() customerClass: any = 'text-tree';
  @Input() authItems: any[] = [];
  @Input() searchVal;
  @Input() options: ITreeOptions = defaultOptions;
  @Input() nodes: INodes[];

  @Output() onMoveNode: EventEmitter<any> = new EventEmitter();
  @Output() onCopyNode: EventEmitter<any> = new EventEmitter();
  @Output() onNodeActivate: EventEmitter<any> = new EventEmitter();


  @ViewChild(TreeComponent)
  tree: TreeComponent;


  constructor(
  ) { }


  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges){

    // 有搜尋條件時 進行查詢
    if(changes['searchVal'] && !changes['searchVal'].isFirstChange()){
      let searchVal = changes['searchVal'].currentValue;
        
      this._searchVal = searchVal;
      
      let curryFn = this.filterCurryFn(this._searchVal);
      
      this.filterNode(curryFn);
    }

  }

  ngAfterViewInit(): void {

    // 預先過濾不啟用的節點
    this.filterNode(node => !node.data.isDisable);

    // 全部關閉
    this.collapseAll();


  }

  ngAfterContentInit(): void {

    // 檢查是否有覆蓋基本樣式
    if(this.treeNodeTemplate){
      this.tree.treeNodeTemplate = this.treeNodeTemplate;
    }
    else{
      this.tree.treeNodeTemplate = this.defaultTemplate;
      this.tree.loadingTemplate = this.loadingTemplate;
    }

  }

  /**
   * 過濾特定節點
   */
  filterNode = (filter: (node) => boolean) => this.tree.treeModel.filterNodes(filter)


  /**
   * 刪除節點
   */
  delete(node, tree){
    console.log(node, tree);

    let parentNode = node.parent ? node.parent.data : tree.virtualRoot;

    let idx = parentNode.children.findIndex(x => x.id == node.data.id);

    parentNode.children.splice(idx, 1);

    this.treeUpdate();

  }


  /**
   * 儲存節點
   */
  saveNode(input,node){
    
    let val = input.value;

    if(!val) return;

    if(node.hasChildren == false){
      node.data.children = [];
    }

    let mergeVal = { ...defaulNode, ...{ name: val }};

    node.data.children.push(mergeVal);

    this.treeUpdate();

    node.data.adding = !node.data.adding;
    
  }


  
  moveNode = (event) => this.onMoveNode.emit(event);
  

  copyNode = (event) => this.onCopyNode.emit(event);

  focus = (event) => {
    console.log("tree click ");
    this.onNodeActivate.emit(event)
  };

  /**
   * filter 柯里化方法
   * @param searchVal 
   */
  private filterCurryFn(searchVal: string){
    let rootNode: TreeNode;
    let _searchVal = searchVal || null;

    return (node: TreeNode): boolean => {
      //console.log("node => ", node);

      if(_searchVal == null) return true;

      let valid = node.data.name.toLowerCase().indexOf(_searchVal.toLowerCase()) >= 0;
      let _rootNode = this.recursivelyParent(node);

      // 比對到就儲存根節點
      if(valid) rootNode = _rootNode;
      // 比對不到 檢查是否為同一個根節點
      else if(!valid && rootNode && rootNode.id == _rootNode.id){
        return true;
      }
      
      return valid;
    }

  }

  /**
   * 取得最上層節點
   * @param node 
   */
  private recursivelyParent(node: TreeNode): TreeNode{
    let rootNode: TreeNode;
    
    if(!node.isRoot) return this.recursivelyParent(node.parent);

    rootNode = node;

    return rootNode;
  }

  getTreeNode(){
    let nodes = this.tree.treeModel.nodes;
    console.log("nodes", nodes);
  }

  /**
   * 更新 treeview
   */
  treeUpdate = () => this.tree.treeModel.update();
  
  /**
   * 關閉所有節點
   */
  collapseAll = () => this.tree.treeModel.collapseAll();

  /**
   * 展開所有節點
   */
  expandAll = () => this.tree.treeModel.expandAll();

}
