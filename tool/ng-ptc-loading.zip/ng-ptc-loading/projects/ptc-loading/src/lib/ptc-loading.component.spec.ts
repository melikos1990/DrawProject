import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcLoadingComponent } from './ptc-loading.component';

describe('PtcLoadingComponent', () => {
  let component: PtcLoadingComponent;
  let fixture: ComponentFixture<PtcLoadingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcLoadingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcLoadingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
