import { TestBed, inject } from '@angular/core/testing';

import { PtcLoadingService } from './ptc-loading.service';

describe('PtcLoadingService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PtcLoadingService]
    });
  });

  it('should be created', inject([PtcLoadingService], (service: PtcLoadingService) => {
    expect(service).toBeTruthy();
  }));
});
