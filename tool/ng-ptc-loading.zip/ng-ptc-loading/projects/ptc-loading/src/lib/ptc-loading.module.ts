import { NgModule } from '@angular/core';
import { PtcLoadingComponent } from './ptc-loading.component';

import { OverlayModule } from '@angular/cdk/overlay';
import { PortalModule } from '@angular/cdk/portal';


@NgModule({
  imports: [
    OverlayModule,
    PortalModule
  ],
  declarations: [PtcLoadingComponent],
  exports: [PtcLoadingComponent]
})
export class PtcLoadingModule { }
