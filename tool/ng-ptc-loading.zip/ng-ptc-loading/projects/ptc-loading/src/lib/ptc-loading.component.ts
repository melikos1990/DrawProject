import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { Overlay, OverlayRef, OverlayConfig, PositionStrategy } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';


@Component({
  selector: 'ptc-loading',
  templateUrl: './ptc-loading.component.html',
  styles: []
})
export class PtcLoadingComponent implements OnInit {

  /**
   * 背景 style class
   */
  @Input()
  backdropClass: string | string[] = null;

  /**
   * 顯示區塊 style class
   */
  @Input()
  panelClass: string | string[] = null;

  /**
   * 顯示區塊 width(px) 如果沒有會自動以內容的寬度為準
   * ex: 150px
   */
  @Input()
  width: string = null;

  /**
   * 顯示區塊 height(px) 如果沒有會自動以內容的高度為準
   * ex: 150px
   */
  @Input()
  height: string = null;;


  /**
   * overlay
   */
  private _overlayRef: OverlayRef;

  /**
   * loading Portal
   */
  @ViewChild("loading")
  private _loading: TemplatePortal;

  constructor(
    private overlay: Overlay
  ) { }

  ngOnInit() {

    this._overlayRef = this._initPosition();

  }

  /**
   * 顯示loading畫面
   */
  show(){

    // 防呆 如果已經attach過了 會有錯誤
    this.close();
    
    this._overlayRef.attach(this._loading);

  }


  /**
   * 關閉loading畫面
   */
  close(){

    if(this._overlayRef.hasAttached()){
      this._overlayRef.detach();
      //this._overlayRef.dispose();
    }

  }


  /**
   * 建立 global PositionStrategy
   */
  private _createPositionStrategy(): PositionStrategy{
    return this.overlay
          .position()
          .global()
          .centerHorizontally()
          .centerVertically()
  }
  
  /**
   * 初始化 overlay
   */
  private _initPosition(): OverlayRef{
    let globalStrategy = this._createPositionStrategy();

    let config = new OverlayConfig({
      positionStrategy: globalStrategy,
      hasBackdrop: true
    })

    if(this.height) config.height = this.height

    if(this.width) config.width = this.width

    if(this.backdropClass) config.backdropClass = this.backdropClass
    
    if(this.panelClass) config.panelClass = this.panelClass

    return this.overlay.create(config);
  }

}
