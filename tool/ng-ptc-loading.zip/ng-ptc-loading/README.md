# ptc-loading

###`import { PtcLoadingModule } from 'ptc-loading'`  


## 描述  

**用途** ajax資料送出時顯示載入畫面

**整合內容**  angular cdk => overlay, portal

**參考文獻** 
> [overlay](https://v6.material.angular.io/cdk/overlay/api) angular material overlay  
> [portal](https://v6.material.angular.io/cdk/portal/api) angular material portal



## 屬性

| 屬性定義           | 名稱 | 型態 | 預設值 | 描述
|--------------|:-----:|:-----:| :-------:|------------------------
| @Input()   | backdropClass | string or string[] | null | 背景 style class
| @Input()   | panelClass | string or string[] | null | 顯示區塊 style class
| @Input()   | width | string | null | 顯示區塊 width(px) 如果沒有會自動以內容的寬度為準
| @Input()   | height | string | null | 顯示區塊 height(px) 如果沒有會自動以內容的高度為準


## 方法

**show()** 
>顯示loading畫面  

**close()** 
>關閉loading畫面  


## 使用方式（範例）

> app.module.ts

```javascript
import { PtcLoadingModule } from 'ptc-loading';

@NgModule({
  declarations: [
    AppComponent,
  ],
  
  imports: [  
	 ...
    PtcLoadingModule //add this line.
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }


```


> app.component.ts

```javascript


import { PtcLoadingComponent } from 'ptc-loading';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
    
  /**
   * 取得 loading 實體
   */
  @ViewChild("loading")
  loading: PtcLoadingComponent;

  /**
   * 判斷是否完成
   */
  isLoadingComplete: boolean = false;

  
  constructor(){}

  /**
   * 顯示 loading 畫面
   */
  showLoading(){
    this.loading.show();

    setTimeout(() => {
      this.isLoadingComplete = true;
      // this.closeLoading();
    }, 2000)

    setTimeout(() => {
      this.closeLoading();
      this.isLoadingComplete = false;
    }, 3000)


  }

  /**
   * 關閉 loading 畫面
   */
  closeLoading(){
    this.loading.close();
  }

}


```


> app.component.html

```html

<!--
    這裡有用到 Material icon 需再 index.html加入css
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
-->

<ptc-loading #loading >

  <img loading-img src="assets/imgs/loading.gif" style="height: 200px;" *ngIf="isLoadingComplete == false; else completeImg" />
  <ng-template #completeImg>
      <i class="material-icons" style="font-size: 190px; color: green;">done_all</i>
  </ng-template>

  <div loading-content>
    <h4 style="text-align: center;" *ngIf="isLoadingComplete == false; else complete">資料載入中....</h4>
    <ng-template #complete>
      <h4 style="text-align: center;" >資料載入完成</h4>
    </ng-template>
  </div>

</ptc-loading>

<button (click)="showLoading()">showLoading</button>

```    
