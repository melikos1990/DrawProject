import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';

import { PtcLoadingComponent } from 'ptc-loading';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'ng-ptc-loading';

  /**
   * 取得 loading 實體
   */
  @ViewChild("loading")
  loading: PtcLoadingComponent;

  /**
   * 判斷是否完成
   */
  isLoadingComplete: boolean = false;

  constructor(
  ){}


  ngOnInit(){
  }

  /**
   * 顯示 loading 畫面
   */
  showLoading(){
    this.loading.show();

    setTimeout(() => {
      this.isLoadingComplete = true;
      // this.closeLoading();
    }, 2000)

    setTimeout(() => {
      this.closeLoading();
      this.isLoadingComplete = false;
    }, 3000)


  }

  /**
   * 關閉 loading 畫面
   */
  closeLoading(){
    this.loading.close();
  }

}
