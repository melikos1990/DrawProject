import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/shared/service/http.service';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {


  url: string = "/Values/GetCaseList";

  caseList : any = [];



  constructor(private http: HttpService) { }

  ngOnInit() {
  }

  onVendorSelect($event) {

    this.http.get(this.url,{ 'WarehourseID': $event }).subscribe((payload: any) => {
      console.log(payload)
      payload.data.forEach(x=> x.AssetStatusName = this.parseAssetType(x.AssetStatus));
      this.caseList = payload.data;
    })


  }

  parseAssetType(type : number) : string {

    console.log(type);
    switch(type)
    {
      case 0 :
        return '正常'
      case 1 :
        return '待修中'
      case 2 :
        return '修理中'

    }
  }
}

export class Case{

  public AssetName : string;

  public AssetSatus : number;

  public CallDateTime : string;

  public ExceptDateTime : string;
}

