import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SummaryComponent } from './summary/summary.component';
import { ThemeModule } from '../../@theme/theme.module';
import { HomeRoutingModule } from './home-routing.module';
import { VendorMapComponent } from './vendor-map/vendor-map.component';
import { VenorCaseComponent } from './venor-case/venor-case.component';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from 'src/app/shared/shared.module';

const COMPONENTS = [
  SummaryComponent,
  VendorMapComponent,
  VenorCaseComponent,
]; 

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    SharedModule,
    ThemeModule,
    HttpClientModule,
    HomeRoutingModule,
    CommonModule
  ]
})
export class HomeModule { }
