import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VenorCaseComponent } from './venor-case.component';

describe('VenorCaseComponent', () => {
  let component: VenorCaseComponent;
  let fixture: ComponentFixture<VenorCaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VenorCaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VenorCaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
