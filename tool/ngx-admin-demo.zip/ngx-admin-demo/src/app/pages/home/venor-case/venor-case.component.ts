import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-venor-case',
  templateUrl: './venor-case.component.html',
  styleUrls: ['./venor-case.component.scss']
})
export class VenorCaseComponent implements OnInit {
  

  @Input() caseList : any[] = [];
  
  constructor() { }

  ngOnInit() {
  }

}
