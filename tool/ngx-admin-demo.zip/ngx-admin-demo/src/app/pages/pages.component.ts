import { Component, OnInit, OnDestroy, AfterViewInit } from '@angular/core';
import { MENU_ITEMS } from '../shared/data/pages-menu'
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import * as fromRootAction from '../store/actions'
import { State as fromRootReducer } from '../store/reducers'
import { Observable } from 'rxjs';
import { Menu } from 'src/app/model/master.model';
@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent implements OnInit {


  menu$ : Observable<Menu[]> = null;

  constructor( private store :Store<fromRootReducer>) { 

  }

  ngOnInit() {
    this.menu$ = this.store.select((state : fromRootReducer)=> state.auth.menu);
   
  }
  

  
  


}
