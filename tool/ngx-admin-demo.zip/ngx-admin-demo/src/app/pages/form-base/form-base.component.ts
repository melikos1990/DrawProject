import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AuthBaseComponent } from '../auth-base/auth-base.component';

@Component({
  selector: 'app-form-base',
  templateUrl: './form-base.component.html',
})
export class FormBaseComponent extends AuthBaseComponent {

  

  constructor() {
    super();
    
  }

  protected markNestedForm(form) {

    for (let control in form.controls) {
      let controlItem = form.controls[control]
      if (controlItem instanceof FormGroup) {
        this.markNestedForm(controlItem);
      }
      form.controls[control].markAsDirty();
      form.controls[control].markAsTouched();
    }

  }

}
