import { Component, OnInit } from '@angular/core';
import { loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AppInjector } from 'src/global-injector';
import { LocalStorageService } from 'src/app/shared/service/local-storage.service';
import { AuthenticationService } from 'src/app/shared/service/authentication.service';
import { PageAuth } from 'src/app/model/authorize.model';

@Component({
  selector: 'app-auth-base',
  templateUrl : './auth-base.component.html'
})
export class AuthBaseComponent {


  protected featrueName : string;

  private authService : AuthenticationService =  AppInjector.get(AuthenticationService);

  
  @loggerAction()
  protected hasReadAuth() : boolean {

    let user = this.authService.getTokenUser();
    
    return this.authService.hasAnyOperator(user , this.featrueName , 'read');

  }
  @loggerAction()
  protected hasEditAuth() : boolean{
    let user = this.authService.getTokenUser();
    
    return this.authService.hasAnyOperator(user , this.featrueName , 'edit');
  }

  @loggerAction()
  protected hasDeleteAuth() : boolean {
    let user = this.authService.getTokenUser();
    
    return this.authService.hasAnyOperator(user , this.featrueName , 'delete');
  }
  
  @loggerAction()
  protected hasAddAuth() : boolean{
    let user = this.authService.getTokenUser();
    
    return this.authService.hasAnyOperator(user , this.featrueName , 'add');
  }
}
