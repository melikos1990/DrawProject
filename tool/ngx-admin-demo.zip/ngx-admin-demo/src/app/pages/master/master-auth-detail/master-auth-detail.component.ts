import { Component, OnInit, OnDestroy } from '@angular/core';
import { Role } from 'src/app/model/authorize.model';

import { State as fromMasterAuthReducers } from "../store/reducers/"
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';

export const featrue = 'MasterAuthDetailComponent'

@Component({
  selector: 'master-auth-detail',
  templateUrl: './master-auth-detail.component.html',
  styleUrls: ['./master-auth-detail.component.scss']
})
export class MasterAuthDetailComponent implements OnInit, OnDestroy {


  masterauth$: Subscription
  masterauth: Role = new Role();

  constructor(private store: Store<fromMasterAuthReducers>) {

  }
  ngOnInit() {
    this.masterauth$ = this.store
      .select((state: fromMasterAuthReducers) => state.master.masterAuth.detail)
      .pipe(filter(x => x != null))
      .subscribe(masterauth => {
        this.masterauth = { ...masterauth };
      })
  }

  ngOnDestroy() {
    this.masterauth$ && this.masterauth$.unsubscribe();
  }



}
