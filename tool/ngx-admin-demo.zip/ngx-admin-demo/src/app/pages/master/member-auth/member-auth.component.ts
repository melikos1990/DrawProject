import { Component, OnInit, ViewChild } from '@angular/core';
import { PtcAjaxOptions, PtcServerTableRequest } from 'ptc-server-table';

import { Store } from '@ngrx/store';
import { State as fromRootReducers } from "src/app/store/reducers"
import * as fromMemberAuthActions from "../store/actions"
import * as fromRootActions from "src/app/store/actions"
import { Member } from 'src/app/model/authorize.model';

import { loggerClass, loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeOfAction, AuthorizeOfComponent } from 'src/app/shared/decorator/authorize.decorator';
import { ServerTableComponent } from 'src/app/shared/component/server-table/server-table.component';
import { AuthBaseComponent } from '../../auth-base/auth-base.component';
import { PtcSwalType } from 'ptc-swal';

export const featrue = 'MemberAuthComponent'

@Component({
  selector: 'app-member-auth',
  templateUrl: './member-auth.component.html',
  styleUrls: ['./member-auth.component.scss']
})
@loggerClass()
@AuthorizeOfComponent(featrue)
export class MemberAuthComponent extends AuthBaseComponent implements OnInit  {


  @ViewChild('table') table: ServerTableComponent;

  member = new Member();
  columns: any[] = [];
  ajax: PtcAjaxOptions = new PtcAjaxOptions();

  constructor(private store: Store<fromRootReducers>) {

    super()
    this.featrueName = featrue;

    this.ajax.url = 'http://10.2.123.86/WebApplication2/api/values/GetList/';
    this.ajax.method = 'POST';
    this.columns = [
      {
        text: '全選',
        name: 'p-check' // it will render checkbox
      },
      {
        text: '名稱',
        name: 'Name',
      },
      {
        text: '信箱',
        name: 'Email',

      },
      {
        text: '帳戶',
        name: 'Account',

      },
      {
        text: '操作',
        name: 'p-operator', 
      },
      {
        text: '自定義',
        name: 'la', 
        customer : true
      },
      {
        text: '自定義2',
        name: 'la2', 
        customer : true
      }
    ]

  }


  @loggerAction()
  ngOnInit(): void {
  
  }

  @loggerAction()
  critiria($event: PtcServerTableRequest<any>) {
    $event.criteria = this.member
  }

  @loggerAction()
  @AuthorizeOfAction(featrue, ['read'])
  render($event) {
    this.table.render($event)  
  }

  @loggerAction()
  @AuthorizeOfAction(featrue, ['delete'])
  onBtnDelete($event) {
    this.store.dispatch(new fromMemberAuthActions.MemberAuthActions.loadDetailAction('A'));
  }
  @loggerAction()
  @AuthorizeOfAction(featrue, ['read'])
  onBtnSearch($event) {
    this.store.dispatch(new fromMemberAuthActions.MemberAuthActions.loadDetailAction('A'));

  }
  @loggerAction()
  @AuthorizeOfAction(featrue, ['edit'])
  onBtnEdit($event) {
    this.store.dispatch(new fromMemberAuthActions.MemberAuthActions.loadDetailAction('A'));

  }
  
  @loggerAction()
  onAjaxError($event){
    this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction( {
      title: "失敗",
      text: `執行失敗 , 原因 : ${$event}`,
      type: PtcSwalType.error,
      showCancelButton: true
    }))
  }
}


