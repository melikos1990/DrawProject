import { Component, OnInit } from '@angular/core';
import { WorkflowNode } from 'src/app/model/workflow.model';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-flow-modal',
  templateUrl: './flow-modal.component.html',
  styleUrls: ['./flow-modal.component.scss']
})
export class FlowModalComponent implements OnInit {

  payload : WorkflowNode;
  
  constructor(private activeModal: NgbActiveModal) { }

  ngOnInit() {
  }
  close(){
    this.activeModal.close();
  }

}
