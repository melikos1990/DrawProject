import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlowModalComponent } from './flow-modal.component';

describe('FlowModalComponent', () => {
  let component: FlowModalComponent;
  let fixture: ComponentFixture<FlowModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlowModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlowModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
