import { Component, OnInit, OnDestroy } from '@angular/core';

import { State as fromFlowSettingReducers } from "../store/reducers/"
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Workflow, WorkflowNode, WorkflowConnection } from 'src/app/model/workflow.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FlowModalComponent } from './flow-modal/flow-modal.component';
import { ConditionModalComponent } from './condition-modal/condition-modal.component';
import { Guid } from "guid-typescript";
export const featrue = 'FlowSettingDetailComponent'

@Component({
  selector: 'flow-setting-detail',
  templateUrl: './flow-setting-detail.component.html',
  styleUrls: ['./flow-setting-detail.component.scss']
})
export class FlowSettingDetailComponent implements OnInit, OnDestroy {

  // nodes: WorkflowNode[] = [];
  // connections: WorkflowConnection[] = [];

  flowsetting$: Subscription
  flowsetting: Workflow = new Workflow();

  constructor(private modalService: NgbModal,
    private store: Store<fromFlowSettingReducers>) {

  }
  ngOnInit() {
    // this.flowsetting$ = this.store
    //   .select((state: fromFlowSettingReducers) => state.master.flowSetting.detail)
    //   .pipe(filter(x => x != null))
    //   .subscribe(flowsetting => {
    //     this.flowsetting = { ...flowsetting };
    //   })
    this.flowsetting.nodes = [{
      title: "開始",
      id: "start",
      x: 300,
      y: 300,
      allowDrag: true,
      allowEdit: false,
      type: '',
      script : '',
      formID : '',
      
    }];
  }


  addFlow($event) {

    this.flowsetting.nodes.push({
      "title": $event,
      "id": Guid.create().toString().replace('-' , ''),
      "type": $event,
      "x": 300,
      "y": 300,
      "allowDrag": true,
      "allowEdit": true,
      "script" : '',
      "formID" : ''
    })
  }
  ngOnDestroy() {
    this.flowsetting$ && this.flowsetting$.unsubscribe();
  }


  onNodesClick($event) {
    let node = this.findNode($event)

    if (node.type == 'flow') {
      const flowModal = this.modalService.open(FlowModalComponent, { size: 'lg', container: 'nb-layout' });
      flowModal.componentInstance.payload = node;
    }

    if(node.type == 'condition'){
      const flowModal = this.modalService.open(ConditionModalComponent, { size: 'lg', container: 'nb-layout' });
      flowModal.componentInstance.payload = node;
    }
  }

  findNode($event) {
    let index = this.flowsetting.nodes.indexOf($event)
    return this.flowsetting.nodes[index]
  }

  btnSave(){
    console.log(this.flowsetting);
  }

}
