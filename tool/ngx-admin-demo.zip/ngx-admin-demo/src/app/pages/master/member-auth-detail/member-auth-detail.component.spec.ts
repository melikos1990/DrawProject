import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MemberAuthDetailComponent } from './member-auth-detail.component';

describe('MemberAuthDetailComponent', () => {
  let component: MemberAuthDetailComponent;
  let fixture: ComponentFixture<MemberAuthDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberAuthDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberAuthDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
