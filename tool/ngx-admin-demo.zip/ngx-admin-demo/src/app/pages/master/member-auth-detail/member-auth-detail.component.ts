import { Component, OnInit, OnDestroy } from '@angular/core';
import { Member } from 'src/app/model/authorize.model';

import { State as fromMasterReducers } from "../store/reducers/"
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';

import * as fromRootAction from 'src/app/store/actions'
import * as fromMasterAction from '../../master/store/actions'

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeOfAction } from 'src/app/shared/decorator/authorize.decorator';
import { PtcSwalType } from 'ptc-swal';
import { FormBaseComponent } from '../../form-base/form-base.component';
import { ObjectSercvice } from 'src/app/shared/service/object.service';

export const featrue = 'MemberAuthDetailComponent'

@Component({
  selector: 'app-member-auth-detail',
  templateUrl: './member-auth-detail.component.html',
  styleUrls: ['./member-auth-detail.component.scss']
})
export class MemberAuthDetailComponent extends FormBaseComponent implements OnInit, OnDestroy {

  member$: Subscription
  member: Member = new Member();
  form: FormGroup;

  constructor(private objectService : ObjectSercvice,
              private store: Store<fromMasterReducers>) {
    super()
    this.featrueName = featrue;
  }
  ngOnInit() {
    this.member$ = this.store
      .select((state: fromMasterReducers) => state.master.memberAuth.detail)
      .pipe(filter(x => x != null))
      .subscribe(member => {
        this.member = { ...member };
      })


    
    this.form = new FormGroup({
      email: new FormControl(this.member.Email, [
        Validators.required,
        Validators.email,
      ]),
      name: new FormControl(this.member.Name, [
        Validators.required,
        Validators.maxLength(6),
      ]),
      account: new FormControl(this.member.Account, [
        Validators.required,
        Validators.maxLength(20),
      ]),
      password: new FormControl(this.member.Password, [
        Validators.required,
        Validators.maxLength(20),
      ]),
      phone: new FormControl(this.member.Phone, [
        Validators.required,
        Validators.maxLength(10),
      ]),
    })
  }

  ngOnDestroy() {
    this.member$ && this.member$.unsubscribe();
  }

  @loggerAction()
  btnBack($event){
    window.history.back();
  }

  @loggerAction()
  @AuthorizeOfAction(featrue, ['edit'])
  btnEdit($event) {

    if (this.form.invalid) {

      this.markNestedForm(this.form);
      
      this.store.dispatch(new fromRootAction.AlertActions.alertOpenAction({
        title: "失敗",
        text: `欄位驗證不通過`,
        type: PtcSwalType.error,
        showCancelButton: true
      }));

      return;
    }
    
    this.store.dispatch(new fromMasterAction.MemberAuthActions.editAction(this.member));

    

  }

}
