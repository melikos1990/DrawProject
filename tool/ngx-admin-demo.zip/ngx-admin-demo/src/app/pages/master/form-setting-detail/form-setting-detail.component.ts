import { Component, OnInit, OnDestroy, Inject, ViewChild } from '@angular/core';

import { State as fromFormSettingReducers } from "../store/reducers/"
import * as fromRootActions from "../store/actions/";
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { CdkDragDrop, moveItemInArray, transferArrayItem, copyArrayItem, CdkDropList } from '@angular/cdk/drag-drop';
import { DYNAMIC_INPUTS, NgInput, NgInputBase } from 'ptc-dynamic-form';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SettingModalComponent } from './setting-modal/setting-modal.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DYNAMIC_PAYLOADS } from 'src/app/@theme/theme.module';
import { FormBaseComponent } from '../../form-base/form-base.component';
import { Form } from 'src/app/model/master.model';

export const featrue = 'FormSettingDetailComponent'

@Component({
  selector: 'form-setting-detail',
  templateUrl: './form-setting-detail.component.html',
  styleUrls: ['./form-setting-detail.component.scss']
})
export class FormSettingDetailComponent extends FormBaseComponent implements OnInit, OnDestroy {


  inputs: NgInputBase[] = [];
  form: FormGroup;
  demoForm : FormGroup = new FormGroup({});
  demo = {};
  json = '';

  componentBasePayloads = [];
  displayPayloads = [];
  implementPayloads = [];


  formsetting$: Subscription
  formsetting: Form = new Form();

  constructor(private modalService: NgbModal,
    private store: Store<fromFormSettingReducers>,
    @Inject(DYNAMIC_PAYLOADS) private dynamicInputs: { key: string, payload: NgInputBase }[]) {

    super();
    
    this.setBasePayloads();
    this.setDisplayPayloads();

  }
  ngOnInit() {
    this.formsetting$ = this.store
      .select((state: fromFormSettingReducers) => state.master.formSetting.detail)
      .pipe(filter(x => x != null))
      .subscribe(form => {
        this.formsetting = { ...form };
        this.json = this.formsetting.Content;
        this.implementPayloads = JSON.parse(this.formsetting.Content)
      })

      //this.initializeForm();
  }

  ngOnDestroy() {
    this.formsetting$ && this.formsetting$.unsubscribe();
  }


  setBasePayloads() {
    this.componentBasePayloads = [];
    let di = [...this.dynamicInputs];

    di.forEach(pair => {
      this.componentBasePayloads.push({ ...pair.payload });
    })

  }

  setDisplayPayloads() {

    this.displayPayloads = [];
    let base = [...this.componentBasePayloads];
    base.forEach(x => {
      this.displayPayloads.push({ ...x });
    })
  }

  rowDelete($event) {
    let index = this.implementPayloads.indexOf($event)
    this.implementPayloads.splice(index, 1);
  }

  rowEdit($event) {
    const activeModal = this.modalService.open(SettingModalComponent, { size: 'lg', container: 'nb-layout' });
    activeModal.componentInstance.payload = $event;

  }

  deprecated(event: CdkDragDrop<string[]>) {
    this.implementPayloads.splice(event.previousIndex, 1);
  }


  btnSave() {
    this.formsetting.Content = JSON.stringify(this.implementPayloads);
    console.log(this.formsetting)
    this.store.dispatch(new fromRootActions.FormSettingActions.addAction(this.formsetting));
  }

  btnPreview() {
    this.json = JSON.stringify(this.implementPayloads);
    let objects = <Array<NgInputBase>>JSON.parse(this.json)
    this.inputs = [...objects];
  }

  drop(event: CdkDragDrop<string[]>, target: string) {

    if (event.previousContainer === event.container) {

      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);

    } else {

      if (event.previousContainer.id === 'right') {
        this.deprecated(event);
        return;
      }

      const activeModal = this.modalService.open(SettingModalComponent, { size: 'lg', container: 'nb-layout' });
      activeModal.componentInstance.payload = event.previousContainer.data[event.previousIndex];

      activeModal.componentInstance.saveHandler = (payload) => {
        transferArrayItem(event.previousContainer.data,
          event.container.data,
          event.previousIndex,
          event.currentIndex);
        this.setDisplayPayloads();
      }
    }

  }

  initializeForm() {
    this.form = new FormGroup({
      Name: new FormControl(this.formsetting.Name, [
        Validators.required,
        Validators.maxLength(6),
      ])

    });
  }

}
