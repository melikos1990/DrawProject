import * as fromMasterAuthAction from '../actions/master-auth.actions';
import { Role } from 'src/app/model/authorize.model';

export interface State{
	detail : Role
}

export const initialState : State = {
	detail : null
}

export function reducer(state :State, action: fromMasterAuthAction.Actions) {
	switch (action.type) {
		case fromMasterAuthAction.LOAD_DETAIL_SUCCESS:
			return {
				...state ,
				detail : action.payload
			};
		default:
			return state;
	}
}