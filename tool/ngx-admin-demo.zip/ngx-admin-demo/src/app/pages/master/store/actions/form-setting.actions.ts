import { Action } from '@ngrx/store';
import { Form } from 'src/app/model/master.model';


export const DETAIL_ENTRY = '[FORM-SETTING] DETAIL ENTRY';
export const LOAD_DETAIL = '[FORM-SETTING] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[FORM-SETTING] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[FORM-SETTING] LOAD DETAIL FAILED';

export const ADD = '[FORM-SETTING] ADD';
export const ADD_SUCCESS = '[FORM-SETTING] ADD SUCCESS';
export const ADD_FAILED = '[FORM-SETTING] ADD FAILED';


export class detailEntryAction implements Action {
    readonly type = DETAIL_ENTRY;
    constructor(public payload : any ) { }
}

export class loadDetailAction implements Action {
    type: string = LOAD_DETAIL
    constructor(public payload : string){ }
}
export class loadDetailSuccessAction implements Action {
    type: string = LOAD_DETAIL_SUCCESS
    constructor(public payload : any){ }
}
export class loadDetailFailedAction implements Action {
    type: string = LOAD_DETAIL_FAILED
    constructor(public payload : string){ }
}

export class addAction implements Action{
    type: string = ADD
    constructor(public payload : Form){ }
}

export class addSuccessAction implements Action{
    type: string = ADD_SUCCESS
    constructor(public payload : boolean){ }
}

export class addFailedAction implements Action{
    type: string = ADD_FAILED
    constructor(public payload : string){ }
}

export type Actions = detailEntryAction | 
                      loadDetailAction | 
                      loadDetailSuccessAction |
                      loadDetailFailedAction |
                      addAction |
                      addSuccessAction |
                      addFailedAction;


