import * as fromFlowSettingAction from '../actions/flow-setting.actions';
import { Workflow } from 'src/app/model/workflow.model';

export interface State{
	detail : Workflow
}

export const initialState : State = {
	detail : null
}

export function reducer(state :State, action: fromFlowSettingAction.Actions) {
	switch (action.type) {
		case fromFlowSettingAction.LOAD_DETAIL_SUCCESS:
			return {
				...state ,
				detail : action.payload
			};
		default:
			return state;
	}
}