import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';

import { State as fromFormSettingReducer } from '../reducers'
import * as fromFormSettingAction from '../actions/form-setting.actions';

import { exhaustMap, tap, map } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { of, concat } from 'rxjs';




// customer service
import { HttpService } from 'src/app/shared/service/http.service';

//customer object
import { AspnetJsonResult, AspnetJsonResultBase } from 'src/app/model/common.model';

// customer ngrx obsv
import { _httpflow$, _isHttpSuccess$ } from 'src/app/shared/ngrx/http.ngrx';
import { _unLoading$, _loadingWork$, _loading$ } from 'src/app/shared/ngrx/loading.ngrx'
import { _failed$, _success$ } from 'src/app/shared/ngrx/alert.ngrx'
import { _entry$ } from 'src/app/shared/ngrx/common.ngrx';
import { _route$ } from 'src/app/shared/ngrx/route.ngrx';
import { Form } from 'src/app/model/master.model';
import { ObjectSercvice } from 'src/app/shared/service/object.service';


@Injectable()
export class FormSettingEffects {
    constructor(private http: HttpService,
        private actions$: Actions,
        private objectService : ObjectSercvice,
        private store: Store <fromFormSettingReducer>) { }


    @Effect()
    loadDetail$ = _entry$<string>(this.actions$,
        fromFormSettingAction.LOAD_DETAIL)
        .pipe(
            exhaustMap((payload: string) => {

                // 主要要做的事情 , 這邊是透過 http client 撈取資料
                const retrieve$ = this.http.get<AspnetJsonResult<Form>> ('/FormSetting/GetForm', {});

                // 成功時將呼叫 loadDetailSuccess$ 進行後續行為
                const handleSuccess = (result: AspnetJsonResult<Form>) =>
                    of(new fromFormSettingAction.loadDetailSuccessAction(result.element));

                // 失敗時將呼叫 loadDetailFailed$ 進行後續行為
                const handleFailed = (result: AspnetJsonResult<any>) =>
                    of(new fromFormSettingAction.loadDetailFailedAction(result.message));

                // 判斷是否成功或是失敗
                const consider = (result: AspnetJsonResultBase) => result.isSuccess;

                // 實際進行http 行為
                const work$ = _httpflow$(handleSuccess, handleFailed, retrieve$, consider)

                return _loadingWork$(work$);
            })
    
        )   

    @Effect()
    loadDetailSuccess$ = _entry$<any>(this.actions$,
        fromFormSettingAction.LOAD_DETAIL_SUCCESS).pipe(
            exhaustMap(payload => {

                let popup$ = _success$('撈取成功');
                let direct$ = _route$('./pages/master/form-setting-detail', {});

                return concat(popup$, direct$)
            })
        )

    @Effect()
    loadDetailFailed$ = _entry$<string>(this.actions$,
        fromFormSettingAction.LOAD_DETAIL_FAILED).pipe(
            exhaustMap(payload => {
                return _failed$(payload)
            })
        )


        @Effect()
        add$ = _entry$<Form>(this.actions$,
            fromFormSettingAction.ADD).pipe(
                exhaustMap((payload: Form) => {
                    
                    let formData = this.objectService.convertToFormData(payload);
    
                    // 主要要做的事情 , 這邊是透過 http client 撈取資料
                    const retrieve$ = this.http.post<AspnetJsonResult<boolean>>('/FormSetting/CreateForm',null , 
                        formData
                    );
    
                    // 成功時將呼叫 loadDetailSuccess$ 進行後續行為
                    const handleSuccess = (result: AspnetJsonResult<boolean>) =>
                        of(new fromFormSettingAction.addSuccessAction(true));
    
                    // 失敗時將呼叫 loadDetailFailed$ 進行後續行為
                    const handleFailed = (result: AspnetJsonResult<boolean>) =>
                        of(new fromFormSettingAction.addFailedAction(result.message));
    
                    // 判斷是否成功或是失敗
                    const consider = (result: AspnetJsonResultBase) => result.isSuccess;
    
                    // 實際進行http 行為
                    const work$ = _httpflow$(handleSuccess, handleFailed, retrieve$, consider)
    
                    return _loadingWork$(work$);
                })
                
             )
    
             @Effect()
             editSuccess$ = _entry$<Form>(this.actions$,
                fromFormSettingAction.ADD_SUCCESS).pipe(
                     exhaustMap(payload => {
         
                         let popup$ = _success$('新增成功');
                         let direct$ = _route$('./pages/master/form-setting-detail', {});
         
                         return concat(popup$, direct$);
                     })
                 )
         
         
             @Effect()
             editFailed$ = _entry$<string>(this.actions$,
                fromFormSettingAction.ADD_FAILED).pipe(
                     exhaustMap(payload => {
                         return _failed$(payload)
                     })
                 )
    
}