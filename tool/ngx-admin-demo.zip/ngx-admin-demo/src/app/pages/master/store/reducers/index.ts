import * as fromMemberAuthReducer from  "./member-auth.reducers";
import * as fromMasterAuthReducer from  "./master-auth.reducers";
import * as fromFormSettingReducer from  "./form-setting.reducers";
import * as fromFlowSettingReducer from  "./flow-setting.reducers";
import * as fromRootReducer from "../../../../store/reducers"


export interface IndexState {
    memberAuth : fromMemberAuthReducer.State;
    masterAuth : fromMasterAuthReducer.State;
    formSetting : fromFormSettingReducer.State;
    flowSetting : fromFlowSettingReducer.State;
}

export interface State extends fromRootReducer.State {
    master : IndexState;
}

export const reducer = {
    memberAuth : fromMemberAuthReducer.reducer,
    masterAuth : fromMasterAuthReducer.reducer,
    formSetting : fromFormSettingReducer.reducer,
    flowSetting : fromFlowSettingReducer.reducer
} 