import { Action } from '@ngrx/store';
import { Workflow } from 'src/app/model/workflow.model';


export const DETAIL_ENTRY = '[FLOW-SETTING] DETAIL ENTRY';
export const LOAD_DETAIL = '[FLOW-SETTING] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[FLOW-SETTING] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[FLOW-SETTING] LOAD DETAIL FAILED';


export class detailEntryAction implements Action {
    readonly type = DETAIL_ENTRY;
    constructor(public payload : any ) { }
}

export class loadDetailAction implements Action {
    type: string = LOAD_DETAIL
    constructor(public payload : string){ }
}
export class loadDetailSuccessAction implements Action {
    type: string = LOAD_DETAIL_SUCCESS
    constructor(public payload : Workflow){ }
}
export class loadDetailFailedAction implements Action {
    type: string = LOAD_DETAIL_FAILED
    constructor(public payload : string){ }
}

export type Actions = detailEntryAction | 
                      loadDetailAction | 
                      loadDetailSuccessAction |
                      loadDetailFailedAction ;


