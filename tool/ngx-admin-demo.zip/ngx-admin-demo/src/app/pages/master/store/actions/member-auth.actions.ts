import { Action } from '@ngrx/store'
import { Member } from 'src/app/model/authorize.model';

export const DETAIL_ENTRY = '[MEMBER-AUTH] DETAIL ENTRY';

export const LOAD_DETAIL = '[MEMBER-AUTH] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[MEMBER-AUTH] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[MEMBER-AUTH] LOAD DETAIL FAILED';

export const EDIT = '[MEMBER-AUTH] EDIT';
export const EDIT_SUCCESS = '[MEMBER-AUTH] EDIT SUCCESS';
export const EDIT_FAILED = '[MEMBER-AUTH] EDIT FAILED';

export class detailEntryAction implements Action{
    type: string = DETAIL_ENTRY
    constructor(public payload :any){}
}

export class loadDetailAction implements Action {
    type: string = LOAD_DETAIL
    constructor(public payload : string){ }
}
export class loadDetailSuccessAction implements Action {
    type: string = LOAD_DETAIL_SUCCESS
    constructor(public payload : Member){ }
}
export class loadDetailFailedAction implements Action {
    type: string = LOAD_DETAIL_FAILED
    constructor(public payload : string){ }
}

export class editAction implements Action{
    type: string = EDIT
    constructor(public payload : Member){ }
}

export class editSuccessAction implements Action{
    type: string = EDIT_SUCCESS
    constructor(public payload : boolean){ }
}

export class editFailedAction implements Action{
    type: string = EDIT_FAILED
    constructor(public payload : string){ }
}

export type Actions = detailEntryAction | 
                      loadDetailAction | 
                      loadDetailSuccessAction |
                      loadDetailFailedAction |
                      editAction |
                      editSuccessAction |
                      editFailedAction;