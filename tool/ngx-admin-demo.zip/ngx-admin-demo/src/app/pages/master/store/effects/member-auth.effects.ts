import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';

import { State as fromRootReducer } from '../../../../store/reducers'
import * as fromMemberAuthAction from '../actions';


import { exhaustMap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { of, concat } from 'rxjs';
import { Member } from 'src/app/model/authorize.model';
import { HttpService } from 'src/app/shared/service/http.service';
import { AspnetJsonResult, AspnetJsonResultBase } from 'src/app/model/common.model';
import { _httpflow$, _isHttpSuccess$ } from 'src/app/shared/ngrx/http.ngrx';
import { _unLoading$, _loadingWork$, _loading$ } from 'src/app/shared/ngrx/loading.ngrx'
import { _failed$, _success$ } from 'src/app/shared/ngrx/alert.ngrx'
import { _entry$ } from 'src/app/shared/ngrx/common.ngrx';
import { _route$ } from 'src/app/shared/ngrx/route.ngrx';
import { ObjectSercvice } from 'src/app/shared/service/object.service';

@Injectable()
export class MemberAuthEffects {

    constructor(private http: HttpService,
        private objectService : ObjectSercvice,
        private actions$: Actions,
        private store: Store<fromRootReducer>) { }

    @Effect()
    loadDetail$ = _entry$<string>(this.actions$,
        fromMemberAuthAction.MemberAuthActions.LOAD_DETAIL)
        .pipe(
            exhaustMap((payload: string) => {

                // 主要要做的事情 , 這邊是透過 http client 撈取資料
                const retrieve$ = this.http.get<AspnetJsonResult<Member>>('/Values/GetUser', { UserID: payload });

                // 成功時將呼叫 loadDetailSuccess$ 進行後續行為
                const handleSuccess = (result: AspnetJsonResult<Member>) =>
                    of(new fromMemberAuthAction.MemberAuthActions.loadDetailSuccessAction(result.element));

                // 失敗時將呼叫 loadDetailFailed$ 進行後續行為
                const handleFailed = (result: AspnetJsonResult<Member>) =>
                    of(new fromMemberAuthAction.MemberAuthActions.loadDetailFailedAction(result.message));

                // 判斷是否成功或是失敗
                const consider = (result: AspnetJsonResultBase) => result.isSuccess;

                // 實際進行http 行為
                const work$ = _httpflow$(handleSuccess, handleFailed, retrieve$, consider)

                return _loadingWork$(work$);
            })

        )

    @Effect()
    loadDetailSuccess$ = _entry$<Member>(this.actions$,
        fromMemberAuthAction.MemberAuthActions.LOAD_DETAIL_SUCCESS).pipe(
            exhaustMap(payload => {

                let popup$ = _success$('撈取成功');
                let direct$ = _route$('./pages/master/member-auth-detail', {});

                return concat(popup$, direct$);
            })
        )


    @Effect()
    loadDetailFailed$ = _entry$<string>(this.actions$,
        fromMemberAuthAction.MemberAuthActions.LOAD_DETAIL_FAILED).pipe(
            exhaustMap(payload => {
                return _failed$(payload)
            })
        )
    
    @Effect()
    edit$ = _entry$<Member>(this.actions$,
         fromMemberAuthAction.MemberAuthActions.EDIT).pipe(
            exhaustMap((payload: Member) => {
                
                let formData = this.objectService.convertToFormData(payload);


                // 主要要做的事情 , 這邊是透過 http client 撈取資料
                const retrieve$ = this.http.post<AspnetJsonResult<boolean>>('/Values/Edit',null , 
                    formData
                );

                // 成功時將呼叫 loadDetailSuccess$ 進行後續行為
                const handleSuccess = (result: AspnetJsonResult<boolean>) =>
                    of(new fromMemberAuthAction.MemberAuthActions.editSuccessAction(true));

                // 失敗時將呼叫 loadDetailFailed$ 進行後續行為
                const handleFailed = (result: AspnetJsonResult<boolean>) =>
                    of(new fromMemberAuthAction.MemberAuthActions.editFailedAction(result.message));

                // 判斷是否成功或是失敗
                const consider = (result: AspnetJsonResultBase) => result.isSuccess;

                // 實際進行http 行為
                const work$ = _httpflow$(handleSuccess, handleFailed, retrieve$, consider)

                return _loadingWork$(work$);
            })
            
         )

         @Effect()
         editSuccess$ = _entry$<Member>(this.actions$,
             fromMemberAuthAction.MemberAuthActions.EDIT_SUCCESS).pipe(
                 exhaustMap(payload => {
     
                     let popup$ = _success$('更新成功');
                     let direct$ = _route$('./pages/master/member-auth-detail', {});
     
                     return concat(popup$, direct$);
                 })
             )
     
     
         @Effect()
         editFailed$ = _entry$<string>(this.actions$,
             fromMemberAuthAction.MemberAuthActions.EDIT_FAILED).pipe(
                 exhaustMap(payload => {
                     return _failed$(payload)
                 })
             )
         
    
    



}