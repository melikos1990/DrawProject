import { Member } from 'src/app/model/authorize.model';
import * as fromMemberAuthAction from '../actions/member-auth.actions'

export interface State {
    detail: Member
}

export const initialState: State = {
    detail: null
}

export function reducer(state = initialState, action: fromMemberAuthAction.Actions): State {
    switch (action.type) {
       
        case fromMemberAuthAction.LOAD_DETAIL_SUCCESS:
            return {
                ...state,
                detail: action.payload
            };
        default: {
            return state
        }
    }
}