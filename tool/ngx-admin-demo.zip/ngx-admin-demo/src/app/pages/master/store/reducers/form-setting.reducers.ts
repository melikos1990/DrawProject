import * as fromFormSettingAction from '../actions/form-setting.actions';
import { Form } from 'src/app/model/master.model';


export interface State{
	detail : Form
}

export const initialState : State = {
	detail : null
}

export function reducer(state :State, action: fromFormSettingAction.Actions) {
	switch (action.type) {
		case fromFormSettingAction.LOAD_DETAIL_SUCCESS:
			return {
				...state ,
				detail : action.payload
			};
		default:
			return state;
	}
}