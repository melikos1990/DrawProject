import { Action } from '@ngrx/store';
import { Role } from 'src/app/model/authorize.model'

export const DETAIL_ENTRY = '[MASTER-AUTH] DETAIL ENTRY';
export const LOAD_DETAIL = '[MASTER-AUTH] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[MASTER-AUTH] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[MASTER-AUTH] LOAD DETAIL FAILED';


export class detailEntryAction implements Action {
    readonly type = DETAIL_ENTRY;
    constructor(public payload : any ) { }
}

export class loadDetailAction implements Action {
    type: string = LOAD_DETAIL
    constructor(public payload : string){ }
}
export class loadDetailSuccessAction implements Action {
    type: string = LOAD_DETAIL_SUCCESS
    constructor(public payload : Role){ }
}
export class loadDetailFailedAction implements Action {
    type: string = LOAD_DETAIL_FAILED
    constructor(public payload : string){ }
}

export type Actions = detailEntryAction | 
                      loadDetailAction | 
                      loadDetailSuccessAction |
                      loadDetailFailedAction ;


