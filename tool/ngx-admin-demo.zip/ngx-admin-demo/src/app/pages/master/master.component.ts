import { Component } from '@angular/core';

@Component({
  selector: 'app-master',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class MasterComponent {
}
