import { Component, OnInit, ViewChild } from '@angular/core';
import { PtcAjaxOptions, PtcServerTableRequest } from 'ptc-server-table';
import { Store } from '@ngrx/store';
import { State as fromMasterAuthReducers } from "../store/reducers/"
import * as fromMasterAuthActions from "../store/actions/master-auth.actions"
import { Role } from 'src/app/model/authorize.model';
import * as fromRootActions from "src/app/store/actions"
import { loggerClass, loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeOfAction, AuthorizeOfComponent } from 'src/app/shared/decorator/authorize.decorator';
import { ServerTableComponent } from 'src/app/shared/component/server-table/server-table.component';
import { PtcSwalType } from 'ptc-swal';

/**
 * 功能名稱
 * - 於模組中的驗證 , 應用範圍如下 : 
 * - src/shared/component/authorize.directive.ts  (UI 權限判定)
 * - src/shared/decorator/authorize.decorator.ts  (component/function 權限判定)
 * - src/shared/service/authorize.decorator.ts    (權限驗證實作)
 */
export const featrue = 'MasterAuthComponent'

@Component({
  selector: 'app-master-auth',
  templateUrl: './master-auth.component.html',
  styleUrls: ['./master-auth.component.scss']
})
@loggerClass()
@AuthorizeOfComponent(featrue)
export class MasterAuthComponent implements OnInit {


  /**
   * 這邊使用套件為 ptc-server-table
   * 請參照以下網址 ： 
   * http://tfs2:8080/tfs/SD4-Collection/LibrarySD4/_git/ng-ptc-server-table?path=%2FREADME.md&version=GBmaster&_a=preview
   */
  @ViewChild('table') 
  table: ServerTableComponent;

  /**
   * 定義顯示之欄位 , 用途請參照以上網址
   */
  columns: any[] = [];

  /**
   * 定義ajax欄位 , 用途請參照以上網址
   */
  ajax: PtcAjaxOptions = new PtcAjaxOptions();

  /**
   * 這邊為畫面上的查詢條件 , 預設為建立之物件
   */
  masterauth = new Role();

  
  constructor(private store: Store<fromMasterAuthReducers>) {

    this.ajax.url = '.';
    this.ajax.method = 'POST';
    this.columns = [
        // 這邊對定義欄位做初始化
    ]

  }

  @loggerAction()
  @AuthorizeOfAction()
  ngOnInit(): void {
  
  }

  /**
   * 將物件傳出之前 , 加工 payload 送回server
   */
  @loggerAction()
  @AuthorizeOfAction()
  critiria($event: PtcServerTableRequest<any>) {
    $event.criteria = this.masterauth
  }

  /**
   * 按鈕按下查詢,渲染table
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['read'])
  btnRender($event : any) {
    this.table.render($event)  
  }

  /**
   * 按鈕按下查詢
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['add'])
  btnAdd($event : any){

  }

  /**
   * 當ptc server table 按下刪除
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['delete'])
  onBtnDelete($event : any) {
    this.store.dispatch(new fromMasterAuthActions.loadDetailAction('param'));
  }

  /**
   * 當ptc server table 按下查詢
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['read'])
  onBtnSearch($event : any) {
    this.store.dispatch(new fromMasterAuthActions.loadDetailAction('param'));

  }

  /**
   * 當ptc server table 按下編輯
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['edit'])
  onBtnEdit($event : any) {
    this.store.dispatch(new fromMasterAuthActions.loadDetailAction('param'));

  }

  onAjaxError($event) {
    this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction( {
      title: "失敗",
      text: `執行失敗 , 原因 : ${$event.statusText}`,
      type: PtcSwalType.error,
      showCancelButton: true
    }))
  }
}


