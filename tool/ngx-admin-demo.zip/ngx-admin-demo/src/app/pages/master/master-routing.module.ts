import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterComponent } from './master.component';
import { MemberAuthComponent } from './member-auth/member-auth.component';
import { MemberAuthDetailComponent } from './member-auth-detail/member-auth-detail.component';
import { AuthGuardService } from 'src/app/shared/service/auth-guard.service';
import { MasterAuthComponent } from './master-auth/master-auth.component';
import { MasterAuthDetailComponent } from './master-auth-detail/master-auth-detail.component';
import { FormSettingComponent } from './form-setting/form-setting.component';
import { FormSettingDetailComponent } from './form-setting-detail/form-setting-detail.component';
import { FlowSettingDetailComponent } from './flow-setting-detail/flow-setting-detail.component';

const routes: Routes = [{
  path: '',
  component: MasterComponent,
  children: [
    {
      path: 'member-auth',
      component: MemberAuthComponent,
      canActivate : [AuthGuardService],  
    },
    {
      path: 'member-auth-detail',
      component: MemberAuthDetailComponent,
      canActivate : [AuthGuardService], 
    },
    {
      path: 'master-auth',
      component: MasterAuthComponent,
      canActivate : [AuthGuardService],  
    },
    {
      path: 'master-auth-detail',
      component: MasterAuthDetailComponent,
      canActivate : [AuthGuardService], 
    },
    {
      path: 'form-setting',
      component: FormSettingComponent,
      canActivate : [AuthGuardService],  
    },
    {
      path: 'form-setting-detail',
      component: FormSettingDetailComponent,
      canActivate : [AuthGuardService], 
    },
    {
      path: 'flow-setting-detail',
      component: FlowSettingDetailComponent,
      canActivate : [AuthGuardService], 
    },
  ],
  canActivate : [AuthGuardService],
 
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [   
    RouterModule
  ]
})
export class MasterRoutingModule { }
