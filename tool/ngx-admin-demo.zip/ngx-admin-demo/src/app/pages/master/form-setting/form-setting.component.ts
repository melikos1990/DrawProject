import { Component, OnInit, ViewChild } from '@angular/core';
import { PtcAjaxOptions, PtcServerTableRequest } from 'ptc-server-table';
import { Store } from '@ngrx/store';
import { State as fromFormSettingReducers } from "../store/reducers/"
import * as fromFormSettingActions from "../store/actions/form-setting.actions"


import { loggerClass, loggerAction } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeOfAction, AuthorizeOfComponent } from 'src/app/shared/decorator/authorize.decorator';
import { ServerTableComponent } from 'src/app/shared/component/server-table/server-table.component';
import { Form } from 'src/app/model/master.model';

/**
 * 功能名稱
 * - 於模組中的驗證 , 應用範圍如下 : 
 * - src/shared/component/authorize.directive.ts  (UI 權限判定)
 * - src/shared/decorator/authorize.decorator.ts  (component/function 權限判定)
 * - src/shared/service/authorize.decorator.ts    (權限驗證實作)
 */
export const featrue = 'FormSettingComponent'

@Component({
  selector: 'app-form-setting',
  templateUrl: './form-setting.component.html',
  styleUrls: ['./form-setting.component.scss']
})
@loggerClass()
@AuthorizeOfComponent(featrue)
export class FormSettingComponent implements OnInit {


  /**
   * 這邊使用套件為 ptc-server-table
   * 請參照以下網址 ： 
   * http://tfs2:8080/tfs/SD4-Collection/LibrarySD4/_git/ng-ptc-server-table?path=%2FREADME.md&version=GBmaster&_a=preview
   */
  @ViewChild('table') 
  table: ServerTableComponent;

  /**
   * 定義顯示之欄位 , 用途請參照以上網址
   */
  columns: any[] = [];

  /**
   * 定義ajax欄位 , 用途請參照以上網址
   */
  ajax: PtcAjaxOptions = new PtcAjaxOptions();

  /**
   * 這邊為畫面上的查詢條件 , 預設為建立之物件
   */
  formsetting = new Form();

  
  constructor(private store: Store<fromFormSettingReducers>) {

    this.ajax.url = 'http://10.2.123.86/WebApplication2/api/FormSetting/GetList/';
    this.ajax.method = 'POST';
    this.columns = [
      {
        text: '全選',
        name: 'p-check'
      },
      {
        text: '名稱',
        name: 'Name',
      },
      {
        text: '描述',
        name: 'Description',
      },

    ]

  }

  @loggerAction()
  @AuthorizeOfAction()
  ngOnInit(): void {
  
  }

  /**
   * 將物件傳出之前 , 加工 payload 送回server
   */
  @loggerAction()
  @AuthorizeOfAction()
  critiria($event: PtcServerTableRequest<any>) {
    $event.criteria = this.formsetting
  }

  /**
   * 按鈕按下查詢,渲染table
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['read'])
  btnRender($event : any) {
    this.table.render($event)  
  }

  /**
   * 按鈕按下新增
   */
  @loggerAction()
  @AuthorizeOfAction(featrue, ['add'])
  btnAdd($event : any){
    this.store.dispatch(new fromFormSettingActions.loadDetailAction(''));
  }

  // /**
  //  * 當ptc server table 按下刪除
  //  */
  // @loggerAction()
  // @AuthorizeOfAction(featrue, ['delete'])
  // onBtnDelete($event : any) {
  //   this.store.dispatch(new fromFormSettingActions.loadDetailAction('param'));
  // }

  // /**
  //  * 當ptc server table 按下查詢
  //  */
  // @loggerAction()
  // @AuthorizeOfAction(featrue, ['read'])
  // onBtnSearch($event : any) {
  //   this.store.dispatch(new fromFormSettingActions.loadDetailAction('param'));

  // }

  // /**
  //  * 當ptc server table 按下編輯
  //  */
  // @loggerAction()
  // @AuthorizeOfAction(featrue, ['edit'])
  // onBtnEdit($event : any) {
  //   this.store.dispatch(new fromFormSettingActions.loadDetailAction('param'));

  // }
}


