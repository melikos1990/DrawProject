import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MasterComponent } from './master.component';
import { MasterRoutingModule } from './master-routing.module';
import { ThemeModule } from '../../@theme/theme.module';
import { StoreModule } from '@ngrx/store';
import * as fromMasterReducder from "./store/reducers"
import { MemberAuthComponent } from './member-auth/member-auth.component';
import { MemberAuthDetailComponent } from './member-auth-detail/member-auth-detail.component';
import { EffectsModule } from '@ngrx/effects';
import { SharedModule } from '../../shared/shared.module';
import { MemberAuthEffects } from './store/effects/member-auth.effects';
import { FormSettingEffects } from './store/effects/form-setting.effects';
import { MasterAuthComponent } from './master-auth/master-auth.component';
import { MasterAuthDetailComponent } from './master-auth-detail/master-auth-detail.component';
import { FormSettingComponent } from './form-setting/form-setting.component';
import { FormSettingDetailComponent } from './form-setting-detail/form-setting-detail.component';
import { SettingModalComponent } from './form-setting-detail/setting-modal/setting-modal.component';
import { FlowSettingComponent } from './flow-setting/flow-setting.component';
import { FlowSettingDetailComponent } from './flow-setting-detail/flow-setting-detail.component';
import { ConditionModalComponent } from './flow-setting-detail/condition-modal/condition-modal.component';
import { FlowModalComponent } from './flow-setting-detail/flow-modal/flow-modal.component';

const EFFECTS = [
  MemberAuthEffects,
  FormSettingEffects
]

const COMPONENTS = [
  MasterComponent,
  MemberAuthComponent,
  MemberAuthDetailComponent,
  MasterAuthComponent,
  MasterAuthDetailComponent,
  FormSettingComponent,
  FormSettingDetailComponent,
  FlowSettingComponent,
  FlowSettingDetailComponent,
  SettingModalComponent,
  FlowModalComponent,
  ConditionModalComponent,
];

@NgModule({
  imports: [
    MasterRoutingModule,
    ThemeModule,
    SharedModule,
    EffectsModule.forFeature(EFFECTS),
    StoreModule.forFeature('master', fromMasterReducder.reducer),
    CommonModule,
  ],
  declarations: [...COMPONENTS, ConditionModalComponent, FlowModalComponent],
  entryComponents: [
    SettingModalComponent,
    FlowModalComponent,
    ConditionModalComponent,
  ]

})
export class MasterModule { }
