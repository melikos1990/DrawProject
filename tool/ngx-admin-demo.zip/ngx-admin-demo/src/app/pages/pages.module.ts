import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PagesComponent } from './pages.component';
import { PagesRoutingModule } from './pages-routing.module';
import { ThemeModule } from '../@theme/theme.module';
import { AuthBaseComponent } from './auth-base/auth-base.component';
import { FormBaseComponent } from './form-base/form-base.component';


@NgModule({
  declarations: [PagesComponent, AuthBaseComponent, FormBaseComponent],
  imports: [
    PagesRoutingModule,
    ThemeModule,
    CommonModule,
  ]
})
export class PagesModule { }
