import { BrowserModule } from '@angular/platform-browser';
import { NgModule, ErrorHandler, Injector } from '@angular/core';
import { AppComponent } from './app.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { ThemeModule } from './@theme/theme.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CoreModule } from './@core/core.module';
import { SharedModule } from './shared/shared.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { reducers } from './store/reducers';
import { AuthorizeModule } from './auth/authorize.module';
import { LayoutModule } from './layout/layout.module';
import { ErrorHandlerService } from './shared/service/error-handler.service';
import { AuthEffects } from './store/effects/auth.effect';
import { setAppInjector } from 'src/global-injector';
import { HttpClientModule } from '@angular/common/http';


const EFFTECS = [
  AuthEffects
]
@NgModule({
  declarations: [
    AppComponent,
  ],

  imports: [
    SharedModule,
    BrowserModule,
    BrowserAnimationsModule,
    AuthorizeModule,
    LayoutModule,
    AppRoutingModule,
    CoreModule.forRoot(),
    ThemeModule.forRoot(),
    NgbModule.forRoot(),
    EffectsModule.forRoot(EFFTECS),
    StoreModule.forRoot(reducers),
    StoreDevtoolsModule.instrument({
      maxAge: 10
    })
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(injector: Injector) {
    setAppInjector(injector);
  }
}
