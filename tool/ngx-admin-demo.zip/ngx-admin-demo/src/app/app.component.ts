import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { State as fromRootReducer } from './store/reducers';
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { LocalStorageService } from './shared/service/local-storage.service';
import * as fromRootAction from './store/actions';
import { AuthenticationService } from './shared/service/authentication.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, OnDestroy {


  routeChange$: Subscription;
  routeStartup$: Subscription;


  constructor(private store: Store<fromRootReducer>,
    private auth: AuthenticationService,
    private router: Router) { }

  ngOnInit(): void {
    this.routeChange$ = this.store.select((state: fromRootReducer) => state.route)
      .pipe(
        filter(payload => payload.navigate != null)
      )
      .subscribe(payload => this.router.navigate([payload.navigate], payload.params));

    this.routeStartup$ = this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {

        let accessToken = this.auth.getAccessToken();
        let refreshToken = this.auth.getAccessToken();


        this.store.dispatch(new fromRootAction.AuthActions.parseAuthAction({
          accessToken: accessToken,
          refreshToken: refreshToken
        }))

      }
    });

  }

  ngOnDestroy(): void {
    this.routeChange$ && this.routeChange$.unsubscribe();
    this.routeStartup$ && this.routeStartup$.unsubscribe();
  }



}