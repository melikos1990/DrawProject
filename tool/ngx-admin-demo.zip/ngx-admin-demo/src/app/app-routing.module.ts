import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { SystemLoginComponent } from './auth/system-login/system-login.component';

const routes: Routes = [
  {
    path: '',
    children : [
      {
        path : '',
        component : SystemLoginComponent
      },
      {
        path : 'pages',
        loadChildren : './pages/pages.module#PagesModule'
      }
      

    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
