export class AspnetJsonResultBase {
    isSuccess : boolean;
    message : string
    extension : any
}

export class AspnetJsonResult<T> extends AspnetJsonResultBase {

    constructor(){
        super();
    }
    element : T;

}

