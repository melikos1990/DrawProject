

export class Member {
    Account : string;
    Password : string; 
    Name : string ;  
    Email : string;
    Phone : string;
    IsEnable : boolean;
    PageAuth : PageAuth[] = [];
  }
  
export class PageAuth{
    Feature  : string;
    Operator : Operator[];
}

export class Role {
    Name : string;
    IsEnable : boolean;
    PageAuth : PageAuth[] = [];
}