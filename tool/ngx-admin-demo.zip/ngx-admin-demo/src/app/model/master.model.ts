import { NbMenuItem } from '@nebular/theme';

export class Menu extends NbMenuItem {
    component? : string;
    children? : Menu[];
    skip? : boolean = false;
 }

 export class Form {
    ID : string;
    Name : string;
    Content : string;
    Description : string;
 }