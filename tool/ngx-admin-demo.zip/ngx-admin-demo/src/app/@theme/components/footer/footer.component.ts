import { Component } from '@angular/core';

@Component({
  selector: 'ngx-footer',
  styleUrls: ['./footer.component.scss'],
  template: `
    <span class="created-by">Copyright © 2018 © 統智科技股份有限公司 All Rights Reserved.</span>
   
  `,
})
export class FooterComponent {
}
