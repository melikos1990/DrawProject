import { ModuleWithProviders, NgModule, InjectionToken } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { PtcLocalTableModule } from 'ptc-local-table';
import { PtcServerTableModule } from 'ptc-server-table';
import { PtcLoadingModule } from 'ptc-loading';
import { PtcSwalModule } from 'ptc-swal';
import {
  PtcDynamicFormModule,
  NgFileInputComponent,
  NgGeneralInputComponent,
  NgSelectInputComponent, 
  NgTextAreaInputComponent,
  NgSingleCheckboxInputComponent,
  NgFileInput, 
  NgSignleCheckboxInput,
  NgTextAreaInput,
  NgGeneralInput, 
  NgSelectInput,
  NgInputBase,
  DYNAMIC_INPUTS
} from "ptc-dynamic-form"
import {
  NbActionsModule,
  NbCardModule,
  NbLayoutModule,
  NbMenuModule,
  NbRouteTabsetModule,
  NbSearchModule,
  NbSidebarModule,
  NbTabsetModule,
  NbThemeModule,
  NbUserModule,
  NbCheckboxModule,
  NbPopoverModule,
  NbContextMenuModule,
  NbProgressBarModule,
  NbCalendarModule,
  NbCalendarRangeModule,
  NbStepperModule,
  NbButtonModule,
  NbInputModule,
  NbAccordionModule,
  NbDatepickerModule,
  NbDialogModule,
  NbWindowModule,
  NbListModule,
  NbToastrModule,
  NbAlertModule,
  NbSpinnerModule,
  NbRadioModule,
  NbSelectModule,
  NbChatModule,
  NbTooltipModule,
  NbCalendarKitModule,
} from '@nebular/theme';

import { NbSecurityModule } from '@nebular/security';

import {
  FooterComponent,
  HeaderComponent,
  SearchInputComponent,
  ThemeSettingsComponent,
  SwitcherComponent,
  LayoutDirectionSwitcherComponent,
  ThemeSwitcherComponent,
  TinyMCEComponent,
  ThemeSwitcherListComponent,
  ToggleSettingsButtonComponent,
} from './components';
import {
  CapitalizePipe,
  PluralPipe,
  RoundPipe,
  TimingPipe,
  NumberWithCommasPipe,
  EvaIconsPipe,
} from './pipes';
import {
  OneColumnLayoutComponent,
  SampleLayoutComponent,
  ThreeColumnsLayoutComponent,
  TwoColumnsLayoutComponent,
} from './layouts';
import { DEFAULT_THEME } from './styles/theme.default';
import { COSMIC_THEME } from './styles/theme.cosmic';
import { CORPORATE_THEME } from './styles/theme.corporate';
import { MatChipsModule } from '@angular/material';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { ServerTableComponent } from '../shared/component/server-table/server-table.component';
import { AceEditorModule } from 'ng2-ace-editor';
export const DYNAMIC_PAYLOADS = new InjectionToken<{ key: string, payload: NgInputBase }[]>('DYNAMIC_PAYLOADS');



const PTC_MODULES = [
  PtcServerTableModule,
  PtcLocalTableModule,
  PtcLoadingModule,
  PtcSwalModule,
  PtcDynamicFormModule
]

const CDK_MODULES = [DragDropModule]

const BASE_MODULES = [CommonModule, FormsModule, ReactiveFormsModule];

const MD_MODULES = [MatChipsModule]

const NB_MODULES = [
  NbCardModule,
  NbLayoutModule,
  NbTabsetModule,
  NbRouteTabsetModule,
  NbMenuModule,
  NbUserModule,
  NbActionsModule,
  NbSearchModule,
  NbSidebarModule,
  NbCheckboxModule,
  NbPopoverModule,
  NbContextMenuModule,
  NgbModule,
  NbSecurityModule, // *nbIsGranted directive,
  NbProgressBarModule,
  NbCalendarModule,
  NbCalendarRangeModule,
  NbStepperModule,
  NbButtonModule,
  NbListModule,
  NbToastrModule,
  NbInputModule,
  NbAccordionModule,
  NbDatepickerModule,
  NbDialogModule,
  NbWindowModule,
  NbAlertModule,
  NbSpinnerModule,
  NbRadioModule,
  NbSelectModule,
  NbChatModule,
  NbTooltipModule,
  NbCalendarKitModule,

];

const COMPONENTS = [
  SwitcherComponent,
  LayoutDirectionSwitcherComponent,
  ThemeSwitcherComponent,
  ThemeSwitcherListComponent,
  HeaderComponent,
  FooterComponent,
  SearchInputComponent,
  ThemeSettingsComponent,
  TinyMCEComponent,
  OneColumnLayoutComponent,
  SampleLayoutComponent,
  ThreeColumnsLayoutComponent,
  TwoColumnsLayoutComponent,
  ToggleSettingsButtonComponent,
  ServerTableComponent,

];

const ENTRY_COMPONENTS = [
  ThemeSwitcherListComponent,
  NgFileInputComponent,
  NgGeneralInputComponent,
  NgSelectInputComponent,
  NgSingleCheckboxInputComponent,
  NgTextAreaInputComponent
];

const PIPES = [
  CapitalizePipe,
  PluralPipe,
  RoundPipe,
  TimingPipe,
  NumberWithCommasPipe,
  EvaIconsPipe,
];

const NB_THEME_PROVIDERS = [
  ...NbThemeModule.forRoot(
    {
      name: 'cosmic',
    },
    [DEFAULT_THEME, COSMIC_THEME, CORPORATE_THEME],
  ).providers,
  ...NbSidebarModule.forRoot().providers,
  ...NbMenuModule.forRoot().providers,
  ...NbDatepickerModule.forRoot().providers,
  ...NbDialogModule.forRoot().providers,
  ...NbWindowModule.forRoot().providers,
  ...NbToastrModule.forRoot().providers,
  ...NbChatModule.forRoot({
    messageGoogleMapKey: 'AIzaSyA_wNuCzia92MAmdLRzmqitRGvCF7wCZPY',
  }).providers,
];

@NgModule({
  imports: [...BASE_MODULES, ...NB_MODULES, ...PTC_MODULES, ...MD_MODULES, ...CDK_MODULES , AceEditorModule],
  exports: [...BASE_MODULES, ...NB_MODULES, ...COMPONENTS, ...PIPES, ...PTC_MODULES, ...MD_MODULES, ...CDK_MODULES , AceEditorModule],
  declarations: [...COMPONENTS, ...PIPES],
  entryComponents: [...ENTRY_COMPONENTS],
  providers: [
    { provide: DYNAMIC_PAYLOADS, useValue: { key: 'NgFileInput', payload: new NgFileInput('', '', '', null) }, multi: true },
    { provide: DYNAMIC_PAYLOADS, useValue: { key: 'NgGeneralInput', payload: new NgGeneralInput('', '', '', null) }, multi: true },
    { provide: DYNAMIC_PAYLOADS, useValue: { key: 'NgSelectInput', payload: new NgSelectInput('', '', '', null) }, multi: true },
    { provide: DYNAMIC_PAYLOADS, useValue: { key: 'NgSignleCheckboxInput', payload: new NgSignleCheckboxInput('', '', '', null) }, multi: true },
    { provide: DYNAMIC_PAYLOADS, useValue: { key: 'NgTextAreaInput', payload: new NgTextAreaInput('', '', '', null) }, multi: true },
 
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgFileInputComponent' , component : NgFileInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgGeneralInputComponent' , component : NgGeneralInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgSelectInputComponent' , component : NgSelectInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgTextAreaInputComponent' , component : NgTextAreaInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgSingleCheckboxInputComponent' , component : NgSingleCheckboxInputComponent} , multi: true },
    
  ]
})
export class ThemeModule {
  static forRoot(): ModuleWithProviders {
    return <ModuleWithProviders>{
      ngModule: ThemeModule,
      providers: [...NB_THEME_PROVIDERS],
      entryComponents:[...ENTRY_COMPONENTS]
    };
  }
}
