import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeModule } from '../@theme/theme.module';
import { LoadingComponent } from './loading/loading.component';
import { StoreModule } from '@ngrx/store';
import { AlertComponent } from "./alert/alert.component";

const COMPONENTS = [ LoadingComponent, AlertComponent ]

@NgModule({
  declarations: [ ...COMPONENTS ],
  imports: [
    CommonModule,
    ThemeModule,
    StoreModule
  ],
  exports : [
    ...COMPONENTS
  ]
  
})
export class LayoutModule { }
