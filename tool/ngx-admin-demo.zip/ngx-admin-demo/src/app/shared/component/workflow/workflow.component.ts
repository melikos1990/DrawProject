import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { WorkflowNode, WorkflowConnection, Workflow } from 'src/app/model/workflow.model';


@Component({
    selector: 'ng-workflow',
    templateUrl: 'workflow.component.html',
    styleUrls: ['workflow.component.scss']
})

export class WorkflowComponent implements OnInit {

    // @Input() public nodes: WorkflowNode[];
    // @Input() public connections: WorkflowConnection[];
    @Input() workflow: Workflow;
    @Input() gridSize: number = 10;
    @Input() lineColor = 'darkgray';
    @Output() nodesClick: EventEmitter<WorkflowNode | WorkflowConnection> = new EventEmitter();

    // Do not allow connection from same node it itself
    // and also prevent circular dependency
    // Example: if A → B. them B → A is not allowed.
    // However, B → C → A will be allowed
    @Input() allowCircular = true;

    constructor() { }

    ngOnInit() {
        //this.workflow = new Workflow();
        this.workflow.allowCircular = this.allowCircular;
        // this.workflow.nodes = this.nodes;
        // this.workflow.connections = this.connections;
    }

    discardConnection() {
        this.workflow.discardCurrentConnection();
    }

    getClickEvent(e: WorkflowConnection | WorkflowNode) {
        this.nodesClick.emit(e);
        if (e.click) {
           
            return e.click(e);
        }
        return () => {};
    }

}

