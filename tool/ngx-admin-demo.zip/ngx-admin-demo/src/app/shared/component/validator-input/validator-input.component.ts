import { Component, OnInit, Input, Directive } from '@angular/core';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-validator-input',
  templateUrl: './validator-input.component.html',
  styleUrls: ['./validator-input.component.scss']
})
export class ValidatorInputComponent implements OnInit {

  @Input() name : string ;
  @Input() form: FormGroup = new FormGroup({});

  get controlName() {
    return this.form.controls[this.name];
  }

  constructor() { }

  ngOnInit() {

  }

}
