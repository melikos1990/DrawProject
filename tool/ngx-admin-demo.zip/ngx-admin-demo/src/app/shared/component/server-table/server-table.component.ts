import { Component, OnInit, ViewChild, Input, EventEmitter, Output } from '@angular/core';
import { PtcServerTableComponent, PtcServerTableOptions, PtcAjaxOptions, PtcServerTableRequest } from 'ptc-server-table';
import { State as fromRootReducers } from "../../../store/reducers"
import * as fromRootActions from "../../../store/actions"
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-server-table',
  templateUrl: './server-table.component.html',
  styleUrls: ['./server-table.component.scss']
})
export class ServerTableComponent implements OnInit {

  @ViewChild('ptcServerTable')
  ptcServerTable: PtcServerTableComponent;

  opts = new PtcServerTableOptions();

  
  @Output() critiria: EventEmitter<any> = new EventEmitter();
  @Output() ajaxSuccess: EventEmitter<any> = new EventEmitter();
  @Output() ajaxError: EventEmitter<any> = new EventEmitter();
  @Output() btnDelete: EventEmitter<any> = new EventEmitter();
  @Output() btnSearch: EventEmitter<any> = new EventEmitter();
  @Output() btnEdit: EventEmitter<any> = new EventEmitter();
  @Output() pageChange: EventEmitter<any> = new EventEmitter();

  @Input() templateRefs : any = {};
  @Input() ajax: PtcAjaxOptions = new PtcAjaxOptions();
  @Input() pageSizeOptions: number[] = [5, 10, 20];
  @Input() defaultPageSize: number = 20;
  @Input() defaultPageIndex: number = 0
  @Input() columns: any = [];

  constructor(public store: Store<fromRootReducers>) { }

  ngOnInit() {
    this.opts.ajax = this.ajax;
    this.opts.columns = this.columns;
    this.opts.pageSizeOptions = this.pageSizeOptions;
    this.opts.pageSize = this.defaultPageSize;
    this.opts.pageIndex = this.defaultPageIndex;
  }



  beforeAjax($event) {
    this.store.dispatch(new fromRootActions.LoadingActions.visibleLoadingAction());
  }

 
  onAjax($event: PtcServerTableRequest<any>) {
    this.critiria.emit($event)
  }
 
  onAjaxSuccess($event) {
    this.store.dispatch(new fromRootActions.LoadingActions.invisibleLoadingAction());
    this.ajaxSuccess.emit($event);

  }

  onAjaxError($event) {
    this.store.dispatch(new fromRootActions.LoadingActions.invisibleLoadingAction());
    this.ajaxError.emit($event);
  }
  
  onBtnDelete($event) {
    this.btnDelete.emit($event);
  }

  onBtnSearch($event) {
    this.btnSearch.emit($event);
  }
 
  onBtnEdit($event) {
    this.btnEdit.emit($event);
  }

  onPageChange($event) {
    this.pageChange.emit($event);
  }
 
  getSelectItem(): any {
    return this.ptcServerTable.getSelectRows();
  }

  setRangeLabel(page: number, pageSize: number, length: number): string {
    if (length == 0 || pageSize == 0) {
      return `0 of ${length}`;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `第 ${startIndex + 1}筆 - 第 ${endIndex} 筆 , 共 ${length} 筆資料`;
  }

  render($event) {
    this.ptcServerTable.render();
  }

  reset($event) {
    this.ptcServerTable.reset();
  }
}
