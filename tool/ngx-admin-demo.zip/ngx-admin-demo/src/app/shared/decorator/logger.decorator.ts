import { ReflectiveInjector } from '@angular/core'
import { LogService } from '../service/log.service'
import { AppInjector } from 'src/global-injector';

export function loggerClass(feature?: string) {

    const inject = ReflectiveInjector.resolveAndCreate([
        LogService
    ])
    return function (constructor: any) {

        let log: LogService = inject.get(LogService);

        const component = constructor.name;
        log.logger.info(component);
    }

}

export function loggerAction(feature?: string , pageAuth? : Operator[]) {

  
    return function loggerAction(target: Object,
        method: string,
        descriptor: TypedPropertyDescriptor<any>) {

        

        var originalMethod = descriptor.value;

        descriptor.value = function (...args: any[]) {

            let log: LogService = AppInjector.get(LogService);

            log.logger.info(method);
            log.logger.info(`${method} args are: ` + JSON.stringify(args));
            log.logger.info(`${method} return value is: ` + result);
            var result = originalMethod.apply(this, args);
            return result;
        };

        return descriptor;
    }
}
