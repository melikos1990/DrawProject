import { AuthenticationService } from '../service/authentication.service';
import { AppInjector } from 'src/global-injector';

export function AuthorizeOfComponent(feature?: string) {


    return function (constructor: any) {

        let auth: AuthenticationService = AppInjector.get(AuthenticationService);
       
        const targetNgOnInit: Function = constructor.prototype.ngOnInit;

        function ngOnInit(...args): void {

        
            if (auth.onPageAuthorization(feature) == false) {
                throw new Error('無頁面權限');
            }

            if (targetNgOnInit) {
                targetNgOnInit.apply(this, args);
            }
        }

        constructor.prototype.ngOnInit = ngOnInit;

    }

}

export function AuthorizeOfAction(feature?: string, pageAuth?: Operator[]) {

    return function (target: Object,
        method: string,
        descriptor: TypedPropertyDescriptor<any>) {

        var originalMethod = descriptor.value;

        descriptor.value = function (...args: any[]) {

            let auth: AuthenticationService = AppInjector.get(AuthenticationService);

            if (auth.onFuncAuthorization(feature, pageAuth) == false) {
                throw new Error(`無功能權限 : ${JSON.stringify(pageAuth)} `);
            }

            var result = originalMethod.apply(this, args);
            return result;
        };

        return descriptor;


    }
}

