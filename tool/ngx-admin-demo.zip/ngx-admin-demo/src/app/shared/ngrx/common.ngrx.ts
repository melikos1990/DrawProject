import { Actions, ofType } from '@ngrx/effects';
import { map } from 'rxjs/operators';
import { tag } from 'rxjs-spy/operators';

export const _entry$ = <T>(action : Actions , type: string) => { 
    return action.pipe(    
        ofType(type),
        map((action : any)=>  <T>action.payload),
        tag(type)
    )
}