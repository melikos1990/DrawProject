import * as fromRootAction from '../../store/actions'
import { of } from "rxjs";
import { PtcSwalType } from 'ptc-swal';


let _success$ = (message: string) => of(new fromRootAction.AlertActions.alertOpenAction(
    {
        title: "成功",
        text: `執行成功 , 訊息 : ${message}`,
        type: PtcSwalType.success,
        showCancelButton: true
    }
    
));
let _failed$ = (message: string) => of(new fromRootAction.AlertActions.alertOpenAction(
    {
        title: "失敗",
        text: `執行失敗 , 原因 : ${message}`,
        type: PtcSwalType.error,
        showCancelButton: true
    }
));

export {
    _success$,
    _failed$
}