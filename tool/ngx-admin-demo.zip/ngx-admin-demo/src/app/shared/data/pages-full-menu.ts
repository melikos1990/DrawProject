import { NbMenuItem } from '@nebular/theme';

import { Menu } from 'src/app/model/master.model';


export const SETTING_MENU_ITEMS: Menu[] = [
    {
        title: '首頁',
        icon: 'nb-home',
        link: '/pages/home/summary',
        home: true,
        component: 'SummaryComponent'
    },
    {
        title: '主檔維護',
        icon: 'nb-star',
        children: [
            {
                title: '使用者設定(清單)',
                link: '/pages/master/member-auth',
                component: 'MemberAuthComponent'
            },
            {
                title: '使用者設定(明細)',
                link: '/pages/master/member-auth-detail',
                component: 'MemberAuthDetailComponent'
            },
            {
                title: '角色權限設定(清單)',
                link: '/pages/master/master-auth',
                component: 'MasterAuthComponent'
            },
            {
                title: '角色權限設定(明細)',
                link: '/pages/master/master-auth-detail',
                component: 'MasterAuthDetailComponent'
            },
        ],
    }

];
