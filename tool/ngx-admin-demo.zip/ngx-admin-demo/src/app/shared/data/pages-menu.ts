import { NbMenuItem } from '@nebular/theme';
import { Menu } from 'src/app/model/master.model';


export const MENU_ITEMS: Menu[] = [
  {
    title: '首頁',
    icon: 'nb-home',
    link: '/pages/home/summary',
    home: true,
    component : 'SummaryComponent'
  },
  {
    title: '功能列',
    group: true,
  },
  {
    title: '主檔維護',
    icon: 'nb-star',
    children: [
      {
        title: '使用者設定',
        link: '/pages/master/member-auth',
        component : 'MemberAuthComponent'
      },
      {
        title: '角色權限設定',
        link: '/pages/master/master-auth',
        component : 'MasterAuthComponent'
      },
      {
        title: '表格設定',
        link: '/pages/master/form-setting',
        component : 'FormSettingComponent'
      },
      {
        title: '流程設定',
        link: '/pages/master/flow-setting-detail',
        component : 'FlowSettingDetailComponent'
      },
    ],
  }
  
];
