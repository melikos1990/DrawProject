import { Directive, Input, OnInit, HostBinding } from '@angular/core';
import { AuthenticationService } from '../service/authentication.service';
import { LocalStorageService } from '../service/local-storage.service';




@Directive({
  selector: '[authorize]'
})
export class AuthorizeDirective implements OnInit {

  @HostBinding('style.visibility')
  display: string = 'inherit';

  @Input()
  feature : string = '';

  @Input()
  operators : Operator[] = [];

  constructor(private storage : LocalStorageService,
              private authentication : AuthenticationService) { }

  ngOnInit(): void {

    var jwtToken = this.authentication.getAccessToken();
    var user = this.authentication.parseTokenUser(jwtToken);

    if(!user){
      this.display = 'hidden';
      return;
    }

    if (this.authentication.onFuncAuthorization(this.feature , this.operators) == false) {
      this.display = 'hidden'
    } else {
      this.display = 'inherit'
    }

  }


}
