import { Injectable, ErrorHandler, Injector, Optional } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

import { Store } from '@ngrx/store';
import { State as fromRootReducers } from "../../store/reducers"
import * as fromRootActions from '../../store/actions';
import { PtcSwalType } from 'ptc-swal';

@Injectable()
export class ErrorHandlerService implements ErrorHandler {
  //private store: Store<fromRootReducers>

  constructor(private router: Router, private injector: Injector,
      @Optional() private store: Store<fromRootReducers>
  ) { 
    
  }

  handleError(error: any): void {
    console.log('handleError');
    console.log(error);
    if (error instanceof HttpErrorResponse) {
      //Backend returns unsuccessful response codes such as 404, 500 etc.				  
      console.error('[client]  Backend returned status code: ', error.status);
      console.error('[client]  Response body:', error.message);
    } else {


      //console.log(this.store);
      
      console.error('[client] An error occurred:', error.message);

      //this.router.navigate(['./']);
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction({
        title: "失敗",
        text: `執行失敗 , 原因 : ${error.message}`,
        type: PtcSwalType.error,
        showCancelButton: true
        
      }))
    }
  }
}
