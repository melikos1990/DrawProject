import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ObjectSercvice {

    jsonDeepClone<T>(obj: T): T {
        return JSON.parse(JSON.stringify(obj))
    }

    objDeepClone(obj: any) {
        var clone = {};
        for (var i in obj) {
            if (obj[i] != null && typeof (obj[i]) == "object")
                clone[i] = this.objDeepClone(obj[i]);
            else
                clone[i] = obj[i];
        }
        return clone;
    }

    convertToFormData(
        model: any,
        form: FormData = null,
        namespace = ''
      ): FormData {
     
        let formData = form || new FormData()
        let formKey
     
        for (let propertyName in model) {
          if (!model.hasOwnProperty(propertyName) || !model[propertyName]) {
            continue
          }
          // tslint:disable-next-line:no-shadowed-variable
          let formKey = namespace ? `${namespace}.${propertyName}` : propertyName
          if (model[propertyName] instanceof Date) {
            console.log(model[propertyName])
            formData.append(formKey, model[propertyName].toISOString())
          } else if (model[propertyName] instanceof Array) {
            model[propertyName].forEach((element, index) => {
     
              if (element instanceof File) {
                const tempFormKey = `${formKey}[]`
                formData.append(tempFormKey, element)
              } else {
                const tempFormKey = `${formKey}[${index}]`
                this.convertToFormData(element, formData, tempFormKey)
              }
            })
          } else if (
            typeof model[propertyName] === 'object' &&
            !(model[propertyName] instanceof File)
          ) {
            this.convertToFormData(model[propertyName], formData, formKey)
          } else if (model[propertyName] instanceof File) {
            formData.append(`${formKey}`, model[propertyName])
          } else {
            formData.append(formKey, model[propertyName])
          }
        }
        return formData
      }



}