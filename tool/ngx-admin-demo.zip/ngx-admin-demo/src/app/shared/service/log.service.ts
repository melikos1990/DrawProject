import { getLogger, Logger, BrowserConsoleAppender, SimpleLayout, AjaxAppender, JsonLayout } from 'log4javascript'
import { Injectable } from '@angular/core';


@Injectable({
    providedIn: 'root',
})
export class LogService {

    public logger: Logger
    static _instance: LogService;


    constructor() {
        if (this.logger == null) {
            this.initialize();
        }
    }

    initialize() {
        this.logger = getLogger('demo');

        // BrowserConsoleAppender
        let consoleAppender = new BrowserConsoleAppender();
        var consoleLayout = new ConsoleLayout();
      
        consoleAppender.setLayout(consoleLayout)

        // AjaxAppender
        let ajaxAppender = new AjaxAppender('http://10.2.123.86/WebApplication2/api/Log/WriteLog')
        let jsonLayout = new JsonLayout();
        jsonLayout.setCustomField('user' , 'user');
        ajaxAppender.setLayout(jsonLayout);
        ajaxAppender.setWaitForResponse(false);
        ajaxAppender.setRequestSuccessCallback(this.ajaxSuccessCallback);
        
        // Append
        this.logger.addAppender(consoleAppender);
        this.logger.addAppender(ajaxAppender);
    }


    ajaxSuccessCallback(httpRequest: XMLHttpRequest) {

        if (httpRequest.status != 200) {
            console.error(`上傳logger失敗 , status : ${httpRequest.status}`);
        } 
    }

}

export class ConsoleLayout extends SimpleLayout{

}




