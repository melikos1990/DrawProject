import { Injectable } from '@angular/core';

import { JwtHelperService } from '@auth0/angular-jwt';
import { Member , PageAuth } from 'src/app/model/authorize.model';
import { MENU_ITEMS } from '../data/pages-menu';
import { Menu } from 'src/app/model/master.model';
import { ObjectSercvice } from './object.service';

import { State as fromRootReducers } from "src/app/store/reducers"
import * as fromRootActions from "src/app/store/actions";
import { Store } from '@ngrx/store';
import { LocalStorageService } from './local-storage.service';
import { ActivatedRouteSnapshot } from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { HttpService } from './http.service';
import { AspnetJsonResult } from 'src/app/model/common.model';
import { exhaustMap, catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  private jwtHelper: JwtHelperService = new JwtHelperService()

  constructor(private http : HttpService ,
    private store: Store<fromRootReducers>,
    private storageService: LocalStorageService,
    private objectSercvice: ObjectSercvice) {

  }

  /**
   * 
   * @param param 
   * @param route 
   */
  onRouteAuthorizationParam(param: Operator, route: ActivatedRouteSnapshot): boolean {

    return true
  }

  /**
   * 
   * @param route 
   */
  onRouteAuthorization(route: ActivatedRouteSnapshot): boolean {

    try {

      let children = route.routeConfig.children;
      let feature = (<any>route.component).name;

      let currentUser: Member = this.getTokenUser();

      if (!currentUser) throw new Error("無權限-找不到使用者");

      if (children && children.length > 0) {
        let hasAuth = false

        for (let userPageAuth of currentUser.PageAuth) {
          if (children.some(x => userPageAuth.Feature.includes((<any>x.component).name))) {
            hasAuth = true;
          }
        }

        if (!hasAuth)
          throw new Error("無權限-權限不足");

      } else {

        if (this.onPageAuthorization(feature as string) == false)
          throw new Error("無權限-權限不足");

      }

    } catch (err) {
      this.store.dispatch(new fromRootActions.AuthActions.authDenyAction(err));

      return false;
    }

    return true;

  }

  /**
   * 
   * @param user 
   * @param feature 
   */
  onPageAuthorization(feature: string) {

    if (!feature) return true;

    let user: Member = this.getTokenUser();

    if (!user) throw new Error("無權限-找不到使用者");

    return this.findPageOperator(user, feature) != null;

  }

  /**
   * 
   * @param user 
   * @param feature 
   * @param operators 
   */
  onFuncAuthorization(feature: string, operators: Operator[]) {


    let user: Member = this.getTokenUser();

    if (!user) throw new Error("無權限-找不到使用者");

    if (!feature || this.hasAnyOperator(user, feature, 'all')) return true;

    for (let operator of operators) {
      if (!this.hasAnyOperator(user, feature, operator)) return false;
    }

    return true;
  }

  /**
   * 
   * @param user 
   * @param feature 
   * @param pageAuth 
   */
  hasAnyOperator(user: Member, feature: string, pageAuth: Operator) {

    let userPageAuth = this.findPageOperator(user, feature);

    if (userPageAuth == null) return false;

    return userPageAuth.some(x => x == pageAuth)
  }

  /**
   * 
   * @param user 
   * @param feature 
   */
  findPageOperator(user: Member, feature: string) {


    if (!user.PageAuth || user.PageAuth.length == 0)
      return null;

    let result = user.PageAuth.find(x => x.Feature == feature);

    return result ? result.Operator : null;
  }

  /**
   * 
   * @param auth 
   */
  parseMenuNode(auth: PageAuth[]): Menu[] {

    let result = [];
    let fullMenuNode = this.objectSercvice.jsonDeepClone(MENU_ITEMS);

    if (!auth || auth.length === 0)
      return [];

    fullMenuNode.forEach(node => {
      result.push(this.nestedCombinationMenuNode(node, auth))
    })

    return result.filter(x => (!x.children || x.children.length > 0));
  }

  /**
   * 
   * @param menu 
   * @param auth 
   */
  nestedCombinationMenuNode(menu: Menu, auth: PageAuth[]): Menu {

    let filtered = [];

    if (!menu.children) return menu;

    menu.children.forEach(node => {

      if (node.component) {

        // 檢核節點是否存在
        let exist = auth.some(x => x.Feature == node.component)

        // 如果節點存在 , 加入遞迴
        if (exist) {
          filtered.push(this.nestedCombinationMenuNode(node, auth))
        }

      } else {
        filtered.push(node);
      }

    });
    menu.children = filtered;

    return menu;
  }


  /**
   * 
   */
  getAccessToken(): string {
    return this.storageService.get<string>('ngToken');
  }
  /**
   * 
   */
  getRefreshToken(): string {
    return this.storageService.get<string>('ngRefreshToken');
  }

  /**
   * 
   */
  removeAccessToken() {
    this.storageService.remove('ngToken');
  }

   /**
   * 
   */
  removeRefreshToken() {
    this.storageService.remove('ngRefreshToken');
  }
  /**
   * 
   * @param token 
   */
  setAccessToken(token) {
    this.storageService.set('ngToken', token);

  }
  /**
  * 
  * @param token 
  */
  setRefreshToken(token) {
    this.storageService.set('ngRefreshToken', token);

  }

  /**
   * 
   */
  getTokenUser(): Member {

    let jwtToken = this.getAccessToken();

    if (jwtToken) {
      return this.parseTokenUser(jwtToken);
    } else {
      return null
    }
  }

  /**
   * 
   * @param token 
   */
  parseTokenUser(token: string): Member {

  
    try {

      if(!token)
       throw new Error('parse error (00)')

      let jwtDescript = this.jwtHelper.decodeToken(token);

      if (!jwtDescript.member) {
        throw new Error('parse error (01)')
      }
      let user = JSON.parse(jwtDescript.member)

      if (!user) {
        throw new Error('parse error (02)')
      }

      return user;

    } catch (error) {
      console.log(error);
      return null;
    }

  }

  /**
   * 
   */
  refreshToken$(): Observable<string> {

    let refreshToken = this.getRefreshToken();
    
    return this.http.post<AspnetJsonResult<string>>("Account/RefreshToken", null , {
      RefreshToken : refreshToken
    }).pipe(
      exhaustMap(payload=> {
        // 將token 放置在 localstorage 中
        this.setAccessToken(payload.element);
        this.setRefreshToken(payload.extension);

        return of(payload.element);
      }),
      catchError((error) => {
        return throwError(error);
      })
    )

  }

  /**
   * 
   * @param request 
   */
  cloneTokenRequest(request) {

    const accessToken = this.getAccessToken();

    if (!accessToken) {
      return request;
    }

    return request.clone({
      setHeaders: {
        Authorization: accessToken,
      }
    });
  }

}
