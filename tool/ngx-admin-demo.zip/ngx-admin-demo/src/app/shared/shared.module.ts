import { NgModule, ModuleWithProviders, ErrorHandler } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeModule } from 'src/app/@theme/theme.module';
import { AuthorizeDirective } from './directive/authorize.directive';
import { ErrorHandlerService } from './service/error-handler.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { GlobalInterceptor, DEFAULT_TIMEOUT } from './interceptor/global.interceptor';
import { DEFAULT_REFESH_TOKEN_URL_CHARATOR, DEFAULT_LOGIN_URL_CHARATOR, AuthInterceptor } from './interceptor/auth.interceptor';
import { ValidatorInputComponent } from './component/validator-input/validator-input.component';
import { NgFileInputComponent, NgGeneralInputComponent, NgSelectInputComponent, PtcDynamicFormComponent, DYNAMIC_INPUTS } from 'ptc-dynamic-form';
import { HtmlPipe } from './pipe/HtmlPipe';
import { AngularDraggableDirective } from './directive/angular-draggable.directive';
import { StopPropagationDirective } from './directive/stop-propagation.directive';
import { WorkflowComponent } from './component/workflow/workflow.component';
import { NodeComponent } from './component/node/node.component';
import { ConnectorComponent } from './component/connection/connection.component';
import { SvgLineComponent } from './component/svg-line/svg-line.component';


const COMPONENT = [
  ValidatorInputComponent,
  AuthorizeDirective,
  WorkflowComponent,
  NodeComponent,
  ConnectorComponent,
  HtmlPipe,
  SvgLineComponent,
  AngularDraggableDirective,
  StopPropagationDirective,
]

@NgModule({
  declarations: [...COMPONENT],
  imports: [
    ThemeModule,
    CommonModule,
  ],
  exports: [
    ...COMPONENT
  ],
  entryComponents:[
    NgFileInputComponent,
    NgGeneralInputComponent,
    NgSelectInputComponent
  ],
  providers: [
    { provide: ErrorHandler, useClass: ErrorHandlerService },
    { provide: HTTP_INTERCEPTORS, useClass: GlobalInterceptor, multi: true } ,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true } ,
    { provide: DEFAULT_TIMEOUT, useValue: 30000 } ,
    { provide: DEFAULT_REFESH_TOKEN_URL_CHARATOR, useValue: `refreshToken` },
    { provide: DEFAULT_LOGIN_URL_CHARATOR, useValue: `login` },
  ],
})
export class SharedModule {

  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      
    };
  }
}
