import { Inject, Injectable, InjectionToken } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { timeout } from 'rxjs/operators';
import { AuthenticationService } from '../service/authentication.service';

export const DEFAULT_TIMEOUT = new InjectionToken<number>('defaultTimeout');

@Injectable()
export class GlobalInterceptor implements HttpInterceptor {
  constructor(private auth: AuthenticationService,
              @Inject(DEFAULT_TIMEOUT) protected defaultTimeout: number) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const value = Number(req.headers.get('timeout')) || this.defaultTimeout;

    let newReq = this.auth.cloneTokenRequest(req)
    return next.handle(newReq)
                .pipe(timeout(value));
  }
} 