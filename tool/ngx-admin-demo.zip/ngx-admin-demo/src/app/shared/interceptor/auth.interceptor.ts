import { Inject, Injectable, InjectionToken } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { timeout, catchError, filter, take, switchMap } from 'rxjs/operators';
import { LocalStorageService } from '../service/local-storage.service';
import { AuthenticationService } from '../service/authentication.service';
import { State as fromRootReducer} from "src/app/store/reducers"
import * as fromRootAction from "src/app/store/actions"
import { Store } from '@ngrx/store';
export const DEFAULT_REFESH_TOKEN_URL_CHARATOR = new InjectionToken<number>('defaultRefreshTokenUrl');
export const DEFAULT_LOGIN_URL_CHARATOR = new InjectionToken<number>('defaultLoginUrl');

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
    constructor(private auth: AuthenticationService,
        private store : Store<fromRootReducer> ,
        @Inject(DEFAULT_REFESH_TOKEN_URL_CHARATOR) protected defaultRefreshTokenUrl: string,
        @Inject(DEFAULT_LOGIN_URL_CHARATOR) protected defaultLoginUrl: string) {
    }
    private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    private refreshTokenInProgress = false;


    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        return next.handle(req).pipe(

            catchError((error) => {
            
                // 如果不是401 錯誤 , 不嘗試刷新token 
                if (error.status !== 401) {
                    //this.store.dispatch(new fromRootAction.AuthActions.authDenyAction())
                    return throwError(error) 
                }

                if (req.url.includes(this.defaultRefreshTokenUrl) ||
                    req.url.includes(this.defaultLoginUrl)) {
                    if (req.url.includes(this.defaultRefreshTokenUrl)) {
                        this.store.dispatch(new fromRootAction.AuthActions.authDenyAction())
                        console.log('交換token失敗')
                        return throwError(error) 
                    }

                    // 回傳錯誤obeservable
                    return throwError(error);
                }

                if (this.refreshTokenInProgress) {

                    // 在token更新過程中 , 阻塞原來的observable
                    let tokenSubject$ =  this.refreshTokenSubject.pipe(
                        filter(result => result !== null),
                        take(1),
                        switchMap(() => next.handle(this.auth.cloneTokenRequest(req)))
                    )

                    return tokenSubject$;

                } else {

                    // 嘗試refresh token
                    this.refreshTokenInProgress = true;

                    this.refreshTokenSubject.next(null);

                    let refreshToken$ = this.auth.refreshToken$()
                        .pipe(
                            switchMap((token: string) => {

                                this.refreshTokenInProgress = false;
                                this.refreshTokenSubject.next(token);

                                // refresh token 成功後 , 再次發送requrest
                                return next.handle(this.auth.cloneTokenRequest(req));

                            }),
                            catchError((error)=> {
                                this.refreshTokenInProgress = false;
                                this.store.dispatch(new fromRootAction.AuthActions.authDenyAction('TOKEN 交換異常'))
                                return throwError(error)
                            })
                        )

                    return refreshToken$;

                }
            })

        )
    }
}