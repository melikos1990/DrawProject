import { Action } from '@ngrx/store'

export const CHANGE_ROUTE = "[ROUTE] CHANGE";

export class changeRouteAction implements Action{
    type: string = CHANGE_ROUTE
    constructor(public payload : any){}
}

export type Actions = changeRouteAction ;