import { Action } from '@ngrx/store'
import { PtcSwalOption } from 'ptc-swal';

export const ALERT_OPEN = "[ALERT] OPEN";

export class alertOpenAction implements Action{
    type: string = ALERT_OPEN
    constructor(public payload : PtcSwalOption){}
}


export type Actions = alertOpenAction ;