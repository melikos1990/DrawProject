import { Action } from '@ngrx/store'
import { Member } from 'src/app/model/authorize.model';
import { Menu } from 'src/app/model/master.model';


export const LOGIN = "[AUTH] LOGIN";
export const LOGIN_SUCCESS = "[AUTH] LOGIN SUCCESS";
export const LOGIN_FAILED = "[AUTH] LOGIN FAILED";
export const LOGOFF = "[AUTH] LOGOFF";
export const LOGOFF_SUCCESS = "[AUTH] LOGOFF SUCCESS";
export const LOGOFF_FAILED = "[AUTH] LOGOFF FAILED";

export const AUTH_DENY = "[AUTH] AUTH DENY";
export const CLEAR_AUTH = '[AUTH] AUTH CLEAR'

export const TOKEN_MEMBER = '[AUTH] TOKEN MEMBER'
export const TOKEN_MENU = '[AUTH] TOKEN MENU'

export const PARSE_AUTH = '[AUTH] PARSE AUTH'

export class loginAction implements Action {
    type: string = LOGIN
    constructor(public payload: Member) { }
}

export class loginFailedAction implements Action {
    type: string = LOGIN_FAILED
    constructor(public payload: string) { }
}

export class loginSuccessAction implements Action {
    type: string = LOGIN_SUCCESS
    constructor(public payload: { accessToken: string, refreshToken: string }) { }

}

export class logOffAction implements Action {
    type: string = LOGOFF
    constructor(public payload: any = null) { }
}

export class logoffSuccessAction implements Action {
    type: string = LOGOFF_SUCCESS
    constructor(public payload: any = null) { }
}

export class logoffFailedAction implements Action {
    type: string = LOGOFF_FAILED
    constructor(public payload: any = null) { }
}

export class authDenyAction implements Action {
    type: string = AUTH_DENY
    constructor(public payload: string = null) { }
}


export class clearAuthAction implements Action {
    type: string = CLEAR_AUTH
    constructor(public payload: any = null) { }
}

export class parseAuthAction implements Action {
    type: string = PARSE_AUTH
    constructor(public payload: any) { }
}

export class TokenMemberAction implements Action {
    type: string = TOKEN_MEMBER
    constructor(public payload: Member = null) { }
}

export class TokenMenuAction implements Action {
    type: string = TOKEN_MENU
    constructor(public payload: Menu[] = []) { }
}


export type Actions =
    authDenyAction |
    loginAction |
    loginSuccessAction |
    loginFailedAction |
    logOffAction |
    logoffFailedAction |
    logoffSuccessAction |
    TokenMemberAction |
    TokenMenuAction |
    clearAuthAction |
    parseAuthAction;