import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/shared/service/http.service';
import { Actions, Effect } from '@ngrx/effects';
import { Store } from '@ngrx/store';

import { State as fromRootReducer } from '../reducers'
import * as fromRootAction from '../actions'
import { exhaustMap, debounceTime, switchMap, flatMap, map, catchError, tap, filter } from 'rxjs/operators';
import { _failed$ } from 'src/app/shared/ngrx/alert.ngrx';
import { _route$ } from 'src/app/shared/ngrx/route.ngrx';
import { _entry$ } from 'src/app/shared/ngrx/common.ngrx';
import { of, concat, iif, forkJoin } from 'rxjs';
import { Member } from 'src/app/model/authorize.model';
import { AspnetJsonResult, AspnetJsonResultBase } from 'src/app/model/common.model';
import { _httpflow$ } from 'src/app/shared/ngrx/http.ngrx';
import { _loadingWork$, _loading$, _unLoading$ } from 'src/app/shared/ngrx/loading.ngrx';
import { AuthenticationService } from 'src/app/shared/service/authentication.service';
import { LocalStorageService } from 'src/app/shared/service/local-storage.service';

@Injectable()
export class AuthEffects {

    constructor(private http: HttpService,
        private authenticationService: AuthenticationService,
        private localStorageService: LocalStorageService,
        private actions$: Actions,
        private store: Store<fromRootReducer>) { }

   
    @Effect()
    authDeny$ = _entry$<any>(this.actions$,
        fromRootAction.AuthActions.AUTH_DENY).pipe(
            exhaustMap((payload: string) => {
                console.log('authDeny')
                let clearAuth$ = of(new fromRootAction.AuthActions.clearAuthAction());
                let direct$ = _route$('./', {}) ;
                let failedPopup$ = _failed$(payload || '無權限');

                return concat(failedPopup$, direct$ , clearAuth$)
            }
            )
        )

    @Effect()
    login$ = _entry$<Member>(this.actions$,
        fromRootAction.AuthActions.LOGIN).pipe(
            switchMap((payload: Member) => {


                const retrieve$ = this.http.post<AspnetJsonResult<string>>('/Account/Login', null, payload);

                // 成功時將呼叫 login$ 進行後續行為
                const handleSuccess = (result: AspnetJsonResult<string>) =>
                    of(new fromRootAction.AuthActions.loginSuccessAction({
                        accessToken: result.element,
                        refreshToken: result.extension
                    }));

                // 失敗時將呼叫 loadDetailFailed$ 進行後續行為
                const handleFailed = (result: AspnetJsonResult<string>) =>
                    of(new fromRootAction.AuthActions.loginFailedAction(result.message));

                // 判斷是否成功或是失敗
                const consider = (result: AspnetJsonResultBase) => result.isSuccess;

                // 實際進行http 行為
                const work$ = _httpflow$(handleSuccess, handleFailed, retrieve$, consider)

                return _loadingWork$(work$);

            }),
            catchError(err => of(new fromRootAction.AuthActions.loginFailedAction(err))
            ))

    @Effect()
    parseAuth$ = _entry$<string>(this.actions$,
        fromRootAction.AuthActions.PARSE_AUTH)
        .pipe(
            filter((payload : any) => payload.accessToken != null),
            exhaustMap((payload: any) => {

                let member = this.authenticationService.parseTokenUser(payload.accessToken)

                if(!member) {
                    return _failed$('使用者TOKEN 解析失敗');
                }

                // 將解析後的user 資料放置在store 中
                const tokenMember$ = of(new fromRootAction.AuthActions.TokenMemberAction(member));

                // 解析menu 資料
                const menu = this.authenticationService.parseMenuNode(member.PageAuth)

                // 將解析後的menu 資料放置在store 中
                const tokenMenu$ = of(new fromRootAction.AuthActions.TokenMenuAction(menu))

                return concat(tokenMember$, tokenMenu$);
            })
        )

    @Effect()
    loginSuccess$ = _entry$<string>(this.actions$,
        fromRootAction.AuthActions.LOGIN_SUCCESS)
        .pipe(

            exhaustMap((payload: any) => {

                console.log(payload);

                // 將token 放置在 localstorage 中
                this.authenticationService.setAccessToken(payload.accessToken);
                this.authenticationService.setRefreshToken(payload.refreshToken);

                const direct$ = _route$('./pages/home/summary', {});
                const parseAuth$ = of(new fromRootAction.AuthActions.parseAuthAction(payload));

                return concat(parseAuth$, direct$);
            }),
            catchError(err => of(new fromRootAction.AuthActions.loginFailedAction(err))
            ))


    @Effect()
    loginFailed$ = _entry$<string>(this.actions$,
        fromRootAction.AuthActions.LOGIN_FAILED)
        .pipe(

            flatMap(err => {
                return _failed$(err)
            })
        )

    @Effect()
    logoff$ = _entry$(this.actions$, fromRootAction.AuthActions.LOGOFF)
        .pipe(
            flatMap(() => {

                let direct$ = _route$('./', {});

                let clearAuth$ = of(new fromRootAction.AuthActions.clearAuthAction())

                // 導向登入頁
                return concat(direct$, clearAuth$);
            })
        )
    @Effect({dispatch:false}) 
    clearAuth$ =_entry$(this.actions$, fromRootAction.AuthActions.CLEAR_AUTH)
    .pipe(
        tap(() => {

            this.authenticationService.removeAccessToken();
            this.authenticationService.removeRefreshToken();
        })
    )

}