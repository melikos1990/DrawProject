import * as fromAuthActions from '../actions/auth.actions';
import { Member } from 'src/app/model/authorize.model';
import { Menu } from 'src/app/model/master.model';


export interface State {
    token: string,
    refreshToken : string,
    member: Member,
    menu: Menu[]
}

export const initialState: State = {
    token: null,
    refreshToken : null,
    member: null,
    menu: []
}

export function reducer(state = initialState, action: fromAuthActions.Actions): State {

    switch (action.type) {
        case fromAuthActions.LOGIN_SUCCESS:
            return {
                ...state,
                token: action.payload.accessToken,
                refreshToken : action.payload.refreshToken,
            }
        case fromAuthActions.TOKEN_MEMBER:
            return {
                ...state,
                member: action.payload
            }
        case fromAuthActions.TOKEN_MENU:
            return {
                ...state,
                menu: action.payload
            }
        case fromAuthActions.CLEAR_AUTH:
            return {
                ...state,
                token: null,
                member: null,
                menu: [],
            }
        default: {
            return state;
        }

    }

}