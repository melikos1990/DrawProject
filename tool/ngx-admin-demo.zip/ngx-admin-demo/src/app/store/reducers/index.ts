import * as fromLoadingReducer from  "../../store/reducers/loading.reducer";
import * as fromAlertReducer from  "../../store/reducers/alert.reducer";
import * as fromRouteReducer from  "../../store/reducers/route.reducer";
import * as fromAuthReducer from  "../../store/reducers/auth.reducer";


export interface State {
    loading : fromLoadingReducer.State;
    alert : fromAlertReducer.State;
    route : fromRouteReducer.State;
    auth : fromAuthReducer.State
}

export const reducers = {
    loading : fromLoadingReducer.reducer,
    alert : fromAlertReducer.reducer,
    route : fromRouteReducer.reducer,
    auth : fromAuthReducer.reducer
}