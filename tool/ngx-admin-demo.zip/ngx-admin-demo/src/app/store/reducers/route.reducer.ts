import * as fromRouteActions from '../actions/route.actions';


export interface State {
    navigate: string;
    params : any;
}

export const initialState: State = {
    navigate: null,
    params : null
}

export function reducer(state = initialState, action: fromRouteActions.Actions): State {

    switch (action.type) {
        case fromRouteActions.CHANGE_ROUTE:
          
            return {
                ...state,
                navigate: action.payload.navigate,
                params : action.payload.params,
            }    
        default : {
            return state;
        }

    }

}