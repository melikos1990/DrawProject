import * as fromAlertActions from '../actions/alert.actions';
import { PtcSwalOption } from 'ptc-swal';

export interface State {
    opts: PtcSwalOption
}

export const initialState: State = {
    opts: null
}

export function reducer(state = initialState, action: fromAlertActions.Actions): State {

    switch (action.type) {
        case fromAlertActions.ALERT_OPEN:       
            return {
                ...state,
                opts: action.payload
            } 
               
        default : {
            return state;
        }

    }

}