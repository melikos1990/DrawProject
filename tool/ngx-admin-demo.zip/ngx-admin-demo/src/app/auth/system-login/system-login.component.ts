import { Component, OnInit } from '@angular/core';
import { loggerClass, loggerAction } from 'src/app/shared/decorator/logger.decorator';
import * as fromRootAction from 'src/app/store/actions';
import { State as fromRootReducers } from 'src/app/store/reducers'
import { Store } from '@ngrx/store';
import { Member } from 'src/app/model/authorize.model';

@Component({
  selector: 'app-login',
  templateUrl: './system-login.component.html',
  styleUrls: ['./system-login.component.scss']
})
@loggerClass()
export class SystemLoginComponent  implements OnInit {


  member = new Member();

  constructor(private store :  Store<fromRootReducers>){}

  @loggerAction()
  ngOnInit(): void {
  }

  @loggerAction()
  btnLogin($event) {

    this.store.dispatch(new fromRootAction.AuthActions.loginAction({...this.member}));
  }
 


}