import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SystemLoginComponent } from './system-login/system-login.component';
import { ThemeModule } from '../@theme/theme.module';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [SystemLoginComponent],
  imports: [
    CommonModule,
    ThemeModule, 
    RouterModule, 
  ],
  exports : [
    SystemLoginComponent
  ]
})
export class AuthorizeModule { }
