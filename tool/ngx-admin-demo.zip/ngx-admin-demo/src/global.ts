
interface String {
  toHostUrl(): string;
}

String.prototype.toHostUrl = function () {
  return `http://10.2.123.86/WebApplication2/api/${this}`;
}


