import { Component, OnInit, SimpleChanges, Input } from '@angular/core';

import { PtcSelect2AjaxOptions, SelectData, PtcSelect2Service } from 'ptc-select2';


@Component({
  selector: 'app-dynamic-select',
  templateUrl: './dynamic-select.component.html',
  styleUrls: ['./dynamic-select.component.scss']
})
export class DynamicSelectComponent implements OnInit {

  @Input() buID: number;

  @Input() groupName: string;

  options: PtcSelect2AjaxOptions<{}> = {
    url: "",
    method: "POST",
    pageIndex: 1,
    size: 10
  }
  maxLevel: any[] = [];
  model: any[] =  [];
  data: SelectData = new SelectData(true, [
    {id: 1, text: "item#1"},
    {id: 2, text: "item#2"}
  ])

  constructor(
    private ptcSelectService: PtcSelect2Service
  ) { }

  ngOnInit() {
    setTimeout(() => {
      console.log("all => ", this.ptcSelectService.ptcSelectAll);
    })
  }

  ngOnChanges(changes: SimpleChanges): void {
    if(changes["buID"]){
      this.getMaxLevel();
    }
  }
  getMaxLevel(){

    if(this.buID == 1)
      this.maxLevel = Array(5).fill(0);
    else if (this.buID == 2)
    this.maxLevel = Array(2).fill(0);
    else if (this.buID == 3)
    this.maxLevel = Array(6).fill(0);

    // this.http.get("http://localhost:29494/Test/MaxLevel", {
    //   params: { BuID: this.buID.toString() }
    // }).subscribe((res: any) => {
    //   this.maxLevel = res.level ? Array(res.level).fill(0) : [];
    // })
  }
  getFirstValue(){
    console.log(this.ptcSelectService.getFirstValue(this.groupName));

    console.log("getParnet => ", this.ptcSelectService.getParnet(3, this.groupName));
    console.log("getSelf => ", this.ptcSelectService.getSelf(3, this.groupName));
    console.log("chilred => ", this.ptcSelectService.getChildren(3, this.groupName));
  }
  getLastValue(){
    console.log(this.ptcSelectService.getLastValue(this.groupName));
  }
  getLastHasValue(){
    
    console.log("getLastHasValue => ", this.ptcSelectService.getLastHasValue(this.groupName))
  }

}
