import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TestSelect2Component } from './test-select2/test-select2.component';


import { AppRoutingModule } from './app-routing.module';
import { TestComponent } from './test/test.component';
import { PtcSelect2Module } from 'ptc-select2';

import { MatSelectModule, MatOptionModule, MatFormFieldModule } from '@angular/material';
import { DynamicSelectComponent } from 'src/shared/components/dynamic-select/dynamic-select.component';

@NgModule({
  declarations: [
    AppComponent,
    // Select2Component,
    // InfiniteScrollComponent,
    TestSelect2Component,
    TestComponent,
    DynamicSelectComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    

    PtcSelect2Module,
    MatSelectModule, MatOptionModule, MatFormFieldModule

    // MaterialCompnentModule,
    // ScrollDispatchModule,
    // PortalModule,
    // OverlayModule
  ],
  providers: [],
  bootstrap: [AppComponent]
  //schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule { }
