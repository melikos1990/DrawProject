
import { NgModule } from '@angular/core';
import { Router, RouterModule,  Routes } from '@angular/router';

import { TestSelect2Component } from './test-select2/test-select2.component';
import { TestComponent } from './test/test.component';

const route: Routes = [
    {path: '', component: TestSelect2Component},
    {path: 'test', component: TestComponent},
    {path: '*', redirectTo: ''},
] 



@NgModule({
    imports: [
        RouterModule.forRoot(route)
    ],
    exports: [
        RouterModule
    ]
})
export class AppRoutingModule {

}
