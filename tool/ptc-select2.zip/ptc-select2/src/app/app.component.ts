import { Component } from '@angular/core';
//import { SelectData } from './select2/select2.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ngPtcSelect2';

  constructor(){}
}
