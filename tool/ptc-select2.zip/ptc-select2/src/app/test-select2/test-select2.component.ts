import { Component, OnInit, ViewChild } from '@angular/core';

import { Router } from '@angular/router';
import { SelectData, Appearance, FloatLabel, SelectDataItem, PtcSelect2AjaxOptions, SelectCacheService } from 'ptc-select2';

import { of, Subject, Observable } from 'rxjs';
import { delay, map } from 'rxjs/operators';

import { PtcSelect2Component, PtcSelect2Service, ChangeInfo } from 'ptc-select2';


export class extension {
  roleId: string
  userId: string
}

@Component({
  selector: 'app-test-select2',
  templateUrl: './test-select2.component.html',
  styleUrls: ['./test-select2.component.scss']
})
export class TestSelect2Component implements OnInit {

  disabled: boolean = false;

  floatLabel: FloatLabel = 'never';
  matOptionClass="optionClass"
  selectData: SelectData;
  selectData2: SelectData;
  _multiple: boolean = true;
  _items;

  model: any;
  ngmodelTest: any = 
  {
    id: false,
    text: "item #1"
  };

  // data: SelectData = new SelectData(true, [
  //   {id: "1", text:"123"},
  //   {id: '2', text:"4516"},
  //   {id: 3, text:"qw1e"},
  //   {id: '4', text:"as1d"},
  // ])

  childSelect: any;
  child2Select: any;

  option: PtcSelect2AjaxOptions<extension> = {
    method: 'POST',
    url: 'http://localhost:28632/api/SelectTest/GetData',
    // url: 'http://localhost:45396/api/Test/SelectTest',
    pageIndex: 0,
    size : 30,
    criteria: {
      userId: "id-213",
      roleId: "roleid"
    }
  }

  // defaultSelected: SelectDataItem = {
  //   id: "1",
  //   text: "123",
  // };
  
  // default2Selected: SelectDataItem = {
  //   id: "123",
  //   text: "test",
  // };

  ngmodelMultTest: any;
  
  @ViewChild("heroForm") heroForm: any;
  @ViewChild("select212") select2: PtcSelect2Component;
  @ViewChild("select3") select3: PtcSelect2Component;

  constructor(
    private ptcService: PtcSelect2Service,
    private cacheService: SelectCacheService
  ){

    // this.model = 3;

    
    this.selectData = new SelectData(false, []);

    this.selectData2 = new SelectData(false, []);
    this.selectData.items = this.createItems(0, 100000);
  }

  ngOnInit(): void {
    console.log("heroForm => ", this.heroForm);

  }


  ngAfterContentInit(): void {
    setTimeout( () => {
      //console.log("cache data => ", this.tempService.tempData);
      //this.cacheService.pull();

      //console.log("select2 data => ", this.select2.token);
    }, 3000)

    this.select3.stateChange$.subscribe(state => {
      console.log(state);
    })

    // setTimeout(() => {
      
    // }, 0)
  }


  removeCacheData(){
    //this.cacheService.clean();
  }


  createItems(start: number, end: number){

    let items: SelectDataItem[] = [];
    for(var i = start; i < end; i++){
      items.push({
        id: i,
        text: "item #" + i,
      })
    }

    return items;
  }

  onItemChange(ev: ChangeInfo){
    let type = ev.type;
    let item = ev.item;

    console.log("type, item => ", type, item);
  }


  select(...values: any[]): void{
      console.log("values => ", values);
  }


  pullData(){
    
    console.log("select all => ", this.ptcService.ptcSelectAll);
    console.log(this.cacheService);
    this.cacheService.pull();
  }

}
