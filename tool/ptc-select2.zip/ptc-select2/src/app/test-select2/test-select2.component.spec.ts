import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestSelect2Component } from './test-select2.component';

describe('TestSelect2Component', () => {
  let component: TestSelect2Component;
  let fixture: ComponentFixture<TestSelect2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestSelect2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestSelect2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
