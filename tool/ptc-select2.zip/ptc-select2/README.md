# ptc-swal

###`import { PtcSelect2Module } from 'ptc-select2';`

###`npm install ptc-select2@latest`


## 描述


**整合內容** Select2



## 使用方式（範例）

> app.module.ts

```javascript

import { PtcSelect2Module } from 'ptc-select2';

@NgModule({
  declarations: [
    AppComponent,
  ],
  
  imports: [  
	 ...
    PtcSelect2Module //add this line.
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }


```


## 單選

> app.component.ts

```javascript

import { PtcSelect2Component } from 'ptc-select2';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {


    value: SelectDataItem;

    option = {
        method: 'GET',
        url: 'http://localhost:29494/Test/SelectTest',
        size : 30,
    }

}


```



> app.component.html


```html
    <ptc-select2
      placeholder="請選擇"
      chipColor="#ff4081"
      loadingText="資料查詢中..."
      spinnerColer="accent"
      [(ngModel)]="value"
      #select2
    >
    </ptc-select2>


```


## 多選 (加入 multiple 屬性)


> app.component.html


```html
    <ptc-select2
      placeholder="請選擇"
      chipColor="#ff4081"
      loadingText="資料查詢中..."
      spinnerColer="accent"
      [multiple]="true"
      [(ngModel)]="value"
      #select2
    >
    </ptc-select2>

```





## 連動


> app.component.html


```html

    <ptc-select2
      placeholder="請選擇"
      chipColor="#ff4081"
      loadingText="資料查詢中..."
      spinnerColer="accent"
      [(ngModel)]="value"
      [childDOM]="child"
      #select2
    >
    </ptc-select2>


    <ptc-select2
      placeholder="請選擇"
      chipColor="#ff4081"
      loadingText="資料查詢中..."
      spinnerColer="accent"
      [(ngModel)]="childValue"
      #child
    >
    </ptc-select2>

```




