

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { CacheData } from '../model/select2.model';




@Injectable({
    providedIn: 'root'
})
export class SelectCacheService {
    
    tempData: Map<string, CacheData>;

    watchData: Subject<Map<string, CacheData>>;

    constructor(){
        this.tempData = new Map();
        this.watchData = new Subject();
    }

    push(data: CacheData, key: string){
        if(this.check(key)){
            this.tempData.delete(key);
            this.tempData.set(key, {...data});
        }
        else{
            this.tempData.set(key, {...data});
        }
    }

    pull = () => this.watchData.next(this.tempData);


    clean(){
        this.tempData = new Map();
    }

    cleanByKey(key: string){
        if(this.check(key))
            this.tempData.delete(key);
    }


    check = (key: string) => this.tempData.has(key);
    

}

