import { Injectable } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { PtcSelect2Component } from '../ptc-select2.component';


@Injectable({
  providedIn: 'root'
})
export class PtcSelect2Service {

  private _selectModel: SelectionModel<PtcSelect2Component>;
  
  get ptcSelectAll() { return this._selectModel.selected; }

  constructor(

  ) { 
    this.init();
  }

  private init(){
    this._selectModel = new SelectionModel(true);
  }
  

  register(select2: PtcSelect2Component){
    
    if(this.check(select2)) return;

    this._selectModel.select(select2);

  }

  clear(select2: PtcSelect2Component){
    
    if(this.check(select2) == false) return;

    this._selectModel.deselect(select2);

  }

  /**
   * 取得指定階層的父選單
   * @param currentLevel 
   * @param groupName 群組名稱
   */
  getParnet(currentLevel: number, groupName: string = null){
    return this.getGearing(x => x.level == (currentLevel - 1) && x.groupName == groupName)[0];
  }

  /**
   * 取得指定階層的子選單
   * @param currentLevel 
   * @param groupName 群組名稱
   */
  getChild(currentLevel: number, groupName: string = null){
    return this.getGearing(x => x.level == (currentLevel + 1) && x.groupName == groupName)[0];
  }

  /**
   * 取得指定階層的所有子選單
   * @param currentLevel 
   * @param groupName 群組名稱
   */
  getChildren(currentLevel: number, groupName: string = null){
    return this.getGearing(x => x.level >= (currentLevel + 1) && x.groupName == groupName);
  }

  /**
   * 取得指定階層的選單
   * @param currentLevel 
   * @param groupName 群組名稱
   */
  getSelf = (currentLevel: number, groupName: string = null) => this.getGearing(x => x.level == currentLevel && x.groupName == groupName)[0]


  /**
   * 取得第一個選單的值
   * @param groupName 
   */
  getFirstValue(groupName: string = null){
    let data = this.getGearing(x => x.level == 1 && x.groupName == groupName)[0];
    return !!(data) ? data.selected : null;
  }

  /**
   * 取得最後一個選單的值
   * @param groupName 
   */
  getLastValue(groupName: string = null){
    let groupSelectAll = this.getGearing(x => x.groupName == groupName);
    let data = groupSelectAll[(groupSelectAll.length >= 0 ? groupSelectAll.length - 1 : 0)];
    return !!(data) ? data.selected : null;
  }

  /**
   * 取得最後一個選單的值(不為空的值)
   * @param groupName 
   */
  getLastHasValue(groupName: string = null){
    let allSelect = this.getGearing(x => x.groupName == groupName);
    let value = null;
    let reverse = [...allSelect].reverse();
    
    reverse.forEach(x => {
      if(x.selected && !value)
        value = x.selected;
    })
    
    return value;
  }


  /**
   * 清除所有已註冊的選單
   */
  clearAll = () => this._selectModel.clear();

  /**
   * 檢查選單是否存在
   */
  check = (select2: PtcSelect2Component) => this._selectModel.isSelected(select2)


  private getGearing(levelFn: (x) => boolean){
    return this._selectModel.selected.filter(levelFn);
  }
  

}
