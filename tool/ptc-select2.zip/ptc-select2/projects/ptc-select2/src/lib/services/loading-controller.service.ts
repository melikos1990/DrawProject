import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { SelectData } from '../model/select2.model';


@Injectable()
export class LoadingControllerService {


  loadingWait$: Subject<Observable<SelectData>>;

  constructor() { 
    this.loadingWait$ = new Subject<Observable<SelectData>>();
  }

  wait = (work$: Observable<SelectData>) => this.loadingWait$.next(work$);
  
}
