
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PtcSelect2AjaxOptions } from '../model/select2.model';
import { Observable, throwError } from 'rxjs';


@Injectable()
export class HttpService {

    constructor(private http : HttpClient){

    }

    excute<T extends object>(options : PtcSelect2AjaxOptions<T>) {
        
        let action: Observable<any>;

        if(options.method.toString().toLowerCase() == 'post')
        {
            action = this.post(options);
        }
        else if(options.method.toString().toLowerCase() == 'get')
        {
            action = this.get(options);
        }
        else  if(options.method.toString().toLowerCase() == 'request')
        {
            action = this.request(options);
        }
        else{
            return throwError(`not implement ${options.method.toString()}`);
        }

        return action;

    }


    request<T extends object>(options : PtcSelect2AjaxOptions<T>){ 

        let params = {
            pageIndex : options.pageIndex,
            size : options.size,
            parentID: options.parentID || "",
            // parentText: options.parentText || "",
            criteria: !!options.criteria && {...options.criteria}
        }

        return this.http.request(options.method, options.url, {
            body: params,
            headers: options.header,
        })

    }


    get<T extends object>(options : PtcSelect2AjaxOptions<T>) : Observable<any> {
        let params = {
            pageIndex : options.pageIndex.toString(),
            size : options.size.toString(),
            parentID: options.parentID || "",
            // parentText: options.parentText || "",
        }

        if(options.keyword) params["keyword"] = options.keyword

        return this.http.get<any>(options.url , {
            headers : options.header ,
            params
        })
    }

    post<T extends object>(options : PtcSelect2AjaxOptions<T>) : Observable<any>{

        let params = {
            pageIndex : options.pageIndex,
            size : options.size,
            parentID: options.parentID || "",
            // parentText: options.parentText || "",
            criteria: !!options.criteria && {...options.criteria}
        }

        if(options.keyword) params["keyword"] = options.keyword

        return this.http.post<any>(options.url , params,{
            headers : options.header,
            responseType : options.responseType
        })
    }


    httpLog(mesg: string){
        console.error(`Ptc-Select2 Error => ${mesg}`);
    }

}