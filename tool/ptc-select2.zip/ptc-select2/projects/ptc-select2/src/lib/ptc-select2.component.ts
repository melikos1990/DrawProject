import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter, forwardRef, ChangeDetectorRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

import { fromEvent, Observable, of, concat, Subscription, Subject } from 'rxjs';
import { debounceTime, tap, map, switchMap, distinctUntilChanged, filter, delay, catchError } from 'rxjs/operators';
import { LoadingControllerService } from './services/loading-controller.service';
import { MatSelect } from '@angular/material';
import { FloatLabel } from './material/material-component.module';
import { SelectCacheService } from './services/select-cache.service';
import { SelectData, SelectDataItem, PtcSelect2AjaxOptions, StateInfo } from './model/select2.model';
import { HttpService } from './services/http.service';

import { StateType } from './model/enum/stateType';
import { ConnectedPosition, CdkOverlayOrigin } from '@angular/cdk/overlay';
import { SelectModel } from './model/selection/selectModel';
import { ChangeType, CacheData } from './model';
import { PtcSelect2Service } from './services/ptc-select2.service';



const DEBUNCE_TIME: number = 350;
const OPEN_TAG = "LoadingOpen";
const CLOSE_TAG = "LoadingClose";
const ACTIONS = {
  KEYUP: "KEYUP",
  INFINITE: "INFINITE"
}
const DEFAULT_OPTIONS: PtcSelect2AjaxOptions<{}> = {
  method: 'GET',
  url: null,
  size : 30,
  pageIndex: 0,
  header: null,
  responseType: 'json',
  criteria: {}
} 

const _positionStrategy: ConnectedPosition[] = [
  {originX: 'start', originY: 'top', overlayX: 'start', overlayY: 'top'}
]

export const USER_PROFILE_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => PtcSelect2Component),
  multi: true
};

@Component({
  selector: 'ptc-select2',
  templateUrl: './ptc-select2.component.html',
  styleUrls: ['./ptc-select2.component.scss'],
  providers: [USER_PROFILE_VALUE_ACCESSOR, LoadingControllerService]
})
export class PtcSelect2Component implements OnInit, ControlValueAccessor {

  _selectModel: SelectModel<SelectDataItem>;

  
  @Input() positionStrategy: ConnectedPosition[] = _positionStrategy;

  /**
   * 是否才取ajax模式
   */
  @Input() ajaxMode: boolean = true;

  /**
   * http operator
   */
  @Input() fetch : (options: PtcSelect2AjaxOptions<{}>) => Observable<any>;

  /**
   * ajax options 
   */
  @Input() options: PtcSelect2AjaxOptions<{}> = null;

  /**
   * 是否 cache 資料 (true = 畫面離開自動cache資料)
   */
  @Input() cache: boolean = false;

  /**
   * Select2 ID
   */
  @Input() selectID: string;

  /**
   * 資料來源
   */
  @Input() selectData: SelectData = new SelectData(false, []);
  

  @Input() 
  set selectedItems(val: any){
    if(!val) return;

    setTimeout(() => {

      if(val instanceof Array){
        this._selectModel.select(...val);
      }
      else{
        this._selectModel.select(val);
      }
      
      this.synchronizeSelected();

    }, 0);
    
  }

  get selectedItems(){ return this._selectModel.selected;}

  /**
   * 一列的高度
   */
  @Input() rowHeight: number = 35;

  /**
   * 顯示多少列
   */
  @Input() displayRowNumber: number = 10;

  /**
   * 是否多選
   */
  @Input() multiple: boolean = false;

  /**
   * 提示文字
   */
  @Input() placeholder: string = "請選擇";

  /**
   * 提示文字
   */
  @Input() searchPlaceholder: string = "關鍵字搜尋";

  /**
   * menu class
   */
  @Input() menuClass: string = "select2-option-content";

  /**
   * overlay panel class
   */
  @Input() panelClass: string = "defaultPanel";

  /**
   * 續載無資料時 顯示的文字
   */
  @Input() noDataText: string = "無資料";


  @Input() disabled:  boolean = false;


  @Input() hasClearOption: boolean = false;

  @Input() clearText: string = "清空目前選項";

  /**
   * 資料載入時 顯示的文字
   */
  @Input() loadingText: string = "查詢資料中...";

  @Input() floatLabel: FloatLabel;
  @Input() matFieldClass: string | string[] = "";
  @Input() spinnerColer: string;
  @Input() chipColor: string = "";

  @Input() matOptionClass: string | string[] = null;

  /**
   * 是否啟用 連動行為
   */
  @Input() linkageEnable: boolean = false;

  /**
   * 本身所屬階層
   */
  @Input() level: number;

  /**
   * 連動所屬的群組名稱(當畫面上有2組以上連動選單時使用)
   */
  @Input() groupName: string = null;
  
  /**
   * keyup 事件
   */
  @Output() onKeyup: EventEmitter<object> = new EventEmitter<object>();

  /**
   * item 改變事件
   */
  @Output() onItemChange: EventEmitter<object> = new EventEmitter<object>();


  /**
   * Select2 狀態變化
   */
  stateChange$: Subject<StateInfo>;

  private currentAction: string;

  private onload$: Observable<any>;
  private cache$: Observable<any>;
  private openLoading$: Observable<any>;
  private closeLoading$: Observable<any>;
  private scrollOffset: number = 400;
  private _clearTrigger: boolean = null;

  get clearTrigger() { return this._clearTrigger; }

  /**
   * 所有 Subscription
   */
  private onkeyupSubscription$: Subscription;
  private onloadSubscription$: Subscription;
  private cacheSubscription$: Subscription;
  private onscrollSubscription$: Subscription;
  

  @ViewChild(CdkOverlayOrigin) origin: CdkOverlayOrigin;
  @ViewChild("select") select: MatSelect;

  /**
   * cdk Viewport Menu視窗
   */
  private _scroll: ElementRef<HTMLElement>;
  @ViewChild("scroll")
  set scroll(val: ElementRef<HTMLElement>) {
    if (val) {
      this._scroll = val;
      this.listenScroll();
    }
  };
  get scroll() { return this._scroll }

  // 搜尋條件
  @ViewChild("search") 
  set search(val: ElementRef<HTMLElement>){
    if(val){
      this.searchInput = val;
      this.listenSearch();
    }
  };

  searchInput: ElementRef<any>;

  

  set selected(items: SelectModel<SelectDataItem>){
    this._selected = this.multiple ? items.selected.map(x => x.id) : (!!items.selected[0] ? items.selected[0].id : null);
  }

  get selected(){
    return this._selected;
  }
  
  private _selected: any = null; // binding Data

  public _items: SelectDataItem[] = [];
  public _displayRowNumber: number;
  public _viewHeight: number;

  public isOpen: boolean = false;
  public isLoading: boolean = false;


  /**
   * 顯示多少列
   */
  get displayNumber() {

    let _displayNumber = (this._items.length >= this.displayRowNumber ? this.displayRowNumber : this._items.length);
    _displayNumber = this.hasClearOption ? _displayNumber + 1 : _displayNumber;

    return this._items.length == 0 ? 1 : _displayNumber;
  }

  constructor(public http: HttpService,
    public cacheService: SelectCacheService,
    public loadingCtrl: LoadingControllerService,
    private ptcSelectService: PtcSelect2Service,
    private changeDetectorRef: ChangeDetectorRef) 
    { 
      this.initProps();
    }


  ngOnInit(): void {
    console.log("ptc-select2 init");
    // this.options = {...DEFAULT_OPTIONS, ...this.options};
    this._displayRowNumber = this.displayNumber;
    this._selectModel = new SelectModel(((src, targe)  => src.id == targe.id), this.multiple);
  }

  ngOnDestroy(): void {

    this.ptcSelectService.clear(this); // 移除自己
    this.unSubscribe();      // 解除訂閱行為   
    this.trySettingCache();  // 嘗試設定CACHE

  }

  ngAfterViewInit(): void {

    this.constraint();        // 必要欄位之驗證
    this.observableHandler(); // 設定 observable stream
    this.subscribe();         // 訂閱 observable
    this.calcRows();        // 初始 rows

    this.stateChange({ state: StateType.Pedding });

    this.ptcSelectService.register(this);

    setTimeout(() => {
      this.select.options = null;
    }, 0)
  }

  initProps(){
    this.selectData = new SelectData(false, []);
    this.stateChange$ = new Subject<StateInfo>();
  }
  //disptch = () => this._scroll;

  /**
   * 預設 ajax 行為
   */
  defaultFetch =  (options: PtcSelect2AjaxOptions<{}>) : Observable<any> => {
    return this.http.excute(options);
  }



  /**
  * 必要欄位之驗證
  */
  constraint() {

    if(this.ajaxMode && !this.options){
      let error = new Error("options is null, " + this.options);
      this.stateChange({state: StateType.Error, error});
      throw error;
    }

    if (!this.ajaxMode && this.selectData.items.length <= 0 ) {
      let error = new Error("ajaxMode = false , selectData items 不能為空值, selectData: " + JSON.stringify(this.selectData));
      this.stateChange({ state: StateType.Error, error })
      throw error;
    }

    if(this.linkageEnable && !this.level){
      let error = new Error(`啟動連動時(linkageEnable) level 不能是空的 [level => ${this.level}]`);
      this.stateChange({ state: StateType.Error, error })
      throw error;
    }

    if (this.cache && !this.selectID) {
      let error = new Error("cache Data 必需要給 selectID 參數");
      this.stateChange({ state: StateType.Error, error })
      throw error;
    }

  }

  /**
   * 設定observable stream
   */
  observableHandler() {

    this.openLoading$ = of(OPEN_TAG).pipe(tap(x => this.openLoading()));

    this.closeLoading$ = of(CLOSE_TAG).pipe(tap(x => this.closeLoading()));

    this.onload$ = this.loadingCtrl.loadingWait$
      .pipe(
        debounceTime(DEBUNCE_TIME),
        switchMap(http$ => {
          let newObservble$ = http$.pipe(
            tap(g => {
              this.appendRows(g)
            })
          )
          return concat(this.openLoading$, newObservble$, this.closeLoading$)
            .pipe(
              catchError(err => {
                return of(new StateInfo(StateType.Error, null, err));
                }
              ))
        })
      )

    this.cache$ = this.cacheService.watchData
      .pipe(
        filter(x => !!(this.cache && this.selectID))
      )
  }

  /**
  * 解除訂閱observable
  */
  unSubscribe() {

    this.onkeyupSubscription$ && this.onkeyupSubscription$.unsubscribe();
    this.onloadSubscription$ && this.onloadSubscription$.unsubscribe();
    this.cacheSubscription$ && this.cacheSubscription$.unsubscribe();
    this.onscrollSubscription$ && this.onscrollSubscription$.unsubscribe();

  }

  /**
   * 訂閱 observable
   */
  subscribe() {

    // 當loading 行為時 , 進行後續行為
    this.onloadSubscription$ = this.onload$
          .subscribe((x: any) => {

            // 錯誤訊息 拋出狀態
            if(x instanceof StateInfo && x.state == StateType.Error){
              this.closeLoading();
              this.stateChange({ state: StateType.Error, error: x.error })
              return;
            }

            if (x != OPEN_TAG && x != CLOSE_TAG) {
              this.ajaxMode ? this.calcRows() : this.calcRows(x.items);
            }

          })


    // 當 cache 行為時 , 進行後續行為
    this.cacheSubscription$ = this.cache$.subscribe((map: Map<string, CacheData>) => {
      let data = map.get(this.selectID);
      
      if (!data) return;

      this.backFillCacheData(data);
      // this.appendRows(new SelectData(false, data.items));
      // this.calcRows();
    })

  }

  /**
  * key event
  * @param element 
  */
  emitKeyup(element: any) {
    let target = element.target;
    let keyword = target.value;

    this.currentAction = ACTIONS.KEYUP;
    this.options.pageIndex = 0;

    let options = this.deepCopyOptions(this.options);
    options.keyword = keyword;
    

    let fetch = this.fetch || this.defaultFetch;

    if(this.ajaxMode)
      this.loadingCtrl.wait(fetch(options))
    else
      this.loadingCtrl.wait(this.filterItem(keyword))
  }


  private filterItem(keyword: string){

    let lowerKeyword = keyword.toLowerCase();

    return of(1).pipe(
      map(_ =>  this.selectData.items.filter(x => x.text.toLowerCase().indexOf(lowerKeyword) >= 0)),
      map(items => new SelectData(true, items)),
      delay(500)
    )


  }

  backdropClick(event){
    this.closeMenu();
  }
  
  /**
   * 更新SelectData
   */
  appendRows(selectData: SelectData) {

    if(!this.ajaxMode) return;
    
    // 排除已選擇的選項
    // selectData.items = selectData.items.filter(x => !this.selectedItems.some(g => g.id == x.id));

    if (this.currentAction == ACTIONS.INFINITE)
      this.selectData.apply(selectData.items);
    else
      this.selectData.items = selectData.items;

    this.selectData.noData = (!!selectData.items && selectData.items.length <= 0) || selectData.noData;

  }

  /**
   * 計算 view Items 和 viewport 大小
   * @param selectData 
   */
  calcRows(items = this.selectData.items) {
    
    this._items = [...items];
    this.changeViewSize();

  }

  /**
   *  設定到cache 中
   */
  trySettingCache() {
    if (this.cache && this.selectID){
      this.cacheService.push(this.cacheData, this.selectID);
    }
  }


  /**
   * 開啟loading
   */
  openLoading() {
    this.isLoading = true;
    this.stateChange({ state: StateType.OnLoad });
    if (this.currentAction == ACTIONS.KEYUP) {
      this.changeViewSize(1);
      this._items = [];
    }
  }

  /**
   * 關閉loading
   */
  closeLoading() {
    if (this.isLoading == false) return;

    this.isLoading = false;
    this.currentAction = null;
    this.changeViewSize();

    this.stateChange({ state: StateType.Pedding })
  }

  /**
   * 關閉option menu
   */
  closeMenu() {
    this.isOpen = false;
    this.options.pageIndex = 0;

  }

  /**
   * 開啟option menu
   */
  openMenu() {
    
    // 鎖定 不開啟 menu
    if(this.disabled) return;

    if(this.isOpen) return;

    this.isOpen = true;

    let options = this.deepCopyOptions(this.options);

    let fetch = this.fetch || this.defaultFetch;
    
    if(!this.ajaxMode){
      this.loadingCtrl.wait(this.filterItem(''))
    }
    else{
      this.loadingCtrl.wait(fetch(options))
    }

  }


  removeAll(){
    this._selectModel.clear();
    this.synchronizeSelected();
    this.changeChildSelect();
    this.onItemChange.next({type: ChangeType.Clear});
    
    if(this.multiple) this.triggerOption();
    // if(!this.multiple) this.changeDetectorRef.markForCheck();
    // else this.triggerOption();
    

  }

  /**
   * 加入 mat-chip 元素
   * @param ev 
   */
  selectAdd(data: SelectDataItem) {

    this.searchInput.nativeElement.value = "";


    let isSelected = this._selectModel.isSelected(data);

    if(isSelected && this.multiple){
      this._selectModel.deselect(data);
      this.onItemChange.emit({type: ChangeType.Remove, item: data});
    } else {
      this._selectModel.select(data);
      this.onItemChange.emit({type: ChangeType.Selected, item: data});
    }

    

    this.synchronizeSelected(); 
    this.changeChildSelect();

    if(!this.multiple){
      setTimeout(() => {
        this.closeMenu();
      }, 150)
    }

  }

  /**
   * 設定連動 select 的資料
   */
  changeChildSelect(){

    if(!this.child) return;

    // 如果 select 屬於多選，就不異動連動select
    if(!this.linkageEnable || this.multiple) return;

    // 清空選擇的 options 並同步畫面
    this.child._selectModel.clear();
    this.child.synchronizeSelected();

    this.child.onChange(null);

    // 清空連動的 chile select2
    this.child.changeChildSelect();

  }

  optionDisable = (option: any) => {
    return this.multiple ? 
      this._selected.some(x => x == option.id) :
      this._selected == option.id;
  }
  

  changeViewSize = (displayRowNumber?: number) => {
    this._displayRowNumber = (displayRowNumber || this.displayNumber);
    let _viewHeight = this.rowHeight * this._displayRowNumber;
    
    if(_viewHeight != this._viewHeight){
      this._viewHeight = _viewHeight;
    }

  }


  /**
   * 監聽 選單目前看的到的 item (續載)
   * @param viewPortIndex 第一個 item Index
   */
  infinite() {
    
    this.options.pageIndex = this.options.pageIndex + 1;
    this.isLoading = true;
    this.currentAction = ACTIONS.INFINITE;
    
    let keyword = this.searchInput.nativeElement.value;
    let options = this.deepCopyOptions(this.options);
    
    if (keyword) {    
      options.keyword = keyword;     
    }
    let fetch = this.fetch || this.defaultFetch;

    this.loadingCtrl.wait(fetch(options))


  }

  originWidth = () => {
    return this.origin.elementRef.nativeElement.clientWidth;
  }

  trackByFn = (i, item) => { return item.id; }

  /**
   * 以下為 ControlValueAccessor 用
   */
  private _change: (value) => {};
  private onChange = (data: any) => this._change(data);

  writeValue(obj: any): void {


    if(typeof obj === "boolean" || obj){
      this._selected = obj

      if(!this.ajaxMode) this.backfill(this.selected);
    }
    
  }

  registerOnChange(fn: any): void {
    this._change = fn;
  }

  registerOnTouched(fn: any): void {
  }

  setDisabledState?(isDisabled: boolean): void {
  }

  private synchronizeSelected(){
    this.selected = this._selectModel;
    this.onChange(this.selected);


    setTimeout(() => {
      this.select.options = null;
    }, 0)
  }

  /**
   * 回填作業
   * @param ids 
   */
  private backfill(ids: any){
    if(typeof ids === "boolean" || ids){
      let selectData = [];
      if(ids instanceof Array)
        selectData = this.selectData.items.filter(x => ids.some(z => z == x.id));
      else
        selectData = this.selectData.items.filter(x => x.id == ids);

      selectData.forEach(data => this._selectModel.select(data));
    }
  }



  private stateChange = (state: StateInfo) => this.stateChange$.next(state)
  
  private listenScroll(){
    
    if(this.onscrollSubscription$){
      this.onscrollSubscription$.unsubscribe();
    }

    let scroll$ = 
        fromEvent(this.scroll.nativeElement, 'scroll')
        .pipe(
          debounceTime(300),
          distinctUntilChanged(),
          map(event => event.target),
          filter((elm: HTMLElement) => {
            let scrollHeight = elm.scrollHeight;
            let scrollTop = elm.scrollTop;
            return this.ajaxMode && !this.isLoading && (scrollTop >= (scrollHeight - this.scrollOffset));
          })
        )

    this.onscrollSubscription$ = scroll$.subscribe(event => {
        this.infinite();
    })

  }

  private listenSearch(){

    if(this.onkeyupSubscription$){
      this.onkeyupSubscription$.unsubscribe();
    }


    let search$ = fromEvent(this.searchInput.nativeElement, "keyup")
      .pipe(debounceTime(DEBUNCE_TIME), distinctUntilChanged());

    // 當輸入完畢後 , 進行後續行為
    this.onkeyupSubscription$ = search$.subscribe(element => {
      this.emitKeyup(element);
    })

  }

  /**
   * 觸發多選時 option UI
   */
  private triggerOption(){

    if(this.clearTrigger == null) this._clearTrigger = false;
    else this._clearTrigger = !this._clearTrigger;

  }

  private deepCopyOptions(options: PtcSelect2AjaxOptions<{}>){
    let _options = Object.assign({}, options);

    if(this.linkageEnable == false) return _options;

    // 取得父組件
    let parent = this.parnet;

    // && !this.multiple
    if(parent){
      _options.parentID = parent.selected;
    }

    return _options;
  }

  private backFillCacheData(data: CacheData){
    let { bindModel, criteria, parentID, parentText, displayItems } = data;
    this.options = {...this.options};

    this._selected = bindModel;
    // this.options.pageIndex = pageInfo.pageIndex;
    // this.options.size = pageInfo.size;
    this.options.criteria = criteria;
    this.options.parentID = parentID;
    // this.options.parentText = parentText;
    this.options.criteria = {...criteria};
    // this._items = [...items];
    this.selectedItems = !!(displayItems) ? displayItems : [];

  }

  get child(){ return this.ptcSelectService.getChild(this.level, this.groupName); }

  get parnet(){ return this.ptcSelectService.getParnet(this.level, this.groupName); }
  
  get children(){ return this.ptcSelectService.getChildren(this.level, this.groupName); }


  get cacheData(): CacheData{
    let pageIndex =  Math.round(this._items.length / this.options.size);
    pageIndex = pageIndex <= 0 ? 0 : pageIndex - 1;

    return {
      // pageInfo:{
      //   pageIndex: pageIndex,
      //   size: this.options.size
      // },
      displayItems: this.selectedItems,
      bindModel: this.selected,
      //items: this._items,
      criteria: {...this.options.criteria},
      parentID: this.options.parentID,
      // parentText: this.options.parentText
    }
  }

}
