
import { Component, Input, QueryList, OnChanges, ContentChildren, ChangeDetectionStrategy, SimpleChanges } from '@angular/core';
import { MatOption, MatOptionParentComponent, MAT_OPTION_PARENT_COMPONENT } from '@angular/material';

@Component({
    selector: "app-option-parent",
    template: '<ng-content></ng-content>',
    providers:[
        {provide: MAT_OPTION_PARENT_COMPONENT, useClass: OptionParentComponent}
    ],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OptionParentComponent implements MatOptionParentComponent, OnChanges {
    

    _selected: any[] = [];
    @Input() 
    set selected(val: any[]){
        if(val && val.length > 0){
            this._selected = val;
        }
    }
    get selected(){ return this._selected; }

    @Input() clearTrigger: boolean;
    
    private _trigger: boolean;

    multiple: boolean = true;

    disableRipple?: boolean;

    _options: QueryList<MatOption> = new QueryList();

    /** All of the defined select options. */
    @ContentChildren(MatOption, { descendants: true })
    set options(opts: QueryList<MatOption>) {
        if (opts && opts.length > 0) {
            this._options = opts;
            this.lazyCall(this.setSelected.bind(this))
        }
    }
    get options() { return this._options; }

    constructor() { }

    ngOnInit() {
        // console.log("OptionParentComponent ngOnInit", this.multiple);
    }

    ngOnChanges(changes: SimpleChanges): void {
        if(changes["clearTrigger"] && !changes["clearTrigger"].firstChange){
            if(changes["clearTrigger"].currentValue != this._trigger){
                this.deSelected();
                this._trigger = changes["clearTrigger"].currentValue;
            }
        }
    }

    ngOnDestroy(): void {

    }

    setSelected() {
        this.options.filter((x, index, array) => {
            return this.selected.some(id => id == x.value); //MatOption id = value, value = viewValue
        }).forEach(option => {
            option.select();
        });

    }

    private lazyCall = (callback: () => void) => {
        setTimeout(() => {
            callback();
        }, 0)
    }

    private deSelected(){
        this.options.forEach(option => {
            option.deselect();
        });
    }

}
