import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcSelect2Component } from './ptc-select2.component';

describe('PtcSelect2Component', () => {
  let component: PtcSelect2Component;
  let fixture: ComponentFixture<PtcSelect2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcSelect2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcSelect2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
