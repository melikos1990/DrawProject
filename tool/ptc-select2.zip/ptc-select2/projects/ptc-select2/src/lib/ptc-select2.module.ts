import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { PtcSelect2Component } from './ptc-select2.component';
import { InfiniteScrollComponent } from './infinite-scroll/infinite-scroll.component';

import { MaterialComponentModule } from './material/material-component.module';
import { ScrollDispatchModule, ScrollingModule } from '@angular/cdk/scrolling';
import { OverlayModule } from '@angular/cdk/overlay';
import { PortalModule } from '@angular/cdk/portal';
import { HttpClientModule } from '@angular/common/http';
import { LoadingControllerService } from './services/loading-controller.service';
import { HttpService } from './services/http.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OptionParentComponent } from './components/optionParent.component';

@NgModule({
  declarations: [
    PtcSelect2Component,
    InfiniteScrollComponent,
    OptionParentComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    MaterialComponentModule,
    ScrollDispatchModule,
    OverlayModule,
    PortalModule,
    ScrollingModule,
    FormsModule, ReactiveFormsModule
  ],
  exports: [
    
    PtcSelect2Component,
    InfiniteScrollComponent
  ],
  providers: [
    HttpService,
    //LoadingControllerService
  ],
  schemas: [NO_ERRORS_SCHEMA]
})
export class PtcSelect2Module { }
