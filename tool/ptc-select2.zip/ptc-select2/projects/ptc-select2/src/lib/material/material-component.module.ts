
import { NgModule } from '@angular/core';

import { 
  MatChipsModule, MatIconModule, MatFormFieldModule, 
  MatSelectModule, MatProgressSpinnerModule, MatGridListModule, 
  MatFormFieldAppearance, FloatLabelType, MatInputModule, MatOptionModule
 } from '@angular/material';



const MATERIAL_MODUEL = [
    MatChipsModule,
    MatIconModule, 
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatProgressSpinnerModule,
    MatGridListModule,
    MatInputModule
]

export type Appearance = MatFormFieldAppearance;

export type FloatLabel = FloatLabelType;

@NgModule({
  imports: [
    ...MATERIAL_MODUEL
  ],
  exports: [
    ...MATERIAL_MODUEL
  ],
})
export class MaterialComponentModule { }
