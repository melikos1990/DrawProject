import { Subject } from 'rxjs';


/**
 * SelectModel 是參照 angular material SelectionModel 的簡單實作，
 * 如行為複雜可用 angular material SelectionModel ，
 * 參考網址: 
 * https://github.com/angular/components/blob/master/src/cdk/collections/selection.ts
 */
export class SelectModel<T> {
    
    /**
     * 資料異動時的事件
     */
    onChange: Subject<T[]>;

    /**
     * 目前選擇的資料
     */
    get selected(){ return this._selection; }

    /**
     * 是否為多選
     */
    get multiple(){ return this._multiple; }

    /**
     * 比對機制
     * src = SelectModel array 原始資料，
     * dest = 新增/刪除 資料
     */
    get compareFn(){ return this._compareFn }

    private _compareFn: (item: T, dest: T) => boolean = null;

    private _selection: T[] = [];

    private _multiple: boolean = false;

    constructor(compare: (src: T, dest: T) => boolean, multiple: boolean = false){
        this.onChange = new Subject();
        this._compareFn = compare;
        this._multiple = multiple
    }

    /**
     * 選擇資料
     * @param values 
     */
    select(...values: T[]){
        values.forEach(item => this.append(item));

        this.cheange();

    }

    /**
     * 刪除資料
     * @param values 
     */
    deselect(...values: T[]){
        values.forEach(item => this.remove(item));

        this.cheange();
    }

    /**
     * 是否有資料
     */
    isSelected = (value: T) => {
        var _curryFn = this.curryFn(value);
        let idx = this._selection.findIndex(_curryFn);
        return idx > -1
    }


    clear = () => this._selection = [];
    

    private append(value: T){

        if(this._multiple){
            this._selection.push(value);
        }
        else{
            this._selection = [value];
        }


    }

    private remove(value: T){
        if(this.isSelected(value)){
            var idx = this.findIndex(value);
            this._selection.splice(idx, 1);
        }
    }


    private findIndex(dest: T) { 
        var _curryFn = this.curryFn(dest);
        return this._selection.findIndex(_curryFn)
    }

    private cheange = () => this.onChange.next(this._selection);

    private curryFn(dest: T){
        let cloneFn = this._compareFn;
        
        return (src) => {
            return cloneFn(src, dest);
        }
    }

}
