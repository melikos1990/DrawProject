

export enum StateType {

    OnLoad = "onLoad",

    Pedding = "Pedding",

    Error = "Error"

}
