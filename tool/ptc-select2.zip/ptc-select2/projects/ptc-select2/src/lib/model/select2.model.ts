import { StateType } from './enum/stateType';
import { ChangeType } from '.';


export * from './selection/selectModel';


export interface SelectDataItem {
  id: any;
  text: string;
  isSelected? :  boolean;
  extend?: any;
}

export class SelectData {


  constructor(public noData: boolean, public items: SelectDataItem[]) { }

  public apply(dataItem: SelectDataItem | SelectDataItem[]) {

    if (dataItem instanceof Array)
      this.items = [...this.items, ...dataItem];
    else
      this.items.push(dataItem);

  }

}

export class PtcSelect2AjaxOptions<T extends object> {

  keyword?: string;

  url : string;

  pageIndex: number;

  size: number;

  criteria?: T = Object.assign({});

  parentID?: any = null;

  // parentText?: string = null;

  header?: any;

  responseType?: any = 'json';

  method: 'POST' | 'GET' | 'PATCH' | 'HEAD' | 'PUT' | 'DELETE' | 'REQUEST' = 'GET';

}


export class OptionExtension {


}


export class StateInfo {

  constructor(_state: StateType, _message?: string, _error?: Error){
    this.state = _state;
    this.message = _message;
    this.error = _error;
  }

  state: StateType;

  message?: string;

  error?: Error;
}


export class ChangeInfo {
  type: ChangeType;
  item: SelectDataItem;
}


export class CacheData {
  
  /** ngModel */
  bindModel?: any;

  /** 顯示的itmes */
  displayItems?: any;
  
  /** 來源的itmes */
  //items: any[] = [];
  
  /** 頁面資訊 */
  // pageInfo: {
  //   pageIndex: number,
  //   size: number
  // }

  /** 擴充欄位 */
  criteria?: any;

  /** 父selectID  */
  parentID?: any;

  /** 父select Text  */
  parentText?: any;
}