
export enum ChangeType {
    Selected = "selected",
    Remove = "remove",
    Clear = "clear"
}
