/*
 * Public API Surface of ptc-select2
 */

export * from './lib/ptc-select2.component';
export * from './lib/ptc-select2.module';
export * from './lib/services';
export * from './lib/model';

export { Appearance, FloatLabel } from './lib/material/material-component.module';
