import { Action } from '@ngrx/store';
import { <%=classify(name)%> } from 'src/app/model/<%=dasherize(name).toLowerCase()%>.model'

export const DETAIL_ENTRY = '[<%= dasherize(name).toUpperCase() %>] DETAIL ENTRY';
export const LOAD_DETAIL = '[<%= dasherize(name).toUpperCase() %>] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[<%= dasherize(name).toUpperCase() %>] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[<%= dasherize(name).toUpperCase() %>] LOAD DETAIL FAILED';


export class detailEntryAction implements Action {
    readonly type = DETAIL_ENTRY;
    constructor(public payload : any ) { }
}

export class loadDetailAction implements Action {
    type: string = LOAD_DETAIL
    constructor(public payload : string){ }
}
export class loadDetailSuccessAction implements Action {
    type: string = LOAD_DETAIL_SUCCESS
    constructor(public payload : <%=classify(name)%>){ }
}
export class loadDetailFailedAction implements Action {
    type: string = LOAD_DETAIL_FAILED
    constructor(public payload : string){ }
}

export type Actions = detailEntryAction | 
                      loadDetailAction | 
                      loadDetailSuccessAction |
                      loadDetailFailedAction ;


