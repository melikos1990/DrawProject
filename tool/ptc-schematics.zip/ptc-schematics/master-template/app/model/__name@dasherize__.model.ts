export class <%=classify(name)%> {

}