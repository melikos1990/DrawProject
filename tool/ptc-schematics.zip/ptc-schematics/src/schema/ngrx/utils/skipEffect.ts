import { filter, Rule } from "@angular-devkit/schematics";



export function ignoreEffect(): Rule{
    return filter(x => {
      
      let pathArr = x.split("/");
      let dirName = pathArr[(pathArr.length - 2)];
  
      return dirName != "effects";
    })
  }

