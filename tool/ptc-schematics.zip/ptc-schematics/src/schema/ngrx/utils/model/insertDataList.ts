import { InsertChange } from '@schematics/angular/utility/change';
import { Tree, SchematicsException } from '@angular-devkit/schematics';
//import * as stringUtils from '../../../strings';
import { Mapping } from '../mapping';
import { KEYWORDS, KeyItem, TYPENAME } from '../mapping-config';

 

export class DataItem {
    type: string; 
    path: string;
    insertChanges: InsertChange[]
}

export class InserDataList {

    datas: DataItem[];

    constructor(className: string, paths: string[], host: Tree){
        this.datas = this.getDatas(className, paths, host);
    }

    private getDatas(className: string, paths: string[], host: Tree) {
        return paths.map(x => {
            let pathArr = x.split("/");
            let dirName = pathArr[(pathArr.length - 2)]; // 取得資料夾名稱
            let suffix: string;
            

            suffix = firstCharToUpperCase(dirName);
            let insertChanges = getInsertChanges(x, dirName, suffix, className, host);

            let dataItem = new DataItem();
            dataItem.type = suffix;
            dataItem.path = x;
            dataItem.insertChanges = insertChanges;

            return dataItem;
        })
    }

}


function getInsertChanges(path: string, type: string, suffix: string, className: string, host: Tree): InsertChange[]{

    let insertChanges: InsertChange[] = [];
    let content = host.read(path);

    if(content){

        let mapping = new Mapping();
        let typeToLowerCase = type.toLowerCase();

        let keywords: KeyItem[] = KEYWORDS[typeToLowerCase] as KeyItem[];
        
        keywords.forEach(keyword => {

            let index = getInsertPosIndex(content.toString(), keyword.key);
            if(index == -1) return;
    
            let getContent = mapping.getVal(keyword.key);
    
            let insertChange = new InsertChange(path, index, getContent(className, suffix));
            insertChanges.push(insertChange);
    
        })
    
        if(insertChanges.length <= 0) throw new Error(`找不到符合keyword: '${keywords.map(x => x.key).join(" or ")}' , path: ${path}`)
    
        let getImportContent = mapping.getVal((typeToLowerCase == TYPENAME.ACTIONS.toLowerCase() ? "actionInclude" : "include"));
        
        let importInsertChange = new InsertChange(path, 0, getImportContent(className, suffix));
        insertChanges.push(importInsertChange);
    
        return insertChanges;

    }
    else throw new Error(`找不到檔案!!, path: ${path}`)

    
}

function getInsertPosIndex(fileContent: string, keyword: string): number{
    let index = -1;

    if(fileContent.indexOf(keyword) != -1){
        // console.log(`contnetStr find '${keyword}' index: `, fileContent.indexOf(keyword));
        // console.log(`'${keyword}'.length: ` , keyword.length);
        index = fileContent.indexOf(keyword) + keyword.length;
    }

    return index;
}


function firstCharToUpperCase(type: string): string{
    let suffix = '';

    switch (type) {
        case "actions":
            suffix = TYPENAME.ACTIONS;
            break;
        case "effects":
            suffix = TYPENAME.EFFECTS;
            break;
        case "reducers":
            suffix = TYPENAME.REDUCERS;
            break;
        default:
            throw new SchematicsException("找不到指定資料夾, dirName: " + type);
    }

    return suffix;
}