import { Tree, SchematicContext } from '@angular-devkit/schematics';
import { InserDataList } from './model/insertDataList';
import { IndexTsFileDefaultContent } from './mapping-config';

import * as stringUtils from '../../../string';

export function insertIndexFile(path: string, options: any){
  
  //const rootPath = path + "/app/pages/" + "" + "/store/";
  const rootPath = `${path}/app/pages/${stringUtils.dasherize(options.parent)}/store/`;

  const actionPath = rootPath + "actions/index.ts";
  const effectPath = rootPath + "effects/index.ts";
  const reducerPath = rootPath + "reducers/index.ts";
  let allPath = [actionPath, reducerPath];

  return function(host: Tree, _context: SchematicContext){

    if(options.ignoreEffect == false) allPath.push(effectPath);

    // 沒檔案 建立index.ts
    allPath.forEach(path => {
      if(!host.exists(path))
        createIndexFile(host, path)
    })

    // 取得 insertDataList 物件, 整理 insert 的資料及位置
    let inserDataList = new InserDataList(options.name, allPath, host);

    // 開始 insert String 到 index.ts 
    inserDataList.datas.forEach(dataItem => {
      let updateRecorder = host.beginUpdate(dataItem.path);

      dataItem.insertChanges.forEach(insertItem => {
        updateRecorder.insertLeft(insertItem.pos, insertItem.toAdd);
      })

      host.commitUpdate(updateRecorder);
    })
    
    return host;
  };

}



function createIndexFile(host: Tree, path: string){
    let pathArr = path.split("/");
    let dirName = pathArr[(pathArr.length - 2)]; // 取得資料夾名稱
    let content;
    if(dirName == "actions")
      content = IndexTsFileDefaultContent.action
    else if(dirName == "effects")
      content = IndexTsFileDefaultContent.effect
    else if(dirName == "reducers")
      content = IndexTsFileDefaultContent.reducer
    else
      throw new Error("目錄結構不屬於 actions or effects or reducers 其中一個, 目錄為: "+ path)
  
    host.create(path, content);
  }
  