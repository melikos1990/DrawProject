import { PtcAjaxOptions } from './ptc-ajax-options';

export class PtcServerTableOptions {

    columns: any[] = [];

    pageSizeOptions : number[] = [5,10,20];

    pageSize : number ;

    pageIndex : number ;

    ajax : PtcAjaxOptions;


}


