
export class PtcServerTableRequest<T> {

    pageIndex : number ;

    pageSize : number ;

    criteria : T ;

    sort : string ;

    direction : string ;


}