import { PtcServerTableRequest } from './ptc-server-table-req';

export class PtcAjaxOptions {

    url : string ;

    method : 'POST' | 'GET' | 'PATCH' | 'HEAD' | 'PUT' | 'DELETE' = 'GET'

    body : PtcServerTableRequest<any> = new PtcServerTableRequest();

    headers : any;

    responseType : any =  'json';

}
