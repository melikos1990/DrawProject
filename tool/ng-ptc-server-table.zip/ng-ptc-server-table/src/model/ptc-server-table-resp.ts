import { MatTableDataSource } from '@angular/material';


export class PtcServerTableResponse<T> {


    constructor(){ }


    get wrap() {
        return new MatTableDataSource<T>(this.data);
    } 

    //wrap : any = null;

    data : T[] = [];

    isSuccess : boolean;

    totalCount : number = 0;

    extension : any;

    message : string;

    

}