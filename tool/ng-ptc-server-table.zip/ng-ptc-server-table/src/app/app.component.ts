import { Component, ViewChild } from '@angular/core';
import { PtcServerTableOptions } from 'src/model/ptc-server-table-options';
import { PtcAjaxOptions } from 'src/model/ptc-ajax-options';
import { PtcServerTableComponent } from 'src/core/ptc-server-table/ptc-server-table.component';
import { PtcServerTableRequest } from 'src/model/ptc-server-table-req';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {


  isLoading = false;

  @ViewChild('ptcServerTable') ptcServerTable: PtcServerTableComponent;
  

  opts = new PtcServerTableOptions();

  constructor(){
  
    this.opts.ajax = new PtcAjaxOptions();
    this.opts.ajax.url = 'http://10.2.123.63/SMARTII/api/System/SystemParameter/GetList/';
    this.opts.ajax.method = 'POST';
    this.opts.columns = [
      {
        text: '全選',
        name: 'p-check', // it will render checkbox
        disabled :  false,
        order : 'ID',
        //class : 'customWidthClass'
      },
      {
        text: '定義代號（ＩＤ）',
        name: 'ID',
        disabled :  false,
        order : 'ID',
        //class : 'customWidthClass'
      },
      {
        text: '定義代號（ＫＥＹ）',
        name: 'Key',
        disabled :  true,
        order : 'KEY',
        //class : 'customWidthClass'
      },
      {
        text: '值',
        name: 'Value',
        disabled :  true,
        order : 'VALUE',
        //class : 'customWidthClass'
      },
      {
        text: '敘述',
        name: 'Text', 
        disabled :  false,
        order : 'TEXT',
        class : 'customWidthClass'
      },
      
    ]
    this.opts.pageSizeOptions = [5, 10, 20];
    this.opts.pageSize = 20;
    this.opts.pageIndex = 0;
    
  }

  beforeAjax($event){
    this.isLoading = true;
    alert('before ajax')
  }

    
  onAjax($event : PtcServerTableRequest<any>) {
    alert('onAjax' + JSON.stringify($event));
    
    let objA = {
      Name : 'chenhungtzu',
      Phone : '0926366680'
    }
    $event.criteria = objA 
  }

  rowSelect($event){
    console.log($event);

  }

  onAjaxSuccess($event){
    this.isLoading = false;
    alert('after ajax success'+ JSON.stringify($event))
  }
  
  onAjaxError($event){
    this.isLoading = false;
    alert('after ajax error'+ JSON.stringify($event))
  }
  onBtnDelete($event){
    alert('delete' + JSON.stringify($event))
  }

  onBtnSearch($event){
    alert('serach'+ JSON.stringify($event))
  }

  onBtnEdit($event){
    alert('edit'+ JSON.stringify($event))
  }

  onPageChange($event) {
    alert('page change' + JSON.stringify($event));
  }

  getSelectItem($event){
    alert('select' + this.ptcServerTable.getSelectRows())
  }
 
  setRangeLabel(page: number, pageSize: number, length: number): string {
    if (length == 0 || pageSize == 0) {
      return `0 of ${length}`;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `第 ${startIndex + 1}筆 - 第 ${endIndex} 筆 , 共 ${length} 筆資料`;
  }

  render($event){
    this.ptcServerTable.reset();
    this.ptcServerTable.render();
  }

  reset($event){
    this.ptcServerTable.reset();
  }

  


}
