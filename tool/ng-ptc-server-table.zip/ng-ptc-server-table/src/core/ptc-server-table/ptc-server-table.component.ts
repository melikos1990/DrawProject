import { Component, OnInit, ViewChild, Input, TemplateRef} from '@angular/core';
import { MatSort, MatPaginator, MatTable } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { PtcBaseServerTableComponent } from '../ptc-base-server-table/ptc-base-server-table.component';
import { PtcHttpService } from '../../service/ptc-http-service';
import { catchError } from "rxjs/operators"
import { of, Observable } from 'rxjs';
import { PtcServerTableResponse } from '../../model/ptc-server-table-resp';
import { PtcServerTableRequest } from '../../model/ptc-server-table-req';
import { TableBtnOrderType } from '../../model/table.model';

@Component({
  selector: 'app-ptc-server-table',
  templateUrl: './ptc-server-table.component.html',
  styleUrls: ['./ptc-server-table.component.scss']
})
export class PtcServerTableComponent extends PtcBaseServerTableComponent implements OnInit {
  

  public ajaxResp: PtcServerTableResponse<any> = new PtcServerTableResponse();

  selection = new SelectionModel<any>(true, []);

  currentPageIndex : number;
  currentPageSize : number;
  currentSort : string;
  currentDirection : string;
  

  defaultOrder : string;

  @ViewChild(MatTable) table: MatTable<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
 

  @Input() height: string;


  @Input() defaultOrderIndex? : number; 
  @Input() noDataLabel: string = '無資料'
  @Input() lastPageLabel: string;
  @Input() nextPageLabel: string;
  @Input() previousPageLabel: string;
  @Input() firstPageLabel: string;
  @Input() itemsPerPageLabel: string = '分頁筆數';

  @Input() templateRefs: any = {};

  @Input() setRangeLabel: (page: number, pageSize: number, length: number) => string;

  /**
  * 取得名稱定義
  */
  get columnDefList(): string[] {
    return this.options.columns.map(x => x.name);
  }

  /**
   * 取得總共頁數
   */
  get totalPageList() : number[] {

    let result : number[] = [];

    for(let i = 0 ;
        i < (this.ajaxResp.totalCount/this.currentPageSize) ;
        result.push(i) , i ++);

    return result;

  }

  constructor(private httpService: PtcHttpService) {
    super();
    
  }
  

  ngOnInit() {
    this._build()

  }


  /**
   * 設定控制字樣
   */
  private _setControlLabel() {
    this.paginator._intl.itemsPerPageLabel = this.itemsPerPageLabel;
    this.paginator._intl.lastPageLabel = this.lastPageLabel;
    this.paginator._intl.nextPageLabel = this.nextPageLabel;
    this.paginator._intl.previousPageLabel = this.previousPageLabel;
    this.paginator._intl.firstPageLabel = this.firstPageLabel;
  }

  /**
   * 設定顯示字樣
   * @param page 
   * @param pageSize 
   * @param length 
   */
  private _setRangeLabel(page: number, pageSize: number, length: number): string {
    if (length == 0 || pageSize == 0) {
      return `0 of ${length}`;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} of ${length}`;
  }

  /**
  * 設定分頁字樣
  */
  private _setPagingator() {

    this._setControlLabel();
    this.paginator._intl.getRangeLabel =
      this.setRangeLabel || this._setRangeLabel;
    this.ajaxResp.wrap.paginator = this.paginator

  }

  /**
   * 設定起始參數
   */
  private _setInitalizeParameter(){
    this.currentPageIndex = this.options.pageIndex;
    this.currentPageSize = this.options.pageSize;
    this.defaultOrder = this.options.columns[this.defaultOrderIndex || 0].order;
  }

  /**
   * 檢查instance
   */
  private _isActiveElement() {
    return this.sort && this.paginator && this.table
  }



  /**
   * 選擇頁數
   * @param $event 
   */
  selectPage($event) {
    if ($event) {
    
      if (this._isActiveElement()) {
        this.currentPageIndex = $event;
        this.paginator.page.next({
          pageIndex: this.currentPageIndex,
          pageSize: this.currentPageSize,
          length: this.paginator.length
        });
      }   
    }
  }

  /**
   * 當頁數改變時 , 回呼事件
   * @param $event 
   */
  pageChange($event) { 
   
    this.currentPageIndex = $event.pageIndex;
    this.currentPageSize = $event.pageSize;
  
    this.render();
    this.onPageChange.emit($event);
  } 

  rowSelect($event){
    
    this.onRowSelect.emit($event);
  }

  /**
   * 當排序改變時 , 回呼事件
   * @param $event 
   */
  headerChange($event) {
   
    this.currentSort = this._order($event.active) ;
    this.currentDirection = $event.direction;
    this.render();
    this.onHeaderChange.emit($event); 
  }

  /**
   * 於 “p-operator” 時生效
   * 按下編輯按鈕回呼事件
   * @param $event 
   */
  btnEdit($event) {
    console.log($event);
    this.onBtnEdit.emit($event);
  }

  /**
  * 於 “p-operator” 時生效
  * 按下檢視按鈕回呼事件
  * @param $event 
  */
  btnSearch($event) {
    console.log($event);
    this.onBtnSearch.emit($event);
  }

  /**
   * 於 “p-operator” 時生效
   * 按下刪除按鈕回呼事件
   * @param $event 
   */
  btnDelete($event) {
    console.log($event);
    this.onBtnDelete.emit($event);
  }


  /**
  * 於 “p-check 時生效
  * 檢核是否全選
  */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows =  this.ajaxResp.wrap.data.length;
    return numSelected === numRows;
  }

  /**
  * 於 “p-check 時生效
  * 勾選項目時加入物件控制
  */
  masterToggle() {
    this.isAllSelected() ?
      this.clearSelectItems() :
      this.ajaxResp.wrap.data.forEach(row => this.selection.select(row));
  }


  /**
  * 於 “p-check 時生效
  * 樣式變化
  */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  /**
   * 於 “p-check 時生效
   * 取得已選項目
   */
  getSelectRows(): any {
    return this.selection.selected;
  }

  /**
  * 於 “p-check 時生效
  * 清除勾選項目
  */
  clearSelectItems(): any {
    this.selection.clear();
  }

  /**
   * 設定表頭Component
   */
  private _setSortHeader() {
    this.ajaxResp.wrap.sort = this.sort;
  }


  /**
   * 重新設置表格
   */
  reset(){
    
    this.ajaxResp = new PtcServerTableResponse();
    this._build();
  }

  /**
   * 初始行為
   */
  private _build() {
    if (this._isActiveElement()) {
      this._setInitalizeParameter();
      this._setSortHeader();
      this._setPagingator();
    }
  }

  private _order(active){

    if(!active) return this.defaultOrder;
    
    const activeColumn = this.options.columns.find(x=> x.name === active);
    
    if(activeColumn) {
      return activeColumn.order;
    }else {
      return this.defaultOrder;
    }
  }

  private _refillPaginator(){
    this.paginator.pageIndex = this.currentPageIndex;
    this.paginator.pageSize = this.currentPageSize;

  }

  /**
   * 設置ajax data
   */
  private _setAjaxData(){

    let data = new PtcServerTableRequest<any>();
  
    data.sort = this.currentSort || this.defaultOrder;
    data.direction = this.currentDirection;
    data.pageIndex = this.currentPageIndex;
    data.pageSize = this.currentPageSize;

    this.options.ajax.body = data;

    this.onAjax.emit(this.options.ajax.body);
  }

  /**
   * 錯誤時 handler
   */
  private _ajaxErrorHandler = (error : any) : Observable<any> => {
    this.onAjaxError.emit(error);
    return of(error);
  } 

  /**
   * 成功時 handler
   */
  private _ajaxSuccessHandler = (source : any) => {

    this.ajaxResp = new PtcServerTableResponse();
    this.ajaxResp.data = source.data;
    this.ajaxResp.isSuccess = source.isSuccess;
    this.ajaxResp.totalCount = source.totalCount;

    this._refillPaginator();
    this.onAjaxSuccess.emit(source);
  }


  /**
   * 渲染資料
   */
  render() {

      this.clearSelectItems();

      this.beforeAjax.emit();

      this._setAjaxData();     
      
      this.httpService
          .getSourceData<any>(this.options.ajax)
          .pipe(catchError(this._ajaxErrorHandler))
          .subscribe(this._ajaxSuccessHandler) 
  }

  /**
  * 設定按鈕位置
  * @param idx 
  */
 btnClassSetting(idx: any) {
  let classString: string;

  switch (idx) {
    case 0:
      classString = "btnLeft"
      break;
    case 1:
      classString = "btnCenter"
      break;
    case 2:
      classString = "btnRight"
      break;

    default:
      break;
  }
  return classString;
}

  
}
