import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcServerTableComponent } from './ptc-server-table.component';

describe('PtcServerTableComponent', () => {
  let component: PtcServerTableComponent;
  let fixture: ComponentFixture<PtcServerTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcServerTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcServerTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
