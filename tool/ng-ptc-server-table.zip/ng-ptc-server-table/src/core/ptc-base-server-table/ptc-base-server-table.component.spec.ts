import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcBaseServerTableComponent } from './ptc-base-server-table.component';

describe('PtcBaseServerTableComponent', () => {
  let component: PtcBaseServerTableComponent;
  let fixture: ComponentFixture<PtcBaseServerTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcBaseServerTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcBaseServerTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
