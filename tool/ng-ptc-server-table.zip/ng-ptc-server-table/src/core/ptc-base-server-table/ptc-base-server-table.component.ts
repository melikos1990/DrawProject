import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { PtcServerTableOptions } from '../../model/ptc-server-table-options';
import { TableBtnOrderType } from '../../model/table.model';

@Component({
  selector: 'app-ptc-base-server-table',
  templateUrl: './ptc-base-server-table.component.html',
  styleUrls: ['./ptc-base-server-table.component.scss']
})
export class PtcBaseServerTableComponent {

  public tableBtnOrderType = TableBtnOrderType;

  @Input() options : PtcServerTableOptions;
  

  /**
   * 當ROW選取時
   */
  @Output() onRowSelect : EventEmitter<any> = new EventEmitter<any>();
  /**
   * 頁面切換傳出事件
   */
  @Output() onPageChange: EventEmitter<any> = new EventEmitter();
 
  /**
   * 排序切換傳出事件
   */
  @Output() onHeaderChange: EventEmitter<any> = new EventEmitter();
  /**
   * 檢視按鈕傳出事件
   */
  @Output() onBtnSearch: EventEmitter<any> = new EventEmitter();


  /**
   * 當ajax 發生錯誤時
   */
  @Output() onAjaxError : EventEmitter<any> = new EventEmitter();

  /**
   * 當ajax 進行之前
   */
  @Output() beforeAjax : EventEmitter<any> = new EventEmitter();

  /**
   * 當ajax 執行成功後
   */
  @Output() onAjaxSuccess : EventEmitter<any> = new EventEmitter();

  /**
   * 當 ajax 執行中
   */
  @Output() onAjax : EventEmitter<any> = new EventEmitter();

  /**
   * 是否顯示查詢按鈕
   */
  @Input() isVisibleBtnSearch: boolean = true;

  /**
   * 刪除按鈕傳出事件
   */
  @Output() onBtnDelete: EventEmitter<any> = new EventEmitter();

  /**
    * 是否顯示刪除按鈕
    */
  @Input() isVisibleBtnDelete: boolean = true;

  /**
   * 編輯按鈕傳出事件
   */
  @Output() onBtnEdit: EventEmitter<any> = new EventEmitter();

  /**
    * 是否顯示編輯按鈕
    */
  @Input() isVisibleBtnEdit: boolean = true;
  
  /**
   * 編輯按鈕字樣
   */
  @Input() btnEditText : string = '編輯'
  /**
   * 檢視按鈕字樣
   */
  @Input() btnSearchText : string = '檢視'
  /**
   * 刪除按鈕字樣
   */
  @Input() btnDeleteText : string = '刪除'

  /**
   * 是否顯示底部 
   */
  @Input() isVisibleFooter : Boolean = true ;

  @Input() btnOrderSetting: TableBtnOrderType[] = [this.tableBtnOrderType.Search, this.tableBtnOrderType.Edit, this.tableBtnOrderType.Delete];

  constructor() { }

  getSelectRows(): any[] {
     throw new Error('no implement getSelectRows');
  }
}
