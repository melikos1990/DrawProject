import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PtcServerTableComponent } from './ptc-server-table/ptc-server-table.component';
import { PtcBaseServerTableComponent } from './ptc-base-server-table/ptc-base-server-table.component';
import { HttpClientModule } from '@angular/common/http';
import { CdkTableModule} from '@angular/cdk/table';
import { 
  MatButtonModule,
  MatCheckboxModule,
  MatIconModule,
  MatInputModule,
  MatPaginatorModule, 
  MatSelectModule, 
  MatSortModule, 
  MatTableModule,
} from '@angular/material';
import { PtcHttpService } from '../service/ptc-http-service';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    PtcServerTableComponent, 
    PtcBaseServerTableComponent
  ],
  providers : [
    PtcHttpService
  ],
  exports :[
    PtcServerTableComponent, 
    PtcBaseServerTableComponent,
    
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    CdkTableModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatSortModule,
    MatTableModule,
    
  ]
})
export class PtcServerTableModule { }
