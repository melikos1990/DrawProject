import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PtcAjaxOptions } from '../model/ptc-ajax-options';
import { PtcServerTableResponse } from '../model/ptc-server-table-resp';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

@Injectable()
export class PtcHttpService {

    constructor(private http : HttpClient){

    }

    getSourceData<T>(options : PtcAjaxOptions) : Observable<PtcServerTableResponse<T>> {
        return this.http.request<PtcServerTableResponse<T>>(options.method , options.url, {
            body : options.body,
            headers : options.headers,
            responseType : options.responseType
        }).pipe(
            map(resp => resp)
        )
    }


}