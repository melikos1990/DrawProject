﻿using System.Web.Http;
using SMARTII.Assist.Authentication;
using SMARTII.Assist.Web;

namespace SMARTII._21Century.Controllers
{
    [Authentication]
    [RoutePrefix("Api/21Century")]
    public class _21Century_MasterController : BaseApiController
    {
        [Route("Get")]
        [HttpGet]
        public void Get()
        {
        }
    }
}
