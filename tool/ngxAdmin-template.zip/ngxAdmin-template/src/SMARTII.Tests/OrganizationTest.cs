﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ptc.Data.Condition2;
using Ptc.Data.Condition2.Mssql.Class;
using SMARTII.App_Start;
using SMARTII.Configuration;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Data;
using SMARTII.Domain.Organization;

namespace SMARTII.Tests
{
    [TestClass]
    public class OrganizationTest
    {
        public OrganizationTest()
        {
        }
        [TestMethod]
        public void Test_Calc_PageAuth()
        {

            // 初始化Autofac
            var container = DIConfig.Init();

            // 初始化AutoMapper
            MapperConfig.Init(container);

            // 初始化MSSQL CONDITION
            DataAccessConfiguration.Configure(Condition2Config.Setups);

            DIBuilder.SetContainer(container);
            IOrganizationAggregate c = DIBuilder.Resolve<IOrganizationAggregate>();
            IUserAuthenticationManager b = DIBuilder.Resolve<IUserAuthenticationManager>();

            var con = new MSSQLCondition<USER>(x => x.USER_ID == "e855a36b-7168-416a-9e97-1ce85e676285");
            con.IncludeBy(x => x.ROLE);
            var user = c.User_T1_T2_.Get(con);
            var role = user.Roles.FirstOrDefault();
            var result = b.GetCompleteMergedPageAuth(role.Feature, user.Feature);


        }

        [TestMethod]
        public void Flatten_Nested_node()
        {
            var tree = new CCNode()
            {
                NodeID = 0,
                Name = "root"
            };

            tree.Children.Add(new CCNode()
            {
                NodeID = 1,
                Name = "root-1",
                Children = new List<Domain.Common.INestedModel>()
                {
                    new CCNode(){
                         NodeID = 2,
                         Name = "root-1-1",
                    },
                    new CCNode(){
                         NodeID = 3,
                         Name = "root-1-2",
                    }
                }
            });

            tree.Children.Add(new CCNode()
            {
                Name = "root-2",
                NodeID = 4,
                Children = new List<Domain.Common.INestedModel>()
                {
                    new CCNode(){
                         NodeID = 5,
                         Name = "root-2-1",
                            Children = new List<Domain.Common.INestedModel>(){
                                new CCNode(){
                                    NodeID = 6,
                                    Name = "root-2-1-1"
                                }
                            }
                    },
                    new CCNode(){
                        NodeID = 7,
                            Name = "root-2-2",
                    },
                    new CCNode(){
                        NodeID = 8,
                            Name = "root-2-3",
                    }
                }
            });

            var flatten = tree.Flatten();

            var ccnodes = new List<CCNode>()
            {
                new CCNode()
                {
                    NodeID = 0,
                    LeftBundory = 1,
                    RightBundory = 14,
                    Name = "root"
                },
                new CCNode()
                {
                    NodeID = 1,
                    LeftBundory = 2,
                    RightBundory =5,
                    Name = "root-1"
                },
                  new CCNode()
                {
                    NodeID = 2,
                    LeftBundory = 6,
                    RightBundory =13,
                    Name = "root-2"
                },
                new CCNode()
                {
                    NodeID = 3,
                    LeftBundory = 3,
                    RightBundory =4,
                    Name = "root-1-1"
                },
                 new CCNode()
                {
                    NodeID = 4,
                    LeftBundory = 7,
                    RightBundory =12,
                    Name = "root-2-1"
                },
                   new CCNode()
                {
                    NodeID = 5,
                    LeftBundory = 8,
                    RightBundory =9,
                    Name = "root-2-1-1"
                },
                    new CCNode()
                {
                    NodeID = 6,
                    LeftBundory = 10,
                    RightBundory =11,
                    Name = "root-2-1-2"
                },
            };

            var nested = ccnodes.AsNested();
        }
    }
}
