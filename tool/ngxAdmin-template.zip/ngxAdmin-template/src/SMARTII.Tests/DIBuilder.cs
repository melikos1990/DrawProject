﻿using Autofac;
using SMARTII.ASO.DI;
using SMARTII.Assist.DI;
using SMARTII.Configuration.DI;

namespace SMARTII.Tests
{
    public static class DIBuilder
    {
        private static IContainer _Container;

        private static void Initialize()
        {
            EntryBuilder.RegisterModule(new ServiceModule());
            EntryBuilder.RegisterModule(new ASOModule());
            EntryBuilder.RegisterModule(new WebModule());

            _Container = EntryBuilder.Build();
        }

        public static void SetContainer(IContainer container)
        {
            _Container = container;
        }


        public static T Resolve<T>()
        {
            if (_Container == null)
                Initialize();


            return _Container.Resolve<T>();
        }
    }
}
