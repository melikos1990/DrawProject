﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Globalization;
using System.Linq;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SMARTII.Assist.Authentication;
using SMARTII.Assist.Logger;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Organization;
using SMARTII.Resource.Tag;

namespace SMARTII.Tests
{
    [TestClass]
    public class AuthorizationTest
    {
        public AuthorizationTest()
        {
        }

        [TestMethod]
        public void Test_Create_Token()
        {
            var user = new User()
            {
                Account = "ptc12876266",
                Name = "ptc"
            };

            var token = DIBuilder.Resolve<ITokenManager>().Create(user, null);

            var tuser = DIBuilder.Resolve<ITokenManager>().Parse<User>(token);


        }

        [TestMethod]
        public void Test_AD_Valid()
        {
            var helper = new LDAPHelper();

            var user = helper.FindOne("motx2152000");

            List<ADUser> userList = helper.FindAll(string.Empty);
            var s = userList.FirstOrDefault(x => x.userprincipalname == "rshov0123");
        }


        [TestMethod]
        public void Test_Get_Features()
        {
            Assembly[] assemblies = new Assembly[]
            {
              Assembly.Load("SMARTII"),
              Assembly.Load("SMARTII.ASO"),
              Assembly.Load("SMARTII.21Century"),
            };


            Dictionary<string, string> dict = new Dictionary<string, string>();

            var s = assemblies.FirstOrDefault().GetExportedTypes().Where(x => x.Name.Contains("Controller"));


            foreach (var assem in assemblies)
            {

                var ctrlTypes = assem.GetExportedTypes().Where(x => x.Name.Contains("Controller"));

                foreach (var type in ctrlTypes)
                {

                    var methods = type.GetMethods();



                    methods.ToList().ForEach(x =>
                    {
                        var attr = x.GetCustomAttribute<LoggerAttribute>();

                        if (attr == null) return;

                        var ch = Feature.ResourceManager.GetString(attr.FeatureTag, new CultureInfo("zh-TW", false));

                        dict.Add(ch, attr.FeatureTag);

                    });






                }


            }


            

        }




    }
}
