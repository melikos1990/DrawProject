﻿using SMARTII.Domain.Notification;
using System;


namespace SMARTII.Service.Notification
{
    public class MobilePushFactory : INotificationFactory
    {
        public void Send(IPayload payload)
        {
            throw new NotImplementedException();
        }
    }
}
