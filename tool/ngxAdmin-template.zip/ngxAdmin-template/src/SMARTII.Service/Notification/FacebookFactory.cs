﻿using System;
using SMARTII.Domain.Notification;

namespace SMARTII.Service.Notification
{
    public class FacebookFactory : INotificationFactory
    {
        public void Send(IPayload payload)
        {
            throw new NotImplementedException();
        }
    }
}
