﻿using SMARTII.Domain.Notification;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Service.Notification
{
    public class SMSFactory : INotificationFactory
    {
        public void Send(IPayload payload)
        {
            throw new NotImplementedException();
        }
    }
}
