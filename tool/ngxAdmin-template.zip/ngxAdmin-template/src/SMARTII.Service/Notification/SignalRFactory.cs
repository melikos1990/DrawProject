﻿using SMARTII.Domain.Notification;
using SMARTII.Domain.IO;

namespace SMARTII.Service.Notification
{
    public class SignalRFactory : INotificationFactory
    {

        private readonly ISignalRConnection _Connection;

        public SignalRFactory(ISignalRConnection Connection)
        {
            _Connection = Connection;
        }

        public void Send(IPayload payload)
        {
            // cast payload

            this._Connection.PushAllUser("push");
        }
    }
}
