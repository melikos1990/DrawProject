﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Ptc.Data.Condition2.Mssql.Class;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Cache;
using SMARTII.Domain.Data;
using SMARTII.Domain.IO;
using SMARTII.Domain.Organization;
using SMARTII.Domain.Security;
using SMARTII.Domain.Thread;
using SMARTII.Resource.Error;
using SMARTII.Resource.Tag;

namespace SMARTII.Service.Organization
{
    public class UserService : IUserService
    {

        private IOrganizationAggregate _OrganizationAggregate { get; set; }

        private IUserAuthenticationManager _UserAuthenticationManager { get; set; }

        public UserService(IOrganizationAggregate OrganizationAggregate,
                           IUserAuthenticationManager UserAuthenticationManager)
        {

            _OrganizationAggregate = OrganizationAggregate;
            _UserAuthenticationManager = UserAuthenticationManager;

        }
        /// <summary>
        /// 建立人員資訊
        /// </summary>
        /// <param name="user"></param>
        /// <param name="roleIDs"></param>
        /// <returns></returns>
        public async Task RegiestAsync(User user, int[] roleIDs)
        {


            if (user.IsAD)
            {
                // 如果是AD 帳戶 , 就必須驗證合法性
                if (_UserAuthenticationManager.IsADUser(user.Account, user.Password) == false)
                    throw new Exception(Error.AD_USER_NULL);

            }
            else
            {
                // 給予預設帳號
                // 使用者初次登入時需給予該組預設帳號進行設置
                user.Password = SecurityCache.DefaultPassword.Md5Hash();

                // 重設註記, 標註鎖定時間
                user.LastChangePasswordDateTime = null;
            }


            _OrganizationAggregate.User_T1_T2_.Operator(context =>
            {

                var db = (SMARTIIEntities)context;
                db.Configuration.LazyLoadingEnabled = false;

                var query = db.USER.Include("ROLE")
                                   .Where(x => x.ACCOUNT.ToLower() == user.Account.ToLower())
                                   .FirstOrDefault();

                if (query != null)
                    throw new Exception(Error.ACCOUNT_EXIST);


                var entity = AutoMapper.Mapper.Map<USER>(user);
                entity.CREATE_DATETIME = DateTime.Now;
                entity.CREATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;

                if (user.Picture != null)
                {
                    // 該目錄需定義位址 , 目前先給予假的
                    var path = user.Picture.SaveAs(@"C:\新增資料夾\", Guid.NewGuid().ToString() + ".jpg");
                    entity.IMAGE_PATH = path;
                }

                // 找到使用者操作權限
                var rolesEntity = db.ROLE.Where(x => roleIDs.Contains(x.ID)).ToList();

                // 綁定人員
                entity.ROLE = rolesEntity;

                db.USER.Add(entity);

                db.SaveChanges();
            });



        }
        /// <summary>
        /// 更新人員資訊
        /// </summary>
        /// <param name="user"></param>
        /// <param name="roleIDs"></param>
        /// <returns></returns>
        public async Task UpdateAsync(User user, int[] roleIDs)
        {



            _OrganizationAggregate.User_T1_T2_.Operator(context =>
            {

                var db = (SMARTIIEntities)context;
                db.Configuration.LazyLoadingEnabled = false;

                var query = db.USER.Include("ROLE")
                                   .Where(x => x.USER_ID == user.UserID)
                                   .FirstOrDefault();

                if (user.Picture != null)
                {
                    // 該目錄需定義位址 , 目前先給予假的
                    var path = user.Picture.SaveAs(@"C:\新增資料夾\", Guid.NewGuid().ToString() + ".jpg");
                    query.IMAGE_PATH = path;

                }

                if (query.IS_AD == false && user.IsAD)
                {

                    // 如果改為AD 帳戶 , 需確認有效性
                    if (_UserAuthenticationManager.IsADUser(user.Account, user.Password) == false)
                        throw new Exception(Error.AD_USER_NULL);

                }

                if (query.IS_AD && user.IsAD == false)
                {

                    // 如果原本是AD帳戶而被修正為非AD 帳戶
                    // 密碼重新配置為預設的 , 並且進行重設鎖定
                    query.PASSWORD = SecurityCache.DefaultPassword.Md5Hash();

                    // 重設註記 , 將最後修改時間重置
                    query.LAST_CHANGE_PASSWORD_DATETIME = null;

                }

                query.IS_AD = user.IsAD;
                query.NAME = user.Name;
                query.TELEPHONE = user.Telephone;
                query.UPDATE_DATETIME = DateTime.Now;
                query.UPDATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;
                query.IS_ENABLED = user.IsEnabled;
                query.GENDER = user.Gender;
                query.FEATURE = JsonConvert.SerializeObject(user.Feature);


                // 找到使用者操作權限
                var rolesEntity = db.ROLE.Where(x => roleIDs.Contains(x.ID)).ToList();

                // 綁定人員
                query.ROLE = rolesEntity;

                db.SaveChanges();
            });


        }
        /// <summary>
        /// 建立功能權限
        /// </summary>
        /// <param name="role"></param>
        /// <param name="userIDs"></param>
        /// <returns></returns>
        public async Task CreateRoleAsync(Role role, string[] userIDs)
        {


            _OrganizationAggregate.Role_T1_.Operator(context =>
            {

                var db = (SMARTIIEntities)context;
                db.Configuration.LazyLoadingEnabled = false;


                var entity = AutoMapper.Mapper.Map<ROLE>(role);
                entity.CREATE_DATETIME = DateTime.Now;
                entity.CREATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;

                var usersEntity = db.USER.Where(x => userIDs.Contains(x.USER_ID)).ToList();

                entity.USER = usersEntity;

                db.ROLE.Add(entity);

                db.SaveChanges();
            });

        }
        /// <summary>
        /// 更新功能權限
        /// </summary>
        /// <param name="role"></param>
        /// <param name="userIDs"></param>
        /// <returns></returns>
        public async Task UpdateRoleAsync(Role role, string[] userIDs)
        {

            _OrganizationAggregate.Role_T1_.Operator(context =>
            {

                var db = (SMARTIIEntities)context;
                db.Configuration.LazyLoadingEnabled = false;

                var query = db.ROLE.Include("USER")
                                   .Where(x => x.ID == role.ID)
                                   .FirstOrDefault();

                if (query == null)
                    throw new Exception(Error.NOT_FOUND_DATA);

                query.FEATURE = JsonConvert.SerializeObject(role.Feature);
                query.IS_ENABLED = role.IsEnabled;
                query.NAME = role.Name;
                query.UPDATE_DATETIME = DateTime.Now;
                query.UPDATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;

                var usersEntity = db.USER.Where(x => userIDs.Contains(x.USER_ID)).ToList();

                query.USER = usersEntity;

                db.SaveChanges();
            });

        }
        /// <summary>
        /// 使用者變更密碼
        /// </summary>
        /// <param name="account"></param>
        /// <param name="oldPassword"></param>
        /// <param name="newPassword"></param>
        /// <returns></returns>
        public async Task ResetPasswordAsync(string account, string oldPassword, string newPassword)
        {

            var con = new MSSQLCondition<USER>(x => x.ACCOUNT == account);
            User user = _OrganizationAggregate.User_T1_T2_.Get(con);


            if(user.IsAD)
                throw new Exception(Feature.AD_DENY_CHANGE_PASSWORD);

            if (String.Equals(newPassword, oldPassword))
                throw new Exception(Feature.NEWPASSWORD_EQUAL_OLDPASSWORD);

            if (String.Equals(user.Password, oldPassword.Md5Hash()) == false)
                throw new Exception(Feature.OLDPASSWORD_ERROR);

            if (newPassword.Validate())
                throw new Exception(Feature.VALID_PASSWORD_STRENGTH_FAIL);

            if (user.PastPasswordQueue.HasAny(newPassword.Md5Hash()))
                throw new Exception(Feature.NEWPASSWORD_INSIDE_FIVE_GROUPS);


            if (String.Equals(SecurityCache.DefaultPassword, oldPassword) == false)
                user.PastPasswordQueue.Insert(oldPassword.Md5Hash());

            con.ActionModify(x =>
            {
                x.PASSWORD = newPassword.Md5Hash();
                x.LAST_CHANGE_PASSWORD_DATETIME = DateTime.Now;
                x.LOCKOUT_DATETIME = null;
                x.UPDATE_DATETIME = DateTime.Now;
                x.UPDATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;
                x.PAST_PASSWORD_RECORD = JsonConvert.SerializeObject(user.PastPasswordQueue.ToArray());
            });


            _OrganizationAggregate.User_T1_T2_.Update(con);

        }

        /// <summary>
        /// 重置密碼
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        public async Task ResetDefaultPasswordAsync(string account)
        {
            var con = new MSSQLCondition<USER>(x => x.ACCOUNT == account);

            User user = _OrganizationAggregate.User_T1_T2_.Get(con);
            
            //  系統管理者重新設定密碼 , 原先密碼需要先放入歷程堆疊中。
            if (String.Equals(SecurityCache.DefaultPassword, user.Password) == false)
                user.PastPasswordQueue.Insert(user.Password);


            con.ActionModify(x =>
            {

                x.PAST_PASSWORD_RECORD = JsonConvert.SerializeObject(user.PastPasswordQueue.ToArray());
                x.PASSWORD = SecurityCache.DefaultPassword.Md5Hash();
                x.LAST_CHANGE_PASSWORD_DATETIME = null;
                x.LOCKOUT_DATETIME = null;
                x.UPDATE_DATETIME = DateTime.Now;
                x.UPDATE_USERNAME = ContextUtility.GetUserIdentity()?.Name;
            });

            _OrganizationAggregate.User_T1_T2_.Update(con);

        }
    }
}
