﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Net;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Cache;
using SMARTII.Resource.Error;

namespace SMARTII.Domain.Authentication.Service
{
    public class LDAPHelper
    {
        private DirectoryEntry Entry =
            new DirectoryEntry(
                DataAccessCache.Instance.LDAPUrl,
                DataAccessCache.Instance.LDAPAccount,
                DataAccessCache.Instance.LDAPPassword);

        public List<ADUser> FindAll(string filter)
        {
            var result = new List<ADUser>();

            DirectorySearcher search = new DirectorySearcher(Entry);
            search.Filter = filter;
            search.PropertiesToLoad.Add("cn");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("displayname");
            search.PropertiesToLoad.Add("department");
            search.PropertiesToLoad.Add("mail");
            search.PropertiesToLoad.Add("givenname");
            search.PropertiesToLoad.Add("userprincipalname");
            search.PropertiesToLoad.Add("samaccountname");
            search.PropertiesToLoad.Add("company");
            search.PropertiesToLoad.Add("manager");
            var adUserList = search.FindAll();

            foreach (SearchResult adUser in adUserList)
            {
                result.Add(new ADUser(adUser));
            }

            return result;
        }

        public ADUser FindOne(string principal)
        {
            DirectorySearcher search = new DirectorySearcher(Entry);

            search.Filter = string.Format("(SAMAccountName={0})", principal);
            search.PropertiesToLoad.Add("cn");
            search.PropertiesToLoad.Add("sn");
            search.PropertiesToLoad.Add("displayname");
            search.PropertiesToLoad.Add("department");
            search.PropertiesToLoad.Add("mail");
            search.PropertiesToLoad.Add("givenname");
            search.PropertiesToLoad.Add("userprincipalname");
            search.PropertiesToLoad.Add("samaccountname");
            search.PropertiesToLoad.Add("company");
            search.PropertiesToLoad.Add("manager");
            var adUser = search.FindOne();

            if (adUser == null) return null;


            return new ADUser(adUser);
        }

        public bool IsAdUser(string account , string password)
        {

            bool authenticated = false;
            
            try
            {

                if (string.IsNullOrEmpty(account) || string.IsNullOrEmpty(password))
                    throw new Exception(Error.PARAMETER_NULL);

                DirectoryEntry entry = new DirectoryEntry(DataAccessCache.Instance.LDAPUrl, account, password);
                object nativeObject = entry.NativeObject;
                authenticated = true;
            }
            catch (Exception ex)
            {

                authenticated = false;
            }

            return authenticated;
        }
    }
}
