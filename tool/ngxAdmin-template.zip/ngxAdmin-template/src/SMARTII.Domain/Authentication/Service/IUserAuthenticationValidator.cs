﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Organization;

namespace SMARTII.Domain.Authentication.Service
{
    public interface IUserAuthenticationManager
    {

        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="account"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        Task<User> LoginAsync(string account, string password);

        /// <summary>
        /// 找到使用者資訊
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        Task<User> FindByAccountAsync(string account);

        /// <summary>
        /// 登出
        /// </summary>
        /// <returns></returns>
        Task LogoutAsync();

        /// <summary>
        /// 是否為AD 人員
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        bool IsADUser(string account, string password);

        /// <summary>
        /// 計算黑白名單
        /// </summary>
        /// <param name="roleAuths"></param>
        /// <param name="userAuths"></param>
        /// <returns></returns>
        List<PageAuth> CalcPageAuth(List<PageAuth> roleAuths, List<PageAuth> userAuths);
        /// <summary>
        /// 組合角色與使用權限
        /// </summary>
        /// <param name="roleAuths"></param>
        /// <param name="userAuths"></param>
        /// <returns></returns>
        List<PageAuth> MergedPageAuth(List<PageAuth> roleAuths, List<PageAuth> userAuths);
        /// <summary>
        /// 娶得完整的合併清單
        /// </summary>
        /// <param name="roleAuths"></param>
        /// <param name="userAuths"></param>
        /// <returns></returns>
        List<PageAuth> GetCompleteMergedPageAuth(List<PageAuth> roleAuths, List<PageAuth> userAuths);
    }
}
