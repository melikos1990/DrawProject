﻿using System.Collections.Generic;
using System.Security.Principal;

namespace SMARTII.Domain.Authentication.Service
{
    public interface IPrincipalManager
    {
        /// <summary>
        /// 產生憑證
        /// </summary>
        /// <param name="token"></param>
        /// <returns></returns>
        IPrincipal Generator(string token);
      
    }
}
