﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Authentication.Object
{
    public class TokenPair
    {
        public TokenPair()
        {

        }

        public string AccessToken { get; set; }

        public string RefreshToken { get; set; }
    }
}
