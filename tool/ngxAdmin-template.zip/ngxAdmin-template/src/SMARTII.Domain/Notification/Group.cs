﻿using SMARTII.Domain.Organization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Notification
{
    public class Group
    {
        public Group() { }

        /// <summary>
        /// BU代號
        /// </summary>
        public string BUID { get; set; }
        /// <summary>
        /// 群組名稱
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 推送群組型態
        /// </summary>
        public GroupType NotificationGroupType { get; set; }
        /// <summary>
        ///底下的使用者
        /// </summary>
        public List<User> Users { get; set; }
    }
}
