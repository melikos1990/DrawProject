﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Notification
{
    public interface INotificationFactory
    {
        /// <summary>
        /// 推送訊息
        /// </summary>
        /// <param name=""></param>
        void Send(IPayload payload);

    }
}
