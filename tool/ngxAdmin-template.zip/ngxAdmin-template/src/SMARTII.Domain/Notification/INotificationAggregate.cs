﻿using Autofac.Features.Indexed;

namespace SMARTII.Domain.Notification
{
    public interface INotificationAggregate
    {
        IIndex<NotificationType, INotificationFactory> Factories { get; }
    }
}
