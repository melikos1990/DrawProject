﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Notification
{
    /// <summary>
    /// 推播行為
    /// </summary>
    public enum NotificationType
    {
        /// <summary>
        /// 信箱推播
        /// </summary>
        [Description("信箱推播")]
        Email,

        /// <summary>
        /// 簡訊推播
        /// </summary>
        [Description("簡訊推播")]
        SMS,

        /// <summary>
        /// 畫面通知
        /// </summary>
        [Description("畫面通知")]
        UI,

        /// <summary>
        /// 網頁推播
        /// </summary>
        [Description("網頁推播")]
        WebPush,

        /// <summary>
        /// 手機推播
        /// </summary>
        [Description("手機推播")]
        MobilePush,

        /// <summary>
        /// 社群推播
        /// </summary>
        [Description("社群推播")]
        Social,
        
    }
}
