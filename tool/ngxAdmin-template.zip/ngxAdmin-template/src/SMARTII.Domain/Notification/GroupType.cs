﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Notification
{
    public enum GroupType
    {
        /// <summary>
        /// 派工推播
        /// </summary>
        [Description("派工推播")]
        Assign,

        /// <summary>
        /// 一般推播
        /// </summary>
        [Description("一般推播")]
        General

    }
}
