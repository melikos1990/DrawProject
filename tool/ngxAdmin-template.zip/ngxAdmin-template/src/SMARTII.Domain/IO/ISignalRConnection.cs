﻿namespace SMARTII.Domain.IO
{
    /// <summary>
    /// 該介面為 AP 端呼叫Client 端的邏輯
    /// </summary>
    public interface ISignalRConnection
    {
        void PushAllUser(string message);
    }
}
