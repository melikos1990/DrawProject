﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.IO
{
    public static class FileUtility
    {

        /// <summary>
        /// 刪除檔案
        /// </summary>
        /// <param name="FullPath"></param>
        public static void Delete(string FullPath)
        {
            if (File.Exists(FullPath))
            {
                File.Delete(FullPath);
            }

        }
        /// <summary>
        /// 儲存檔案
        /// </summary>
        /// <param name="File"></param>
        /// <param name="Path"></param>
        /// <returns></returns>
        public static string SaveAs(this byte[] bytes, string path, string fileName = "")
        {

        
            string fullPath = Path.Combine(path, fileName);
            (new FileInfo(fullPath)).Directory.Create();
            File.WriteAllBytes(fullPath, bytes);

            return $"File/GetUserImage?FileName={fileName}";

        }
    }
}
