﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;

namespace SMARTII.Domain.System
{
    public class SystemFeature
    {
        /// <summary>
        /// 代號
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 上層代號
        /// </summary>
        public int ParentID { get; set; }
        /// <summary>
        /// ComponentName
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 顯示名稱
        /// </summary>
        public string DisplayName { get; set; }
        /// <summary>
        /// ComponentPath
        /// </summary>
        public string RoutePath { get; set; }
        /// <summary>
        /// 是否為連結
        /// </summary>
        public bool IsLink { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public bool IsEnabled { get; set; }
        /// <summary>
        /// 排序
        /// </summary>
        public int Order { get; set; }
        /// <summary>
        /// 操作權限
        /// </summary>
        public AuthenticationType Operator { get; set; }
        /// <summary>
        /// 子功能
        /// </summary>
        public virtual List<SystemFeature> Children { get; set; }
        /// <summary>
        /// 父功能
        /// </summary>
        public virtual SystemFeature Parent { get; set; }
    }
}

