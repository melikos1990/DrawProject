﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.System
{
    public class SystemParameter
    {
        public SystemParameter() { }
        /// <summary>
        /// 代號
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 關鍵值
        /// </summary>
        public string Key { get; set; }
        /// <summary>
        /// 實際資料
        /// </summary>
        public string Value { get; set; }
        /// <summary>
        /// 代表文字
        /// </summary>
        public string Text { get; set; }
        /// <summary>
        /// 更新者
        /// </summary>
        public string UpdateUserName { get; set; }
        /// <summary>
        /// 建立者
        /// </summary>
        public DateTime CreateDateTime { get; set; }
        /// <summary>
        /// 建立者
        /// </summary>
        public string CreateUserName { get; set; }
        /// <summary>
        /// 更新時間
        /// </summary>
        public DateTime? UpdateDateTime { get; set; }
    }

}
