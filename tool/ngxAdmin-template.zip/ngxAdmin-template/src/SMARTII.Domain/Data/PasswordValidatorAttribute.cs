﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Resource.Error;

namespace SMARTII.Domain.Data
{
    public class PasswordValidatorAttribute: ValidationAttribute
    {
        
        Type _ClassType { get; set; }
        string _ValiateMethodName { get; set; }

        public PasswordValidatorAttribute(Type classType, string valiateMethodName) 
        {
            _ClassType = classType;
            _ValiateMethodName = valiateMethodName;
        }


        protected override ValidationResult IsValid(object value, ValidationContext validationContext) 
        {

            string password = (string)value;
            MethodInfo methodInfo = this._ClassType.GetMethod(this._ValiateMethodName);
            bool validated = (Boolean)methodInfo.Invoke(this._ClassType, new object[] { password });

            if (validated)
                return ValidationResult.Success;
            else
                return new ValidationResult(Resource.Tag.Feature.VALID_PASSWORD_STRENGTH_FAIL);
            

        }

    }
}
