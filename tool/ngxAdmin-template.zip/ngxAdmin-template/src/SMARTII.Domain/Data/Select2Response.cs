﻿using System;
using System.Collections.Generic;

namespace SMARTII.Domain.Data
{
    public class Select2Response
    {
        public List<SelectItems> items { get; set; }

        public static List<SelectItems> ToSelectItems<T>(
            ICollection<T> value,
            Func<T, string> idSelector,
            Func<T, string> textSelector)
        {
            var items = new List<SelectItems>();

            foreach (var item in value)
            {
                string id = idSelector(item);
                string text = textSelector(item);

                items.Add(new SelectItems()
                {
                    id = id,
                    text = text
                });
            }

            return items;
        }
    }


    public class Select2Response<R>
    {
        public List<SelectItems<R>> items { get; set; }

        public static List<SelectItems<R>> ToSelectItems<T>(
            ICollection<T> value,
            Func<T, string> idSelector,
            Func<T, string> textSelector,
            Func<T, R> extendSelector)
        {
            var items = new List<SelectItems<R>>();

            foreach (var item in value)
            {
                string id = idSelector(item);
                string text = textSelector(item);
                R extendInfo = extendSelector(item);

                items.Add(new SelectItems<R>()
                {
                    id = id,
                    text = text,
                    extend = extendInfo
                });
            }

            return items;
        }
    }


    public class SelectItems
    {
        public string id { get; set; }
        public string text { get; set; }
    }

    public class SelectItems<T> : SelectItems
    {
        public T extend { get; set; }
    }
}
