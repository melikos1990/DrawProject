﻿using System;

namespace SMARTII.Domain.Data
{
    public class PagingResponse
    {
        public PagingResponse()
        {
        }

        public Boolean isSuccess { get; set; }

        public int totalCount { get; set; }

        public object extension { get; set; }

        public string message { get; set; }
    }

    public class PagingResponse<T> : PagingResponse
    {
        public PagingResponse(T data)
        {
            this.data = data;
        }

        public T data { get; set; }
    }
}
