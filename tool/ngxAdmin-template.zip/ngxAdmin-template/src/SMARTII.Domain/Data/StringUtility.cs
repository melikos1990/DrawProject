﻿using System;

namespace SMARTII.Domain.Data
{
    public static class StringUtility
    {
        public static byte[] GetBytes(string input)
        {
            byte[] numArray = new byte[input.Length * 2];
            Buffer.BlockCopy((Array)input.ToCharArray(), 0, (Array)numArray, 0, numArray.Length);
            return numArray;
        }
    }
}
