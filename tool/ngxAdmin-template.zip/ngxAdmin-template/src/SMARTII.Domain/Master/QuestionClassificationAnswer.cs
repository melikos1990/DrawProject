﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Domain.Organization;

namespace SMARTII.Domain.Master
{
    public class QuestionClassificationAnswer
    {
        public QuestionClassificationAnswer() { }

        /// <summary>
        /// 代號
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 所屬分類代號
        /// </summary>
        public int ClassificationID { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public bool IsEnabled { get; set; }
        /// <summary>
        /// 範本內容
        /// </summary>
        public string Content { get; set; }
        /// <summary>
        /// 組織型態
        /// </summary>
        public OrganizationType OrganizationType { get; set; }
        /// <summary>
        /// 節點代號
        /// </summary>
        public int NodeID { get; set; }
        /// <summary>
        /// 更新人員
        /// </summary>
        public string UpdateUserName { get; set; }
        /// <summary>
        /// 新增時間
        /// </summary>
        public DateTime CreateDateTime { get; set; }
        /// <summary>
        /// 新增人員
        /// </summary>
        public string CreateUserName { get; set; }
        /// <summary>
        /// 更新時間
        /// </summary>
        public DateTime? UpdateDateTime { get; set; }
        /// <summary>
        /// 所屬問題分類
        /// </summary>
        public virtual QuestionClassification QuestionClassification { get; set; }
    }
}
