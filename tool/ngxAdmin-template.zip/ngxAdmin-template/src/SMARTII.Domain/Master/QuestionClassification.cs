﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Domain.Organization;

namespace SMARTII.Domain.Master
{
    public class QuestionClassification
    {
        public QuestionClassification() { }
       
        /// <summary>
        /// 組織節點
        /// </summary>
        public int NodeID { get; set; }
        /// <summary>
        /// 代號
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 父階層代號
        /// </summary>
        public int ParentID { get; set; }
        /// <summary>
        /// 分類名稱
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 是否啟用
        /// </summary>
        public bool IsEnabled { get; set; }
        /// <summary>
        /// 更新人員姓名
        /// </summary>
        public string UpdateUserName { get; set; }
        /// <summary>
        /// 建立時間
        /// </summary>
        public DateTime CreateDateTime { get; set; }
        /// <summary>
        /// 建立人員姓名
        /// </summary>
        public string CreateUserName { get; set; }
        /// <summary>
        /// 更新時間
        /// </summary>
        public DateTime? UpdateDateTime { get; set; }
        /// <summary>
        /// 組織型態
        /// </summary>
        public OrganizationType OrganizationType { get; set; }
        /// <summary>
        /// 總部組織
        /// </summary>
        public virtual HeaderQuarterNode HeaderQuarterNode { get; set; }
        /// <summary>
        /// 範本清單
        /// </summary>
        public virtual List<QuestionClassificationAnswer> QuesionClassificationAnswer { get; set; }
        /// <summary>
        /// 子分類
        /// </summary>
        public virtual List<QuestionClassification> Children { get; set; }
        /// <summary>
        /// 父階層分類
        /// </summary>
        public virtual QuestionClassification Parent { get; set; }

    }
}
