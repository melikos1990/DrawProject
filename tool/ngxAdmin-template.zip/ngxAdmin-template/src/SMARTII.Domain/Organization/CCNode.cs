﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMARTII.Domain.Common;

namespace SMARTII.Domain.Organization
{
    public class CCNode : IOrganizationNode
    {
        public int NodeID { get; set; }
        public string Name { get; set; }
        public int LeftBundory { get; set; }
        public int RightBundory { get; set; }
        public int Level { get; set; }
        public string ParentLocator { get; set; }
        public string ParentPath { get; set; }
        public string DefindType { get; set; }

        public OrganizationType OrganizationType => OrganizationType.CallCenter;

        public List<Job> Jobs { get; set; }

        public List<INestedModel> Children { get; set; } = new List<INestedModel>();
    }
}
