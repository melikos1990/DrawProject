﻿using System;
using System.Collections.Generic;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;

namespace SMARTII.Domain.Organization
{
    public class Role
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public bool IsEnabled { get; set; }
        public string UpdateUserName { get; set; }
        public DateTime CreateDateTime { get; set; }
        public string CreateUserName { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public List<PageAuth> Feature { get; set; }
        public List<User> Users { get; set; }
    }
}
