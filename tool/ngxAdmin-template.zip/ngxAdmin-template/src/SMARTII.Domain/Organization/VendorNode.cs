﻿using System.Collections.Generic;
using SMARTII.Domain.Common;

namespace SMARTII.Domain.Organization
{
    public class VendorNode : IOrganizationNode
    {
        public int NodeID { get; set; }
        public string Name { get; set; }
        public int LeftBundory { get; set; }
        public int RightBundory { get; set; }
        public int Level { get; set; }
        public string ParentLocator { get; set; }
        public string ParentPath { get; set; }
        public string DefindType { get; set; }

        public OrganizationType OrganizationType => OrganizationType.Vendor;

        public List<Job> Jobs { get; set; }

        public List<INestedModel> Children { get; set; } = new List<INestedModel>();
    }
}
