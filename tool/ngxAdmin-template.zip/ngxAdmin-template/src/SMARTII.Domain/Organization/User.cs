﻿using System;
using System.Collections.Generic;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;

namespace SMARTII.Domain.Organization
{
    public class User
    {

        /// <summary>
        /// 使用者代號
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// 密碼
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 帳號
        /// </summary>
        public string Account { get; set; }

        /// <summary>
        /// 建立人
        /// </summary>
        public string CreateUserName { get; set; }

        /// <summary>
        /// 建立時間
        /// </summary>
        public DateTime CreateDateTime { get; set; }

        /// <summary>
        /// 電子信箱
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// 是否AD登入
        /// </summary>
        public Boolean IsAD { get; set; }

        /// <summary>
        /// 是否啟用
        /// </summary>
        public Boolean IsEnabled { get; set; }

        /// <summary>
        /// 最後修改密碼時間
        /// </summary>
        public DateTime? LastChangePasswordDateTime { get; set; }

        /// <summary>
        /// 鎖定時間
        /// </summary>
        public DateTime? LockoutDateTime { get; set; }

        /// <summary>
        /// 過去修改過的密碼
        /// </summary>
        public PasswordQueue PastPasswordQueue { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 推播ID
        /// </summary>
        public string PushID { get; set; }

        /// <summary>
        /// 連絡電話
        /// </summary>
        public string Telephone { get; set; }

        /// <summary>
        /// 更新人員
        /// </summary>
        public string UpdateUserName { get; set; }

        /// <summary>
        /// 更新時間
        /// </summary>
        public DateTime? UpdateDateTime { get; set; }

        /// <summary>
        /// 功能權限
        /// </summary>
        public List<PageAuth> Feature { get; set; } = new List<PageAuth>();
        /// <summary>
        /// 圖片實體檔案
        /// </summary>
        public Byte[] Picture { get; set; }
        /// <summary>
        /// 圖片路徑
        /// </summary>
        public string ImagePath { get; set; }
        /// <summary>
        /// 性別
        /// </summary>
        public Boolean Gender { get; set; }

        /// <summary>
        /// 所擁有的權限清單
        /// </summary>
        public List<Role> Roles { get; set; } = new List<Role>();

        #region extension

        public User AsTokenIdentity()
        {
            return new User()
            {
                Account = this.Account,
                Name = this.Name,
                ImagePath = this.ImagePath
                
            };
        }

        #endregion extension
    }
}
