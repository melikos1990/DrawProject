﻿using Ptc.Data.Condition2.Mssql.Repository;
using SMARTII.Database.SMARTII;

namespace SMARTII.Domain.Organization
{
    public interface IOrganizationAggregate
    {
        IMSSQLRepository<USER, User> User_T1_T2_ { get; }
        IMSSQLRepository<USER> User_T1_ { get; }
        IMSSQLRepository<ROLE, Role> Role_T1_T2_ { get; }
        IMSSQLRepository<ROLE> Role_T1_ { get; }
    }
}
