﻿using System.Collections.Generic;

namespace SMARTII.Domain.Organization
{
    public class Job
    {
        /// <summary>
        /// 組織代號
        /// </summary>
        public int OrganizationID { get; set; }

        /// <summary>
        /// 職稱代號
        /// </summary>
        public int JobID { get; set; }

        /// <summary>
        /// 上層職稱代號
        /// </summary>
        public int ParentJobID { get; set; }

        /// <summary>
        /// 職稱
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 備註
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// 使用者
        /// </summary>
        public List<User> Users { get; set; }

        /// <summary>
        /// 排序
        /// </summary>
        public int Order { get; set; }
    }
}
