﻿using System.Collections.Generic;
using SMARTII.Domain.Case;
using SMARTII.Domain.Common;

namespace SMARTII.Domain.Organization
{
    public interface IOrganizationNode : INestedModel, IComplaintSource, IComplaintTarget
    {
        /// <summary>
        /// 節點代號
        /// </summary>
        new int NodeID { get; set; }

        /// <summary>
        /// 組織名稱
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// 左節點
        /// </summary>
        new int LeftBundory { get; set; }

        /// <summary>
        /// 右邊節點
        /// </summary>
        new int RightBundory { get; set; }

        /// <summary>
        /// 層級
        /// </summary>
        new int Level { get; set; }

        /// <summary>
        /// 父層級節點
        /// </summary>
        new string ParentLocator { get; set; }

        /// <summary>
        /// 父層級路徑
        /// </summary>
        new string ParentPath { get; set; }

        /// <summary>
        /// 節點定義
        /// </summary>
        string DefindType { get; set; }

        /// <summary>
        /// 組織型態
        /// </summary>
        OrganizationType OrganizationType { get; }

        /// <summary>
        /// 職稱清單
        /// </summary>
        List<Job> Jobs { get; }
    }
}
