﻿using System;
using System.Configuration;
using System.Web.Configuration;

namespace SMARTII.Domain.Cache
{
    public class DataAccessCache
    {
        private static readonly Lazy<DataAccessCache> LazyInstance = new Lazy<DataAccessCache>(() => new DataAccessCache());

        public static DataAccessCache Instance { get { return LazyInstance.Value; } }

        public DataAccessCache()
        {
            this.SmartIIConn = ConfigurationManager.ConnectionStrings["SMARTIIEntities"].ConnectionString;
            this.LDAPAccount = WebConfigurationManager.AppSettings["LDAPAccount"].ToString();
            this.LDAPPassword = WebConfigurationManager.AppSettings["LDAPPassword"].ToString();
            this.LDAPUrl = WebConfigurationManager.AppSettings["LDAPUrl"].ToString();
        }

        public string SmartIIConn { get; set; }

        public string LDAPAccount { get; set; }

        public string LDAPPassword { get; set; }

        public string LDAPUrl { get; set; }
    }
}
