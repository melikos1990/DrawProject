﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

namespace SMARTII.Domain.Cache
{
    public class GlobalizationCache
    {
        public static string CultureKey = "Culture";
        public static string ServiceKey = "Bu";

        private static readonly Lazy<GlobalizationCache> LazyInstance = new Lazy<GlobalizationCache>(() => new GlobalizationCache());

        public static GlobalizationCache Instance { get { return LazyInstance.Value; } }

        public GlobalizationCache()
        {
            LoadAssembly();
        }

        public Dictionary<string, Assembly> AssemblyDict { get; set; }

        public void LoadAssembly()
        {

            AssemblyDict = new Dictionary<string, Assembly>()
            {
                { "Root" ,  Assembly.Load("SMARTII") },
                { "ASO" ,  Assembly.Load("SMARTII.ASO") },
                { "21Century" ,  Assembly.Load("SMARTII.21Century") }
            };
        }

     
    }
}
