﻿using System;
using System.Web.Configuration;

namespace SMARTII.Domain.Cache
{
    public class SecurityCache
    {
        private static readonly Lazy<SecurityCache> LazyInstance = new Lazy<SecurityCache>(() => new SecurityCache());

        public static SecurityCache Instance { get { return LazyInstance.Value; } }

        public static readonly int PasswordResetLimitCount = 4;

        public static readonly string DefaultPassword = "PTC";

        public SecurityCache()
        {
            this.TokenSecurityKey = WebConfigurationManager.AppSettings["TokenSecurityKey"].ToString();
        }

        public string TokenSecurityKey { get; set; }
    }
}
