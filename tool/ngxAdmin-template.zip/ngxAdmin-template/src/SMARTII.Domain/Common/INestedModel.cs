﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Domain.Common
{
    public interface INestedModel
    {
        /// <summary>
        /// 節點代號
        /// </summary>
        int NodeID { get; set; }
        /// <summary>
        /// 左節點
        /// </summary>
        int LeftBundory { get; set; }
        /// <summary>
        /// 右邊節點
        /// </summary>
        int RightBundory { get; set; }
        /// <summary>
        /// 層級
        /// </summary>
        int Level { get; set; }
        /// <summary>
        /// 父層級節點
        /// </summary>
        string ParentLocator { get; set; }
        /// <summary>
        /// 父層級路徑
        /// </summary>
        string ParentPath { get; set; }
        /// <summary>
        /// 底下的節點
        /// </summary>
        List<INestedModel> Children { get; set; }
    }
}
