﻿

namespace SMARTII.Domain.Common
{
    public interface ICommonAggregate
    {
        Ptc.Logger.ILogger Logger { get; }

      
    }
}
