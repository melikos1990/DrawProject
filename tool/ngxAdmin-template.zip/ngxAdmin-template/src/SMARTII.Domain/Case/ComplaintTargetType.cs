﻿
using System.ComponentModel;


namespace SMARTII.Domain.Case
{
    public enum ComplaintTargetType
    {

        /// <summary>
        /// 組織
        /// </summary>
        [Description("組織")]
        Organization,

        /// <summary>
        /// 商品
        /// </summary>
        [Description("商品")]
        Item


    }
}
