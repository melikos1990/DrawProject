﻿

namespace SMARTII.Domain.Case
{
    public interface IComplaintTarget
    {
    }
}
