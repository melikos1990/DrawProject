﻿using SMARTII.Domain.Notification;


namespace SMARTII.Domain.Case
{
    public class CaseNotification
    {

        /// <summary>
        /// BU代號
        /// </summary>
        public string BUID { get; set; }
        /// <summary>
        /// 案件編號
        /// </summary>
        public string CaseID { get; set; }
        /// <summary>
        /// 黑名單
        /// </summary>
        public string[] DenyUserIDs { get; set; }
        /// <summary>
        /// 白名單
        /// </summary>
        public string[] UserIDs { get; set; }
        /// <summary>
        /// 目標推送群組
        /// </summary>
        public string[] GroupIDs { get; set; }
        /// <summary>
        /// 推播行為
        /// </summary>
        public NotificationType Behavior { get; set; }
        /// <summary>
        /// 推送情境
        /// </summary>
        public string Type { get; set; }

    }
}
