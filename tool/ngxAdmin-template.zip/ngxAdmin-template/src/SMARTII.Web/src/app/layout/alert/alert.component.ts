import { Component, OnInit, ViewChild, AfterViewInit  , OnDestroy} from '@angular/core';
import { PtcSwalComponent, PtcSwalOption, PtcSwalType } from 'ptc-swal';

import { Store } from '@ngrx/store';
import { State as fromRootReducers } from "../../store/reducers"
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.scss']
})
export class AlertComponent implements AfterViewInit , OnDestroy {

  @ViewChild("swal") swal: PtcSwalComponent;

  opts$: Subscription;

  opts: PtcSwalOption = {}


  constructor(private store: Store<fromRootReducers>) {

  }

  ngAfterViewInit(): void {
    this.opts$ = this.store.select((state: fromRootReducers) => state.alert.opts)
    .pipe(filter(x => x != null))
    .subscribe(opts => {

      this.opts = { ...opts.detail };
      this.swal.options = { ...opts.detail };
      this.swal.show(opts.isLoop , opts.confirm , opts.cancel);

    });
  }

  ngOnDestroy(): void {
    this.opts$ && this.opts$.unsubscribe();
  }

}
