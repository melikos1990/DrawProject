import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThemeModule } from '../@theme/theme.module';
import { LoadingComponent } from './loading/loading.component';
import { StoreModule } from '@ngrx/store';
import { AlertComponent } from "./alert/alert.component";
import { SharedModule } from '../shared/shared.module';

const COMPONENTS = [ LoadingComponent, AlertComponent ]

@NgModule({
  declarations: [ ...COMPONENTS ],
  imports: [
    CommonModule,
    ThemeModule,
    StoreModule,
    SharedModule,
  ],
  exports : [
    ...COMPONENTS
  ]

})
export class LayoutModule { }
