import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { PtcLoadingComponent } from 'ptc-loading';

import { Observable, Subscription } from 'rxjs';
import { Store } from '@ngrx/store';

import { State as fromRootReducers } from "../../store/reducers";


@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss']
})
export class LoadingComponent implements AfterViewInit, OnDestroy {


  isVisible$: Subscription

  @ViewChild(PtcLoadingComponent)
  loadingComponent: PtcLoadingComponent;

  constructor(private store: Store<fromRootReducers>) {

  }

  ngAfterViewInit(): void {

    this.isVisible$ =
      this.store.select((state: fromRootReducers) => state.loading.visible)
        .subscribe(visible => {
          visible ? this.loadingComponent.show() : this.loadingComponent.close();
        });
  }

  ngOnDestroy(): void {
    this.isVisible$ && this.isVisible$.unsubscribe();
  }




}
