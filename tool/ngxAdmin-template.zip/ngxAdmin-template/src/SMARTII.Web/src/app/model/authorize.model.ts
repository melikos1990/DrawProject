export enum AuthenticationType {
  None = 0,
  Read = 1 << 0,
  Add = 1 << 1,
  Delete = 1 << 2,
  Update = 1 << 3,
  Report = 1 << 4,
  Admin = 1 << 5,

  All = Read | Add | Delete | Update | Report | Admin
}

export namespace AuthenticationType {
  export function toArray(n: AuthenticationType) {
    const values: string[] = [];
    while (n) {
      const bit = n & (~n + 1);
      values.push(AuthenticationType[bit]);
      n ^= bit;
    }
    return values;
  }
}



export type Identity = {

  Account: string;
  Password: string;
};

export type IdentityWrapper = {
  Account: string;
  UserName: string;
  AccessToken: string;
  RefreshToken: string;
  Feature: PageAuth[];
  Role: Role[];
  Mode: string;
}


export class Operator {
  Feature: PageAuth[] = []
}

export class User extends Operator {
  UserID: string;
  Account: string;
  Password: string;
  Name: string;
  Email: string;
  Phone: string;
  IsEnable: boolean;
  IsAD: boolean;
  Feature: PageAuth[] = [];
  Role: Role[] = [];
  ImagePath: string;
}

export class Role extends Operator {
  ID: number;
  Name: string;
  IsEnable: boolean;
  Feature: PageAuth[] = [];
}

export class ChangePasswordViewModel {
  Account: string;
  NewPassword: string;
  OldPassword: string;
  ConfirmPassword: string;
}


export class UserSearchViewModel {
  Account: string;
  Name: string;
  IsEnable?: boolean;
  IsAD?: boolean;
  Gender: boolean;
  RoleIDs: number[] = [];
}


export class RoleSearchViewModel {
  Name: string;
  IsEnable?: boolean;
}


export class RoleDetailViewModel extends Operator {
  Name: string;
  IsEnable: boolean;
  Feature: PageAuth[] = [];
  UpdateUserName: string;
  UpdateDateTime: string;
  CreateUserName: string;
  CreateDateTime: string;
  Users: Array<UserDetailViewModel> = [];
}


export class UserDetailViewModel extends Operator {
  UserID: string;
  Account: string;
  Password: string;
  Name: string;
  Email: string;
  Telephone: string;
  IsEnable: boolean;
  IsAD: boolean;
  Gender: boolean;
  Feature: PageAuth[] = [];
  RoleIDs: number[] = [];
  UpdateUserName: string;
  UpdateDateTime: string;
  CreateUserName: string;
  CreateDateTime: string;
  Picture: File;
  ImagePath: string;
}

export class PageAuth {
  Feature: string;
  AuthenticationType: AuthenticationType;
}




