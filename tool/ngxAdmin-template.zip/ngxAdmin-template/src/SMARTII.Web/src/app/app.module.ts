import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injector, ErrorHandler } from '@angular/core';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { ThemeModule } from './@theme/theme.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CoreModule } from './@core/core.module';
import { SharedModule } from './shared/shared.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SignalRModule } from 'ng2-signalr';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { reducers } from './store/reducers';
import { AuthorizeModule } from './auth/authorize.module';
import { LayoutModule } from './layout/layout.module';
import { effects } from './store/effects';
import { setAppInjector } from 'src/global';
import { config as signalRConfig } from './shared/signalR';
import { BreadcrumbsModule } from "ng6-breadcrumbs";
import { ErrorHandlerService } from './shared/service/error-handler.service';




@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AuthorizeModule,
    AppRoutingModule,
    LayoutModule,
    CoreModule.forRoot(),
    ThemeModule.forRoot(),
    NgbModule.forRoot(),
    BreadcrumbsModule,
    EffectsModule.forRoot(effects),
    StoreModule.forRoot(reducers),
    SignalRModule.forRoot(signalRConfig),
    StoreDevtoolsModule.instrument({
      maxAge: 10
    }),
    SharedModule,
  ],
  providers: [{ provide: ErrorHandler, useClass: ErrorHandlerService }],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(injector: Injector) {
    setAppInjector(injector);

  }
}
