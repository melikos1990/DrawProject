import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { SystemLoginComponent } from './auth/system-login/system-login.component';
import { AppComponent } from './app.component';

const routes: Routes = [
  {
    path: '',
    component: AppComponent,
    children: [
      {
        path: '',
        redirectTo: "login",
        pathMatch: "full"

      },
      {
        path: 'login',
        component: SystemLoginComponent
      },
      {
        path: 'pages',
        loadChildren: './pages/pages.module#PagesModule'
      }


    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
