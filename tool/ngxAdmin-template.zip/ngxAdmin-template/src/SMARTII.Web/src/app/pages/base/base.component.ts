import { Component, Injector, Optional, SkipSelf, Inject, InjectionToken, inject } from '@angular/core';
import { Translations } from 'src/app/shared/translation';
import { TranslateService, LangChangeEvent } from '@ngx-translate/core';
import { CultureService } from '../../shared/service/culture.service';
import { map } from 'rxjs/operators';
import { ActionType } from 'src/app/model/common.model';
import { AuthenticationType } from 'src/app/model/authorize.model';
export const PREFIX_TOKEN = new InjectionToken<string>('PREFIX');


@Component({
  selector: 'app-base',
  template: ''
})
export class BaseComponent {

  public featrueName: string;

  public translateService: TranslateService;
  public translations: Translations;

  public authType = AuthenticationType;
  public actionType = ActionType;

  constructor(
    public injector: Injector,
    @Optional() @Inject(PREFIX_TOKEN) public prefix?: string) {

    this.translateService = this.injector.get(TranslateService);
    this.translations = this.injector.get(Translations);
    this.featrueName = prefix;
    const cultureService = this.injector.get(CultureService);

    cultureService.language$.pipe(
      map((language: LangChangeEvent) => language.lang))
      .subscribe(lang => this.translateService.use(lang));
  }

}
