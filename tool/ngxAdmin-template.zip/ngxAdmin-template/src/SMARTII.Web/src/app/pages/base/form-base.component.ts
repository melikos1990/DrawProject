import { Component, Injector, Optional, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { AuthBaseComponent } from '../base/auth-base.component';
import { PtcSwalType } from 'ptc-swal';
import { PREFIX_TOKEN } from './base.component';


@Component({
  selector: 'app-form-base',
  template: ''
})
export class FormBaseComponent extends AuthBaseComponent {


  constructor(
    public injector: Injector,
    @Optional() @Inject(PREFIX_TOKEN) public prefix?: string) {
    super(injector, prefix);

  }

  protected getLoopQuestionMessage(title: string, confirm?: () => void, cancel?: () => void) {
    return {

      detail: {
        title: title,
        type: PtcSwalType.question,
        showCancelButton: true
      },
      isLoop: false,
      confirm: confirm,
      cancel: cancel
    }
  }

  protected getFieldInvalidMessage(remark?: string) {
    return {
      detail: {
        title: this.translateService.instant('ERROR.TITLE'),
        text: `${this.translateService.instant('ERROR.FIELD_VALID_ERROR')} ${(remark ? `: ${remark}` : '' )}`,
        type: PtcSwalType.error,
        showCancelButton: true,
      },
      isLoop: false
    };
  }

  protected markNestedForm(form) {

    for (let control in form.controls) {
      let controlItem = form.controls[control]
      if (controlItem instanceof FormGroup) {
        this.markNestedForm(controlItem);
      }
      form.controls[control].markAsDirty();
      form.controls[control].markAsTouched();
    }

  }

  protected validForm(form) {

    const invalid: boolean = form.invalid;
    if (invalid) {
      this.markNestedForm(form);
    }
    return !invalid;

  }

}
