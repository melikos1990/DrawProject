import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService } from 'src/app/shared/service/auth-guard.service';
import { SystemParameterComponent } from './system-parameter/list/system-parameter.component';
import { SystemComponent } from './system.component';
import { SystemParameterDetailComponent } from './system-parameter/detail/system-parameter-detail.component';
import { SystemLogComponent } from './system-log/list/system-log.component';


const routes: Routes = [{
  path: '',
  component: SystemComponent,
  children: [
    {
      path: 'system-parameter',
      component: SystemParameterComponent,
      data: {
        breadcrumb: 'APPLICATION.FEATURE.SYSTEM_PARAMETER',
        feature: 'SystemParameterComponent'
      },
      canActivate: [AuthGuardService],
    },
    {
      path: 'system-parameter-detail',
      component: SystemParameterDetailComponent,
      data: {
        breadcrumb: 'APPLICATION.FEATURE.SYSTEM_PARAMETER_DETAIL',
        feature: 'SystemParameterComponent'
      },
      canActivate: [AuthGuardService],
    },
    {
      path: 'system-log',
      component: SystemLogComponent,
      data: {
        breadcrumb: 'APPLICATION.FEATURE.SYSTEM_LOG',
        feature: 'SystemLogComponent'
      },
      canActivate: [AuthGuardService],
    },
  ]
}];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
  ],
  exports: [
    RouterModule
  ]
})
export class SystemRoutingModule { }
