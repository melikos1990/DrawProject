import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SystemParameterDetailComponent } from './system-parameter-detail.component';

describe('SystemParameterDetailComponent', () => {
  let component: SystemParameterDetailComponent;
  let fixture: ComponentFixture<SystemParameterDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SystemParameterDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SystemParameterDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
