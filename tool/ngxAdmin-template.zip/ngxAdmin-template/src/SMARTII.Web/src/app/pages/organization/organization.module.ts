import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserComponent } from './user/list/user.component';
import { RoleComponent } from './role/list/role.component';
import { ThemeModule } from 'src/app/@theme/theme.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { OrganizationRoutingModule } from './organization-routing.module';
import { OrganizationComponent } from './organization.component';
import { UserDetailComponent } from './user/detail/user-detail.component';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import * as fromOrganizationReducer from './store/reducers';
import * as fromOrganizationEffect from './store/effects';
import { RoleDetailComponent } from './role/detail/role-detail.component';
import { UserSelectorComponent } from './role/modal/user-selector/user-selector.component';
import { AdPasswordComponent } from './user/modal/ad-password/ad-password.component';

const COMPONENTS = [
  UserComponent,
  UserDetailComponent,
  RoleComponent,
  RoleDetailComponent,
  OrganizationComponent,

];

const ENTRY_COMPONENTS = [
  UserSelectorComponent,
  AdPasswordComponent
]

@NgModule({
  imports: [
    ThemeModule,
    SharedModule,
    CommonModule,
    OrganizationRoutingModule,
    EffectsModule.forFeature(fromOrganizationEffect.effects),
    StoreModule.forFeature('organization', fromOrganizationReducer.reducer),
  ],
  declarations: [
    ...COMPONENTS,
    ...ENTRY_COMPONENTS,
  ],
  entryComponents: [...ENTRY_COMPONENTS]
})
export class OrganizationModule { }


