import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MasterRoutingModule } from './master-routing.module';
import { ThemeModule } from '../../@theme/theme.module';
import { SharedModule } from '../../shared/shared.module';

import { MasterComponent } from './master.component';
import { PersonalChangePasswordComponent } from './personal-change-password/personal-change-password.component';

const COMPONENT = [
  MasterComponent,
  PersonalChangePasswordComponent
]

@NgModule({
  imports: [
    MasterRoutingModule,
    ThemeModule,
    SharedModule,
    CommonModule,
  ],
  declarations: [...COMPONENT],
  entryComponents: []

})
export class MasterModule { }
