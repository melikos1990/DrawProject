import * as fromUserReducer from "./user.reducers";
import * as fromRoleReducer from "./role.reducers";
import * as fromRootReducer from "../../../../store/reducers"


export interface IndexState {
  user: fromUserReducer.State;
  role: fromRoleReducer.State;
}

export interface State extends fromRootReducer.State {
  organization: IndexState;
}

export const reducer = {
  user : fromUserReducer.reducer,
  role : fromRoleReducer.reducer,
};
