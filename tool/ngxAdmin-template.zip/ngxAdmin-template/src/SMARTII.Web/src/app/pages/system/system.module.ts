import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SystemRoutingModule } from './system-routing.module';
import { ThemeModule } from 'src/app/@theme/theme.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { SystemComponent } from './system.component';
import { SystemParameterComponent } from './system-parameter/list/system-parameter.component';
import { SystemParameterDetailComponent } from './system-parameter/detail/system-parameter-detail.component';
import { StoreModule } from '@ngrx/store';
import * as fromSystemReducer from './store/reducers';
import * as fromSystemEffect from './store/effects';
import { EffectsModule } from '@ngrx/effects';
import { SystemLogComponent } from './system-log/list/system-log.component';


const COMPONENTS = [
  SystemComponent,
  SystemParameterComponent,
  SystemParameterDetailComponent,
  SystemLogComponent
];

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    ThemeModule,
    SharedModule,
    CommonModule,
    SystemRoutingModule,
    EffectsModule.forFeature(fromSystemEffect.effects),
    StoreModule.forFeature('system', fromSystemReducer.reducer),
  ]
})
export class SystemModule { }
