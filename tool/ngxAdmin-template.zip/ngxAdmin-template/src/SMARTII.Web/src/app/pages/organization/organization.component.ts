import { Component } from '@angular/core';

@Component({
  selector: 'app-organization',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class OrganizationComponent {
}
