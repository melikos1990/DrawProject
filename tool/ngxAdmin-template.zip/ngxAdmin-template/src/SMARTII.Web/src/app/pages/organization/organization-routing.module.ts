import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService } from 'src/app/shared/service/auth-guard.service';
import { OrganizationComponent } from './organization.component';
import { UserComponent } from './user/list/user.component';
import { UserDetailComponent } from './user/detail/user-detail.component';
import { RoleComponent } from './role/list/role.component';
import { RoleDetailComponent } from './role/detail/role-detail.component';


const routes: Routes = [{
  path: '',
  component: OrganizationComponent,
  children: [
    {
      path: 'user',
      component: UserComponent,
      canActivate : [AuthGuardService],
      data: {
        breadcrumb: 'APPLICATION.FEATURE.USER',
        feature: 'UserComponent'
      },
    },
    {
      path: 'user-detail',
      component: UserDetailComponent,
      canActivate : [AuthGuardService],
      data: {
        breadcrumb: 'APPLICATION.FEATURE.USER',
        feature: 'UserComponent'
      },
    },
    {
      path: 'role',
      component: RoleComponent,
      canActivate : [AuthGuardService],
      data: {
        breadcrumb: 'APPLICATION.FEATURE.ROLE',
        feature: 'RoleComponent'
      },
    },
    {
      path: 'role-detail',
      component: RoleDetailComponent,
      canActivate : [AuthGuardService],
      data: {
        breadcrumb: 'APPLICATION.FEATURE.ROLE',
        feature: 'RoleComponent'
      },
    },
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [
    RouterModule
  ]
})
export class OrganizationRoutingModule { }
