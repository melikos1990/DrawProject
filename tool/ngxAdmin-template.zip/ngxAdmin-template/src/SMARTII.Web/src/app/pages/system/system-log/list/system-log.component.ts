import { Component, Injector, OnInit, ViewChild } from '@angular/core';
import { AuthBaseComponent } from 'src/app/pages/base/auth-base.component';
import { loggerMethod } from 'src/app/shared/decorator/logger.decorator';
import { ServerTableComponent } from 'src/app/shared/component/table/server-table/server-table.component';
import { PtcAjaxOptions, PtcServerTableRequest } from 'ptc-server-table';
import { AuthenticationType } from 'src/app/model/authorize.model';
import { AuthorizeMethod } from 'src/app/shared/decorator/authorize.decorator';
import { SystemLogSearchModel } from 'src/app/model/system.model';
import { Store } from '@ngrx/store';
import { State as fromRootReducers } from "src/app/store/reducers"
import { Observable } from 'rxjs';
import { LocalStorage as AsyncStorage } from '@ngx-pwa/local-storage';

export const PREFIX = 'SystemLogComponent';

@Component({
  selector: 'app-system-log',
  templateUrl: './system-log.component.html',
  styleUrls: ['./system-log.component.scss']
})
export class SystemLogComponent extends AuthBaseComponent implements OnInit {


  /**
  * 這邊使用套件為 ptc-server-table
  * 請參照以下網址 ：
  * http://tfs2:8080/tfs/SD4-Collection/LibrarySD4/_git/ng-ptc-server-table?path=%2FREADME.md&version=GBmaster&_a=preview
  */
  @ViewChild('table')
  table: ServerTableComponent;

  /**
   * 定義顯示之欄位 , 用途請參照以上網址
   */
  columns: any[] = [];

  /**
   * 定義ajax欄位 , 用途請參照以上網址
   */
  ajax: PtcAjaxOptions = new PtcAjaxOptions();

  /**
   * 查詢條件
   */
  public model: SystemLogSearchModel = new SystemLogSearchModel();
  public operatorTypes = [];

  constructor(public injector: Injector) {
    super(injector , PREFIX);
  }


  @loggerMethod()
  ngOnInit() {
    this.initializeTable();
  }

  /**
   * 將物件傳出之前 , 加工 payload 送回server
   */
  @loggerMethod()
  critiria($event: PtcServerTableRequest<any>) {

    if (this.operatorTypes && this.operatorTypes.length > 0) {
      this.model.Operator = this.operatorTypes.reduce((sum, current) => sum + parseInt(current), 0);
    } else {
      this.model.Operator = null;
    }

    $event.criteria = this.model;
  }

  /**
   * 按鈕按下查詢,渲染table
   */
  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Read)
  btnRender($event: any) {
    this.table.render();
  }

  /**
   * 初始化Table資訊
   */
  initializeTable() {

    this.ajax.url = 'System/SystemLog/GetList/'.toHostApiUrl();
    this.ajax.method = 'POST';
    this.columns = [
      {
        text: this.translateService.instant('SYSTEM_LOG.FEATURE_NAME'),
        name: 'FeatureName',
        disabled: false,
        order: 'FEATURE_NAME'
      },
      {
        text: this.translateService.instant('SYSTEM_LOG.CONTENT'),
        name: 'Content',
        disabled: false,
        order: 'CONTENT',
      },
      {
        text: this.translateService.instant('SYSTEM_LOG.CREATE_DATETIME'),
        name: 'CreateDateTime',
        disabled: false,
        order: 'CREATE_DATETIME'
      },
      {
        text: this.translateService.instant('SYSTEM_LOG.CREATE_USERNAME'),
        name: 'CreateUserName',
        disabled: false,
        order: 'CREATE_USERNAME'
      },
      {
        text: this.translateService.instant('SYSTEM_LOG.OPERATOR'),
        name: 'Operator',
        disabled: false,
        order: 'OPERATOR'
      },
    ];


  }


}
