import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalChangePasswordComponent } from './personal-change-password.component';

describe('PersonalChangePasswordComponent', () => {
  let component: PersonalChangePasswordComponent;
  let fixture: ComponentFixture<PersonalChangePasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalChangePasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalChangePasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
