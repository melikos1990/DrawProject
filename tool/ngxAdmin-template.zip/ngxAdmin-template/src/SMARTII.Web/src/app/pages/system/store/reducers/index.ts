import * as fromSystemParameterReducer from  "./system-parameter.reducers";
import * as fromRootReducer from "../../../../store/reducers"


export interface IndexState {
    systemParameter : fromSystemParameterReducer.State;
}

export interface State extends fromRootReducer.State {
    system : IndexState;
}

export const reducer = {
  systemParameter : fromSystemParameterReducer.reducer,
}
