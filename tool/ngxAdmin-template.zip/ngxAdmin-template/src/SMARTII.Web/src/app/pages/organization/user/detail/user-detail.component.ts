import { Component, OnInit, Injector } from '@angular/core';
import { FormBaseComponent } from 'src/app/pages/base/form-base.component';
import { FormGroup, Validators, FormControl, EmailValidator } from '@angular/forms';
import { ActionType, EntrancePayload } from 'src/app/model/common.model';
import { User, UserSearchViewModel, UserDetailViewModel, AuthenticationType, Identity } from 'src/app/model/authorize.model';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { State as fromOrganizationReducer } from "../../store/reducers";
import * as fromUserActions from "../../store/actions/user.actions";
import { loggerMethod } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeMethod } from 'src/app/shared/decorator/authorize.decorator';
import { NumberValidator } from 'src/app/shared/validator';
import * as fromRootActions from "src/app/store/actions";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AdPasswordComponent } from '../modal/ad-password/ad-password.component';

export const PREFIX = 'UserComponent';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss']
})
export class UserDetailComponent extends FormBaseComponent implements OnInit {


  form: FormGroup;

  public validADState?: boolean;
  public uiActionType: ActionType;
  public model: UserDetailViewModel = new UserDetailViewModel();

  model$: Subscription;

  public options = {};

  public genderItems = [
    { id: true, text: '男' },
    { id: false, text: '女' }
  ];

  constructor(
    private modalService: NgbModal,
    private active: ActivatedRoute,
    private store: Store<fromOrganizationReducer>,
    public injector: Injector) {
    super(injector, PREFIX);
  }

  ngOnInit() {
    this.subscription();
    this.initializeForm();
  }

  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Read | AuthenticationType.Add)
  btnAdd($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }

    this.store.dispatch(new fromUserActions.addAction(this.model));

  }

  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Update | AuthenticationType.Read)
  btnEdit($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }
    this.store.dispatch(new fromUserActions.editAction(this.model));
  }


  @loggerMethod()
  btnBack($event) {
    history.back();
  }


  adSelectChange($event) {

    const isChecked: boolean = $event.target.checked;

    if (isChecked) {
      const ref = this.modalService.open(AdPasswordComponent, { size: 'lg', container: 'nb-layout', backdrop: 'static' });

      ref.componentInstance.btnValidAD = this.btnValidAD.bind(this);
    } else {
      this.model.IsAD = false;
      this.validADState = undefined;

    }

  }

  @loggerMethod()
  btnValidAD($event: string , modalRef) {

    if (!$event) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(
        this.getFieldInvalidMessage()));
      return;
    }

    const payload = new EntrancePayload<Identity>();
    payload.data = {
      Account: this.model.Account,
      Password: $event.trim()
    };
    payload.success = () => {
      this.model.Password = $event.trim();
      this.model.IsAD = true;
      this.validADState = true;
      modalRef.close();

    };

    payload.failed = () => {
      this.model.IsAD = false;
      this.validADState = false;
    };

    this.store.dispatch(new fromUserActions.validADPasswordAction(payload));
  }

  @loggerMethod()
  btnResetPassword() {
    this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(
      this.getLoopQuestionMessage(this.translateService.instant('USER.RESET_PASSWORD_QUESTION'),
      () => {
        const payload = new EntrancePayload<string>();
        payload.data = this.model.Account;
        this.store.dispatch(new fromUserActions.resetPasswordAction(payload));
      }
    )));
  }

  subscription() {
    this.active.params.subscribe(this.loadPage.bind(this));

    this.model$ =
      this.store
        .select((state: fromOrganizationReducer) => state.organization.user.detail)
        .subscribe(user => {
          this.model = { ...user };
          if (user && user.ImagePath) {
            this.options = {
              initialPreview: [
                user.ImagePath.toHostApiUrl()
              ],
            };
          }
        });
  }

  initializeForm() {
    this.form = new FormGroup({
      Account: new FormControl(this.model.Account, [
        Validators.required,
        Validators.maxLength(50),

      ]),
      Name: new FormControl(this.model.Name, [
        Validators.required,
        Validators.maxLength(50),

      ]),
      Telephone: new FormControl(this.model.Telephone, [
        Validators.required,
        NumberValidator
      ]),
      Email: new FormControl(this.model.Email, [
        Validators.required,
        Validators.email
      ]),
      IsEnabled: new FormControl(this.model.IsEnable),
      IsAD: new FormControl(this.model.IsAD),
      Gender: new FormControl(this.model.Gender, [
        Validators.required,
      ]),
      Picture: new FormControl(),
      CreateUserName: new FormControl(),
      CreateDateTime: new FormControl(),
      UpdateUserName: new FormControl(),
      UpdateDateTime: new FormControl(),
      roleIDs: new FormControl()
    });

  }

  loadPage(params) {
    this.uiActionType = parseInt(params['actionType']);

    const payload = {
      UserID: params['id']
    };

    switch (this.uiActionType) {
      case ActionType.Add:
        this.store.dispatch(new fromUserActions.loadEntryAction());
        break;
      case ActionType.Update:
        this.store.dispatch(new fromUserActions.loadDetailAction(payload));
        break;
      case ActionType.Read:
        this.store.dispatch(new fromUserActions.loadDetailAction(payload));
        break;
    }

  }

}
