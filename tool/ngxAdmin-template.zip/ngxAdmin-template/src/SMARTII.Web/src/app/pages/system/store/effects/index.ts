import { SystemParameterEffects } from './system-parameter.effects';

export const effects = [
  SystemParameterEffects
];
