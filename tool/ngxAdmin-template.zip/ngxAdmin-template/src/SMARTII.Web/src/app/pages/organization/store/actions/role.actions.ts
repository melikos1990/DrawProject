import { Action } from '@ngrx/store';
import { EntrancePayload, ResultPayload } from 'src/app/model/common.model';
import { RoleDetailViewModel } from 'src/app/model/authorize.model';


export const ADD = '[ROLE] ADD';
export const ADD_SUCCESS = '[ROLE] ADD SUCCESS';
export const ADD_FAILED = '[ROLE] ADD FAILED';
export const EDIT = '[ROLE] EDIT';
export const EDIT_SUCCESS = '[ROLE] EDIT SUCCESS';
export const EDIT_FAILED = '[ROLE] EDIT FAILED';
export const DELETE = '[ROLE] DELETE';
export const DELETE_SUCCESS = '[ROLE] DELETE SUCCESS';
export const DELETE_FAILED = '[ROLE] DELETE FAILED';
export const DELETE_RANGE = '[ROLE] DELETE RANGE';
export const DELETE_RANGE_SUCCESS = '[ROLE] DELETE RANGE SUCCESS';
export const DELETE_RANGE_FAILED = '[ROLE] DELETE RANGE FAILED';
export const LOAD_ENTRY = '[ROLE] LOAD ENTRY';
export const LOAD_DETAIL = '[ROLE] LOAD DETAIL';
export const LOAD_DETAIL_SUCCESS = '[ROLE] LOAD DETAIL SUCCESS';
export const LOAD_DETAIL_FAILED = '[ROLE] LOAD DETAIL FAILED';

export class loadDetailAction implements Action {
  public type: string = LOAD_DETAIL;
  constructor(public payload: {
    RoleID: number
  }) { }
}

export class loadDetailSuccessAction implements Action {
  public type: string = LOAD_DETAIL_SUCCESS;
  constructor(public payload: RoleDetailViewModel) { }
}

export class loadDetailFailedAction implements Action {
  public type: string = LOAD_DETAIL_FAILED;
  constructor(public payload: string) { }
}

export class loadEntryAction implements Action {
  public type: string = LOAD_ENTRY;
  constructor(public payload: RoleDetailViewModel = new RoleDetailViewModel()) { }
}

export class addAction implements Action {
  public type: string = ADD;
  constructor(public payload: RoleDetailViewModel) { }
}

export class addSuccessAction implements Action {
  public type: string = ADD_SUCCESS;
  constructor(public payload: RoleDetailViewModel) { }
}

export class addFailedAction implements Action {
  public type: string = ADD_FAILED;
  constructor(public payload: string) { }
}

export class editAction implements Action {
  public type: string = EDIT;
  constructor(public payload: RoleDetailViewModel) { }
}

export class editSuccessAction implements Action {
  public type: string = EDIT_SUCCESS;
  constructor(public payload: RoleDetailViewModel) { }
}

export class editFailedAction implements Action {
  public type: string = EDIT_FAILED;
  constructor(public payload: string) { }
}

export class deleteAction implements Action {
  public type: string = DELETE;
  constructor(public payload: EntrancePayload<string>) { }
}
export class deleteSuccessAction implements Action {
  public type: string = DELETE_SUCCESS;
  constructor(public payload: ResultPayload<string>) { }
}

export class deleteFailedAction implements Action {
  public type: string = DELETE_FAILED;
  constructor(public payload: ResultPayload<string>) { }
}


export class deleteRangeAction implements Action {
  public type: string = DELETE_RANGE;
  constructor(public payload: EntrancePayload<number[]>) { }
}
export class deleteRangeSuccessAction implements Action {
  public type: string = DELETE_RANGE_SUCCESS;
  constructor(public payload: ResultPayload<string>) { }
}

export class deleteRangeFailedAction implements Action {
  public type: string = DELETE_RANGE_FAILED;
  constructor(public payload: ResultPayload<string>) { }
}
export type Actions =
  loadEntryAction |
  loadDetailAction |
  loadDetailSuccessAction |
  loadDetailFailedAction |
  addAction |
  addSuccessAction |
  addFailedAction |
  editAction |
  editSuccessAction |
  editFailedAction |
  deleteAction |
  deleteFailedAction |
  deleteSuccessAction |
  deleteRangeAction |
  deleteRangeFailedAction |
  deleteRangeSuccessAction;
