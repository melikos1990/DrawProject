import { Component, Injector, Optional, Inject } from '@angular/core';
import { AuthenticationService } from 'src/app/shared/service/authentication.service';
import { BaseComponent, PREFIX_TOKEN } from './base.component';
import { AuthenticationType, Operator, User } from 'src/app/model/authorize.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-auth-base',
  template: '',
})
export class AuthBaseComponent extends BaseComponent {

  public authService: AuthenticationService = this.injector.get(AuthenticationService);

  constructor(
    public injector: Injector,
    @Optional() @Inject(PREFIX_TOKEN) public prefix?: string) {
    super(injector, prefix);
  }

  findAuth(operator: Operator, feature: string): AuthenticationType {

    if (!operator.Feature) {
      return null;
    }

    const target = operator.Feature.find(x => x.Feature === feature);

    if (target) {
      return target.AuthenticationType;
    }

    return null;
  }

  public hasAuth(operator: Operator, feature: string, authenticationType: AuthenticationType) {
    return this.authService.hasAuthentication(operator, feature, authenticationType);
  }

  public hasAuth$(authenticationType: AuthenticationType): Observable<boolean> {
    return this.getCurrentUser().pipe(
      map(user => this.hasAuth(user, this.featrueName, authenticationType))
    );
  }

  public getCurrentUser(): Observable<User> {
    return this.authService.getCompleteUser();
  }


}
