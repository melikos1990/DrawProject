import { Component, OnInit, Injector, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { loggerClass, loggerMethod } from 'src/app/shared/decorator/logger.decorator';
import { ActionType } from 'src/app/model/common.model';
import {  SystemParameterDetailViewModel } from 'src/app/model/system.model';
import * as fromSystemParameterActions from '../../store/actions/system-parameter.actions';
import { State as fromSystemReducer } from "../../store/reducers";
import { Store } from '@ngrx/store';
import { FormBaseComponent } from 'src/app/pages/base/form-base.component';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { AuthorizeMethod } from 'src/app/shared/decorator/authorize.decorator';
import { AuthenticationType } from 'src/app/model/authorize.model';
import * as fromRootActions from 'src/app/store/actions';


export const PREFIX = 'SystemParameterComponent';

@Component({
  selector: 'app-system-parameter-detail',
  templateUrl: './system-parameter-detail.component.html',
  styleUrls: ['./system-parameter-detail.component.scss']
})
@loggerClass()
export class SystemParameterDetailComponent extends FormBaseComponent implements OnInit, OnDestroy {


  form: FormGroup;

  public uiActionType: ActionType;
  public model: SystemParameterDetailViewModel = new SystemParameterDetailViewModel();

  model$: Subscription;

  constructor(
    private active: ActivatedRoute,
    private store: Store<fromSystemReducer>,
    public injector: Injector) {
    super(injector , '');

  }

  @loggerMethod()
  ngOnInit() {
    this.subscription();
    this.initializeForm();
  }



  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Read | AuthenticationType.Add)
  btnAdd($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }

    this.store.dispatch(new fromSystemParameterActions.addAction(this.model));

  }

  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Delete | AuthenticationType.Add)
  btnEdit($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }

    this.store.dispatch(new fromSystemParameterActions.editAction(this.model));
  }


  @loggerMethod()
  btnBack($event) {
    history.back();
  }

  subscription() {

    this.active.params.subscribe(this.loadPage.bind(this));

    this.model$ =
      this.store
        .select((state: fromSystemReducer) => state.system.systemParameter.detail)
        .subscribe(systemParameter => {
          this.model = { ...systemParameter };
        });
  }

  initializeForm() {
    this.form = new FormGroup({
      ID: new FormControl(this.model.ID, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      Key: new FormControl(this.model.Key, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      Text: new FormControl(this.model.Text, [
        Validators.required,
      ]),
      Value: new FormControl(this.model.Value, [
        Validators.required,
      ]),
      CreateUserName: new FormControl(),
      CreateDateTime: new FormControl(),
      UpdateUserName: new FormControl(),
      UpdateDateTime: new FormControl(),
    });

  }

  loadPage(params) {

    this.uiActionType = parseInt(params['actionType']);

    const payload = {
      ID: params['id'],
      Key: params['key']
    };

    switch (this.uiActionType) {
      case ActionType.Add:
        this.store.dispatch(new fromSystemParameterActions.loadEntryAction());
        break;
      case ActionType.Update:
        this.store.dispatch(new fromSystemParameterActions.loadDetailAction(payload));
        break;
      case ActionType.Read:
        this.store.dispatch(new fromSystemParameterActions.loadDetailAction(payload));
        break;
    }

  }

  ngOnDestroy() {
    this.model$ && this.model$.unsubscribe();
  }

}
