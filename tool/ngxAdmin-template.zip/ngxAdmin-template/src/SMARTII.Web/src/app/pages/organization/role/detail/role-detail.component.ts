import { Component, OnInit, Injector, ViewChild, TemplateRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActionType } from 'src/app/model/common.model';
import { RoleDetailViewModel, AuthenticationType, User } from 'src/app/model/authorize.model';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import * as fromRoleActions from "../../store/actions/role.actions";
import { State as fromOrganizationReducer } from "../../store/reducers";
import { loggerMethod } from 'src/app/shared/decorator/logger.decorator';
import { AuthorizeMethod } from 'src/app/shared/decorator/authorize.decorator';
import { FormBaseComponent } from 'src/app/pages/base/form-base.component';
import * as fromRootActions from "src/app/store/actions";
import { UserSelectorComponent } from '../modal/user-selector/user-selector.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

export const PREFIX = 'RoleComponent';

@Component({
  selector: 'app-role-detail',
  templateUrl: './role-detail.component.html',
  styleUrls: ['./role-detail.component.scss']
})
export class RoleDetailComponent extends FormBaseComponent implements OnInit {


  model$: Subscription;

  form: FormGroup;

  public uiActionType: ActionType;
  public model: RoleDetailViewModel = new RoleDetailViewModel();

  public options = {};

  constructor(
    private modalService: NgbModal,
    private active: ActivatedRoute,
    private store: Store<fromOrganizationReducer>,
    public injector: Injector
  ) {
    super(injector, PREFIX);

  }

  ngOnInit() {
    this.initializeForm();
    this.initializeTable();
    this.subscription();
  }

  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Read | AuthenticationType.Add)
  btnAdd($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }

    this.store.dispatch(new fromRoleActions.addAction(this.model));

  }


  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Update | AuthenticationType.Read)
  btnEdit($event) {

    if (this.validForm(this.form) === false) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(this.getFieldInvalidMessage()));
      return;
    }

    this.store.dispatch(new fromRoleActions.editAction(this.model));
  }

  @loggerMethod()
  @AuthorizeMethod(PREFIX, AuthenticationType.Update | AuthenticationType.Read)
  btnUserSelector($event) {

    const ref = this.modalService.open(UserSelectorComponent, { size: 'lg', container: 'nb-layout' });

    ref.componentInstance.btnAddUser = this.btnAddUser.bind(this);
  }
  @loggerMethod()
  btnAddUser($event, modalRef) {

    if (!$event) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(
        this.getFieldInvalidMessage(this.translateService.instant('ERROR.ATLEAST_ONE_TERM'))));
      return;
    }
    const isExist = this.model.Users.findIndex(x => x.UserID === $event.UserID) !== -1;

    if (isExist) {
      this.store.dispatch(new fromRootActions.AlertActions.alertOpenAction(
        this.getFieldInvalidMessage(this.translateService.instant('ERROR.ALREADY_EXIST'))));
    } else {
      this.model.Users = [...this.model.Users, $event];
      modalRef.close();
    }

  }

  @loggerMethod()
  btnBack($event) {
    history.back();
  }

  @loggerMethod()
  btnDeleteUser($event) {

    const index = this.model.Users.findIndex(x => x.UserID == $event.data.UserID);
    this.model.Users.splice(index, 1);
    $event.confirm.resolve();
  }


  initializeTable() {

    this.options = {
      columns: {
        UserName: {
          title: this.translateService.instant('USER.USER_NAME'),
          width: '20%',
        },
        Account: {
          title: this.translateService.instant('USER.ACCOUNT'),
          width: '20%',
        },
        IsAD: {
          title: this.translateService.instant('USER.IS_AD'),
          width: '20%',
        },
        IsEnabled: {
          title: this.translateService.instant('USER.IS_ENABLED'),
          width: '20%',
        },

      },
    };
  }

  initializeForm() {
    this.form = new FormGroup({

      Name: new FormControl(this.model.Name, [
        Validators.required,
        Validators.maxLength(50),

      ]),
      IsEnabled: new FormControl(this.model.IsEnable),
      CreateUserName: new FormControl(),
      CreateDateTime: new FormControl(),
      UpdateUserName: new FormControl(),
      UpdateDateTime: new FormControl(),
    });

  }

  subscription() {
    this.active.params.subscribe(this.loadPage.bind(this));

    this.model$ =
      this.store
        .select((state: fromOrganizationReducer) => state.organization.role.detail)
        .subscribe(role => {
          this.model = { ...role };
        });
  }

  loadPage(params) {
    this.uiActionType = parseInt(params['actionType']);

    const payload = {
      RoleID: params['id']
    };

    switch (this.uiActionType) {
      case ActionType.Add:
        this.store.dispatch(new fromRoleActions.loadEntryAction());
        break;
      case ActionType.Update:
        this.store.dispatch(new fromRoleActions.loadDetailAction(payload));
        break;
      case ActionType.Read:
        this.store.dispatch(new fromRoleActions.loadDetailAction(payload));
        break;
    }

  }

}
