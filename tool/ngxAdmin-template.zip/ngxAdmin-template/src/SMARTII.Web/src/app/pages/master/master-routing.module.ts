import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterComponent } from './master.component';
import { PersonalChangePasswordComponent } from './personal-change-password/personal-change-password.component';
import { AuthGuardService } from 'src/app/shared/service/auth-guard.service';


const routes: Routes = [{
  path: '',
  component: MasterComponent,
  children: [
    {
      path: 'personal-change-password',
      component: PersonalChangePasswordComponent,
      canActivate: [AuthGuardService],
      data: {
        breadcrumb: 'APPLICATION.FEATURE.PERAONAL_CHANGE_PASSWORD',
        feature: 'PersonalChangePasswordComponent'
      },
    },
  ],

}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [
    RouterModule
  ]
})
export class MasterRoutingModule { }
