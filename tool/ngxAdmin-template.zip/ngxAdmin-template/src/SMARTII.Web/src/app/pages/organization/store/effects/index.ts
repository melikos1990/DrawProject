import { UserEffects } from './user.effects';
import { RoleEffects } from './role.effects';

export const effects = [
  UserEffects,
  RoleEffects
];
