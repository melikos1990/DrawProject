import { Component, OnInit, OnDestroy, Injector, Inject } from '@angular/core';
import { Store } from '@ngrx/store';
import { State as fromRootReducer } from '../store/reducers'
import { Subscription } from 'rxjs';
import { BaseComponent } from './base/base.component';
import { Menu } from '../model/master.model';
import { NbMenuInternalService } from '@nebular/theme/components/menu/menu.service';
import { SignalRHubService } from '../shared/service/signalR.hub.service';
import { ObjectService } from '../shared/service/object.service';
import { LayoutBaseComponent } from './base/layout-base.component';
import { Location } from '@angular/common';
import { MENU_SELECT } from '../shared/shared.module';
import { IMenuSelect } from '../shared/service/menu-select.service';



@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent extends LayoutBaseComponent implements OnInit, OnDestroy {


  menu: Menu[];
  menu$: Subscription;
  signalr$: Subscription;

  constructor(
    @Inject(MENU_SELECT) public menuSelectService: IMenuSelect,
    public store: Store<fromRootReducer>,
    public menuService: NbMenuInternalService,
    public signalRService: SignalRHubService,
    public objectSercice: ObjectService,
    public location: Location,
    public injector: Injector) {
    super(injector, '');
  }

  ngOnInit() {

    this.menu$ =
      this.store.select((state: fromRootReducer) => state.auth.menu)
        .subscribe((data: Menu[]) => {
          this.menu = this.getTranslateMenu(data);

          setTimeout(() => {
            const subMenu = this.menuSelectService.matchItem(location.pathname, this.menu);
            this.menuService.prepareItems(this.menu);
            if (subMenu) {
              this.menuService.selectItem(subMenu, this.menu, false, 'menu');

            }

          }, 100);
        });

    this.signalr$ =
      this.signalRService.listener('ShowMessage').subscribe(x => {
        console.log('ShowMessage');
        console.log(x);

      });

  }


  ngOnDestroy() {
    this.menu$ && this.menu$.unsubscribe();

  }

}
