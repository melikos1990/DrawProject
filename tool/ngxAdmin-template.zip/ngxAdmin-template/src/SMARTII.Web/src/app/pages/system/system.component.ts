import { Component } from '@angular/core';

@Component({
  selector: 'app-system',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class SystemComponent {
}
