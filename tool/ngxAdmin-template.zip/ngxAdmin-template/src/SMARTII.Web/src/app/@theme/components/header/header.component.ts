import { Component, Input, OnInit, Injector, OnDestroy } from '@angular/core';

import { NbMenuService, NbSidebarService } from '@nebular/theme';
import { AnalyticsService } from '../../../@core/utils';
import { LayoutService } from '../../../@core/utils';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { Store } from '@ngrx/store';
import { State as fromRootReducers } from "../../../store/reducers";
import * as fromAuthActions from "../../../store/actions/auth.actions";
import * as fromAlertActions from "../../../store/actions/alert.actions";
import * as fromRouteActions from "../../../store/actions/route.actions";
import { Subscription, Observable } from 'rxjs';
import { User, Role } from 'src/app/model/authorize.model';
import { AuthenticationService } from 'src/app/shared/service/authentication.service';
import { LocalStorageService } from 'src/app/shared/service/local-storage.service';
import { PtcSwalType } from 'ptc-swal';



@Component({
  selector: 'ngx-header',
  styleUrls: ['./header.component.scss'],
  templateUrl: './header.component.html',
})
export class HeaderComponent extends BaseComponent implements OnInit, OnDestroy {


  @Input() position = 'normal';


  role: any = '';

  userRoles: Array<Role> = [];
  userMenu = [];

  user$: Observable<User>;
  roles$: Subscription;
  menu$: Subscription;

  constructor(
    private authService: AuthenticationService,
    private sidebarService: NbSidebarService,
    private menuService: NbMenuService,
    private analyticsService: AnalyticsService,
    private layoutService: LayoutService,
    private store: Store<fromRootReducers>,
    public injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.initialize();

  }


  initialize() {
    this.userMenu = [{ title: this.translateService.instant('COMMON.LOG_OFF'), id: 'logout' }];
    this.user$ = this.store.select((state: fromRootReducers) => state.auth.member);

    this.roles$ =
      this.authService.getRoles().subscribe(roles => {
        this.userRoles = roles;
        this.setSelectRoleValue();
      });


    this.menu$ =
      this.menuService
        .onItemClick()
        .subscribe(this.profileClick.bind(this));

  }

  toggleSidebar(): boolean {
    this.sidebarService.toggle(true, 'menu-sidebar');
    this.layoutService.changeLayoutSize();

    return false;
  }

  profileClick(value) {
    switch (value.item.id) {
      case 'logout':
        this.store.dispatch(new fromAuthActions.logOffAction());
        break;
    }
  }

  goToHome() {
    this.menuService.navigateHome();
  }

  startSearch() {
    this.analyticsService.trackEvent('startSearch');
  }


  setSelectRoleValue() {
    const cacheRole = this.authService.getCacheRoleID();
    this.role = cacheRole;

  }

  roleChange($event) {

    this.store.dispatch(new fromAlertActions.alertOpenAction(
      {
        detail: {
          title: this.translateService.instant('COMMON.ON_ROLE_CHANGE_HINT'),
          type: PtcSwalType.question,
          showCancelButton: true
        },
        isLoop: false,
        confirm: () => {
          this.authService.setCacheRoleID($event);
          this.store.dispatch(new fromRouteActions.changeRouteAction({
            url: './pages/home/summary',
            params: {}
          }));
          this.store.dispatch(new fromAuthActions.parseAuthAction());
        },
        cancel: () => {
          this.setSelectRoleValue();
        }
      }
    ));




  }
  ngOnDestroy() {
    this.menu$ && this.menu$.unsubscribe();
    this.roles$ && this.roles$.unsubscribe();
  }
}
