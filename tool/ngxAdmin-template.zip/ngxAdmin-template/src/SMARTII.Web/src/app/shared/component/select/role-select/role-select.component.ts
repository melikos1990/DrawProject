import { Component, OnInit, Input, Injector, forwardRef } from '@angular/core';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { HttpService } from 'src/app/shared/service/http.service';


export const INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => RoleSelectComponent),
  multi: true
};

@Component({
  selector: 'app-role-select',
  templateUrl: './role-select.component.html',
  styleUrls: ['./role-select.component.scss'],
  providers: [INPUT_CONTROL_VALUE_ACCESSOR]
})
export class RoleSelectComponent extends BaseComponent implements OnInit, ControlValueAccessor {

  @Input() multiple: boolean = false;
  @Input() placeholder: string = '';
  @Input() noDataText: string = '';
  @Input() searchText: string = '';

  public innerValue: [] = [];

  public isDisabled: boolean = false;

  public items: [] = [];

  public options = {
    url: "Organization/Role/GetAppRoles".toHostApiUrl(),
    method: "POST"
  };

  public onTouchedCallback: () => void = () => { };
  public onChangeCallback: (_: any) => void = (_: any) => { };

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(this.innerValue);
    }
  }
  constructor(
    public http: HttpService,
    public injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.http.post("Organization/Role/GetAppRoles", null, {}).subscribe((resp: any) => {
      this.items = resp.items;
      this.value = [...this.value];
    });
  }
  writeValue(obj: any): void {

    if (obj !== this.innerValue) {
      this.innerValue = obj;
    }
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }


}
