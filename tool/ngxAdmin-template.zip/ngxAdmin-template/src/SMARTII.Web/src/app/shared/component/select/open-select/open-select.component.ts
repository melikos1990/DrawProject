import { Component, OnInit, Injector, Input, forwardRef } from '@angular/core';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { SelectData } from 'ptc-select2';

export const INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => OpenSelectComponent),
  multi: true
};

@Component({
  selector: 'app-open-select',
  templateUrl: './open-select.component.html',
  styleUrls: ['./open-select.component.scss'],
  providers: [INPUT_CONTROL_VALUE_ACCESSOR]
})
export class OpenSelectComponent extends BaseComponent implements OnInit, ControlValueAccessor {

  @Input() mutiple: boolean = false;
  @Input() items : any[] = [];
  @Input() placeholder: string = '';

  public isDisabled: boolean = false;

  public onTouchedCallback: () => void = () => { };
  public onChangeCallback: (_: any) => void = (_: any) => { };



  get value(): any | any[] {
    return this.innerValue;
  }

  set value(v: any | any[]) {
    if (v !== this.innerValue) {
      this.innerValue = v;

      if (!this.mutiple) {
        this.selectValue = String(v);
      } else {
        this.selectValue = v;
      }
      this.onChangeCallback(this.innerValue);
    }
  }

  constructor(public injector: Injector) {
    super(injector);
  }
  public innerItems: any[] = [];
  public innerValue: any | any[];
  public selectValue: any | any[];

  ngOnInit() {

  }

  writeValue(obj: any): void {

    if (obj !== this.innerValue) {
      this.innerValue = obj;
      setTimeout(() => {
        if (!this.mutiple) {
          this.selectValue = String(obj);
        } else {
          if (obj) {
            this.selectValue = (<any[]>obj).map(x => x.toString());
          }
        }
      }, 0);
    }
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }
}
