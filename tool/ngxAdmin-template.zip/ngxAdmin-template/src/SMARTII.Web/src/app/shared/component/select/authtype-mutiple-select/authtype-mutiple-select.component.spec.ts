import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuthtypeMutipleSelectComponent } from './authtype-mutiple-select.component';

describe('AuthtypeMutipleSelectComponent', () => {
  let component: AuthtypeMutipleSelectComponent;
  let fixture: ComponentFixture<AuthtypeMutipleSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuthtypeMutipleSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuthtypeMutipleSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
