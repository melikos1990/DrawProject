import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OpenSelectComponent } from './open-select.component';

describe('OpenSelectComponent', () => {
  let component: OpenSelectComponent;
  let fixture: ComponentFixture<OpenSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OpenSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OpenSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
