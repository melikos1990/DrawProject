import { Component, OnInit, forwardRef, Injector, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { ChangeInfo } from 'ptc-select2';



export const INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => UserSelectComponent),
  multi: true
};


@Component({
  selector: 'app-user-select',
  templateUrl: './user-select.component.html',
  styleUrls: ['./user-select.component.scss'],
  providers: [INPUT_CONTROL_VALUE_ACCESSOR]
})
export class UserSelectComponent extends BaseComponent implements OnInit, ControlValueAccessor {

  @Input() placeholder: string = '';
  @Input() noDataText: string = '';
  @Input() searchText: string = '';
  @Output() itemChange: EventEmitter<ChangeInfo> = new EventEmitter();

  public innerValue;

  public isDisabled: boolean = false;

  public options = {
    url: "Organization/User/GetAppUsers".toHostApiUrl(),
    method: "POST"
  };

  public onTouchedCallback: () => void = () => { };
  public onChangeCallback: (_: any) => void = (_: any) => { };

  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(this.innerValue);
    }
  }
  constructor(
    public injector: Injector) {
    super(injector);
  }

  ngOnInit() {
  }

  onItemChange = ($event) => this.itemChange.emit($event);

  writeValue(obj: any): void {

    if (obj !== this.innerValue) {
      this.innerValue = obj;
    }
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }

}
