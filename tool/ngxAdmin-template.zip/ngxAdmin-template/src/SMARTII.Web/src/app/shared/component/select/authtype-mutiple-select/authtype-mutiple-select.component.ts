import { Component, OnInit, Injector, Input, EventEmitter, forwardRef } from '@angular/core';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';


export const INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => AuthtypeMutipleSelectComponent),
  multi: true
};
@Component({
  selector: 'app-authtype-mutiple-select',
  templateUrl: './authtype-mutiple-select.component.html',
  styleUrls: ['./authtype-mutiple-select.component.scss'],
  providers: [INPUT_CONTROL_VALUE_ACCESSOR]
})
export class AuthtypeMutipleSelectComponent extends BaseComponent implements OnInit, ControlValueAccessor {

  public isDisabled: boolean = false;
  public innerValue = null;


  public onTouchedCallback: () => void = () => { };
  public onChangeCallback: (_: any) => void = (_: any) => { };


  get value(): any {
    return this.innerValue;
  }

  set value(v: any) {
    if (v !== this.innerValue) {
      this.innerValue = v;
      this.onChangeCallback(this.innerValue);
    }
  }


  constructor(public injector: Injector) {
    super(injector, '');

  }

  ngOnInit() {

  }

  writeValue(obj: any): void {
    if (obj !== this.innerValue) {
      this.innerValue = obj;
    }
  }
  registerOnChange(fn: any): void {
    this.onChangeCallback = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouchedCallback = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.isDisabled = isDisabled;
  }


}
