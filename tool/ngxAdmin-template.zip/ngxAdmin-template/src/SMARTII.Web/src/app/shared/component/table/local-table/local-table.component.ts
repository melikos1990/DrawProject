import { Component, OnInit, Injector, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from 'src/app/pages/base/base.component';
import { LocalDataSource } from 'ng2-smart-table';

@Component({
  selector: 'app-local-table',
  templateUrl: './local-table.component.html',
  styleUrls: ['./local-table.component.scss']
})
export class LocalTableComponent extends BaseComponent implements OnInit {

  public defaultOpts;

  @Input() options: {} = {};

  public innerValue: [] = [];

  public source: LocalDataSource = new LocalDataSource();

  @Output() add: EventEmitter<any> = new EventEmitter();
  @Output() edit: EventEmitter<any> = new EventEmitter();
  @Output() delete: EventEmitter<any> = new EventEmitter();

  @Input()
  get data(): [] {

    return this.innerValue;
  }

  set data(v: []) {
    if (v !== undefined) {
      this.source.load(v);
      this.innerValue = v;
    }

  }

  constructor(public injector: Injector) {
    super(injector);
  }

  ngOnInit() {

    this.defaultOpts = {
      hideSubHeader: true,
      editable: false,
      actions: {
        position: 'right',
        columnTitle: this.translateService.instant('COMMON.ACTION'),
        edit: false,
        add: false
      },
      delete: {
        deleteButtonContent: '<i class="nb-trash"></i>',
        confirmDelete: true,
      },
    };

    this.options = { ...this.defaultOpts, ...this.options };

  }

  btnAdd($event) {
    this.add.emit($event);
  }
  btnDelete($event) {
    this.delete.emit($event);
  }
  btnEdit($event) {
    this.edit.emit($event);
  }


}
