import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationStart, ActivatedRoute } from '@angular/router';
import { State as fromRootReducer } from './store/reducers';
import { Store } from '@ngrx/store';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import * as fromRootAction from './store/actions';
import { AuthenticationService } from './shared/service/authentication.service';
import { CultureService } from './shared/service/culture.service';
import { BreadcrumbsService } from "ng6-breadcrumbs";
import { LocalStorageService } from './shared/service/local-storage.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, OnDestroy {

  culture$: Subscription;
  breadcrumbs$: Subscription;
  routeChange$: Subscription;
  routeStartup$: Subscription;
  signalr$: Subscription;

  constructor(
    private store: Store<fromRootReducer>,
    private auth: AuthenticationService,
    private localStorageService: LocalStorageService,
    private languageService: CultureService,
    private breadcrumbsService: BreadcrumbsService,
    private router: Router) {
  }


  ngOnInit(): void {

    this.subscription();
  }


  subscription() {
    this.culture$ =
      this.store.select((state: fromRootReducer) => state.app.cluture)
        .subscribe(this.setLang.bind(this));

    this.breadcrumbs$ =
      this.breadcrumbsService.get()
        .subscribe(breadcrumbs =>
          this.store.dispatch(new fromRootAction.RouteActions.changeBreadcrumbAction(breadcrumbs)));

    this.routeChange$ = this.store.select((state: fromRootReducer) => state.route.navigate)
      .pipe(
        filter(payload => payload != null)
      )
      .subscribe(payload => {
        this.router.navigate([payload.url, payload.params]);

      });

    this.routeStartup$ = this.router.events.pipe(
      filter(event => event instanceof NavigationStart))
      .subscribe((event: NavigationStart) => this.onPageChange(event));

  }

  onPageChange(event: NavigationStart) {
    console.log('onPageChange');
    if (event.url != '/') {
      // 重整畫面行為
      if (this.router.navigated === false) {
        this.onPageRefresh();
      }

      this.onPageRedirect();
    }
  }


  setLang(lang: string) {
    if (!lang) {
      this.languageService.setInitState();
    } else {
      this.languageService.setLang(lang);
      this.auth.setCacheLangKey(lang);
    }
  }

  onPageRefresh() {

    // 語系cache 回應
    const cacheLang = this.auth.getCacheLangKey();
    if (cacheLang) {
      this.store.dispatch(new fromRootAction.AppActions.changeCultureAction(cacheLang));
    }

    // 重新初始化Signalr連線
    this.store.dispatch(new fromRootAction.AuthActions.activateExistIdentity());
  }
  onPageRedirect() {
    this.store.dispatch(new fromRootAction.AuthActions.parseAuthAction());
  }

  ngOnDestroy(): void {
    this.routeChange$ && this.routeChange$.unsubscribe();
    this.routeStartup$ && this.routeStartup$.unsubscribe();
    this.breadcrumbs$ && this.breadcrumbs$.unsubscribe();
    this.culture$ && this.culture$.unsubscribe();
    this.signalr$ && this.signalr$.unsubscribe();
  }


}
