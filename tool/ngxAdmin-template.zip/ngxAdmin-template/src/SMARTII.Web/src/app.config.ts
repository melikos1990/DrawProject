

export const viewChangedError = "ExpressionChangedAfterItHasBeenCheckedError";
export const globalLang: string = 'zh-tw';

