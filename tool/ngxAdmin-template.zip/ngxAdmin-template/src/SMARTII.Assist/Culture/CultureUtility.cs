﻿using System.Web;
using SMARTII.Domain.Cache;

namespace SMARTII.Assist.Culture
{
    public static class CultureUtility
    {
        public static void DetectionCulture(this HttpRequest request)
        {
           
            // 取得語系
            var cultureName = request.Headers[GlobalizationCache.CultureKey];

            // 設定語系
            if (string.IsNullOrEmpty(cultureName) == false)
            {
                // 語系定義相關轉換功能
                System.Threading.Thread.CurrentThread.CurrentCulture =
                    new System.Globalization.CultureInfo(cultureName);

                // 設定語系定義檔
                System.Threading.Thread.CurrentThread.CurrentUICulture =
                    new System.Globalization.CultureInfo(cultureName);
            }
        }
    }
}
