﻿using Autofac;
using SMARTII.Domain.Notification;
using SMARTII.Service.Notification;

namespace SMARTII.Assist.DI
{
    public class NotificationModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SignalRFactory>().As<INotificationFactory>()
                   .Keyed<INotificationFactory>(NotificationType.UI)
                   .InstancePerDependency();
        }
    }
}
