﻿using Autofac;
using SMARTII.Assist.Authentication;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Authentication.Service;

namespace SMARTII.Assist.DI
{
    public class AuthenticationModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SystemAccountFactory>().As<IAccountFactory>()
                   .Keyed<IAccountFactory>(UserType.System)
                   .InstancePerDependency();

            builder.RegisterType<ADAccountFactory>().As<IAccountFactory>()
                  .Keyed<IAccountFactory>(UserType.AD)
                  .InstancePerDependency();

         
        }

    }
}
