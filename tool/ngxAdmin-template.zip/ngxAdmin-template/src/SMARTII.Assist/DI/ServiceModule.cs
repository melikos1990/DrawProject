﻿using System.Reflection;
using Autofac;
using Autofac.Extras.AggregateService;
using Autofac.Integration.WebApi;
using Ptc.Data.Condition2.Mssql.DI;
using SMARTII.Assist.Authentication;
using SMARTII.Assist.Logger;
using SMARTII.Domain.Common;
using SMARTII.Domain.Notification;
using SMARTII.Domain.Organization;
using SMARTII.Domain.System;

namespace SMARTII.Assist.DI
{
    public class ServiceModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            Assembly[] assemblies = new Assembly[]
            {
                 Assembly.Load("SMARTII.Domain"),
                 Assembly.Load("SMARTII.Service"),
                 Assembly.Load("SMARTII.Assist"),
            };

          
            
            builder.RegisterAggregateService<ICommonAggregate>();
            builder.RegisterAggregateService<IOrganizationAggregate>();           
            builder.RegisterAggregateService<ISystemAggregate>();
            builder.RegisterAggregateService<INotificationAggregate>();

            builder.Register(x => Ptc.Logger.NLogManager.CreateInstance().SystemLog)
                   .As<Ptc.Logger.ILogger>()
                   .InstancePerLifetimeScope(); 

            builder.RegisterType<AuthenticationAttribute>().PropertiesAutowired();
            builder.RegisterType<LoggerAttribute>().PropertiesAutowired();
            builder.RegisterType<AuthenticationMethodAttribute>().PropertiesAutowired();
            builder.RegisterType<AccountBase>().PropertiesAutowired();

            builder.RegisterModule(new MSSQLModule());
            builder.RegisterModule(new NotificationModule());
            builder.RegisterModule(new AuthenticationModule());

            builder.RegisterAssemblyTypes(assemblies)
                   .AsImplementedInterfaces()
                   .InstancePerLifetimeScope();
        }


    }
}
