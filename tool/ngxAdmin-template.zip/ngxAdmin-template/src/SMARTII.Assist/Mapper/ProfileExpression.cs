﻿using AutoMapper;

namespace SMARTII.Assist.Mapper
{
    public class ProfileExpression : Domain.Mapper.IProfileExpression
    {
        public void AddProfile(IMapperConfigurationExpression expression)
        {
            /////////////// MASTER PROFILES ///////////////////
            expression.AddProfile<MasterProfile.QuestionClassificationProfile>();
            expression.AddProfile<MasterProfile.QuestionClassificationAnswerProfile>();

            ////////////// SYSTEM PROFILES ////////////////////
            expression.AddProfile<SystemProfile.SystemFeatureProfile>();
            expression.AddProfile<SystemProfile.SystemParameterProfile>();
            expression.AddProfile<SystemProfile.SystemLogProfile>();

            /////////////// ORGANIZATION PROFILES ///////////////
            expression.AddProfile<OrganizationProfile.UserProfile>();
            expression.AddProfile<OrganizationProfile.RoleProfile>();
        }
    }
}
