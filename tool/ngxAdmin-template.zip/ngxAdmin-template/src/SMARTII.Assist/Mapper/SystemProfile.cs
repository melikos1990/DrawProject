﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.System;

namespace SMARTII.Assist.Mapper
{
    public static class SystemProfile
    {

        public class SystemParameterProfile : AutoMapper.Profile
        {
            public SystemParameterProfile()
            {

                CreateMap<SYSTEM_PARAMETER, SystemParameter>()
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))
                     .ForMember(dest => dest.UpdateDateTime, opt => opt.MapFrom(src => src.UPDATE_DATETIME))
                     .ForMember(dest => dest.UpdateUserName, opt => opt.MapFrom(src => src.UPDATE_USERNAME))
                     .ForMember(dest => dest.ID, opt => opt.MapFrom(src => src.ID))
                     .ForMember(dest => dest.Key, opt => opt.MapFrom(src => src.KEY))
                     .ForMember(dest => dest.Value, opt => opt.MapFrom(src => src.VALUE))
                     .ForMember(dest => dest.Text, opt => opt.MapFrom(src => src.TEXT))
                     .IgnoreAllNonExisting()
                     .ReverseMap();

            }

        }

        public class SystemFeatureProfile : AutoMapper.Profile
        {
            public SystemFeatureProfile()
            {

                CreateMap<SYSTEM_FEATURE, SystemFeature>()
                     .ForMember(dest => dest.ID, opt => opt.MapFrom(src => src.ID))
                     .ForMember(dest => dest.Children, opt => opt.MapFrom(src => src.SYSTEM_FEATURE1))
                     .ForMember(dest => dest.DisplayName, opt => opt.MapFrom(src => src.DISPLAY_NAME))
                     .ForMember(dest => dest.IsEnabled, opt => opt.MapFrom(src => src.IS_ENABLED))
                     .ForMember(dest => dest.IsLink, opt => opt.MapFrom(src => src.IS_LINK))
                     .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.NAME))
                     .ForMember(dest => dest.Operator, opt => opt.MapFrom(src => (AuthenticationType)src.OPERATOR))
                     .ForMember(dest => dest.Order, opt => opt.MapFrom(src => src.ORDER))
                     .ForMember(dest => dest.Parent, opt => opt.MapFrom(src => src.SYSTEM_FEATURE2))
                     .ForMember(dest => dest.ParentID, opt => opt.MapFrom(src => src.PARENT_ID))
                     .ForMember(dest => dest.RoutePath, opt => opt.MapFrom(src => src.ROUTE_PATH))
                     .ReverseMap()
                     .ForPath(dest => dest.OPERATOR, opt => opt.MapFrom(src => (int)src.Operator))
                     .IgnoreAllNonExisting();

            }

        }

        public class SystemLogProfile : AutoMapper.Profile
        {
            public SystemLogProfile()
            {

                CreateMap<SYSTEM_LOG, SystemLog>()
                     .ForMember(dest => dest.ID, opt => opt.MapFrom(src => src.ID))
                     .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.CONTENT))
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserAccount, opt => opt.MapFrom(src => src.CREATE_USER_ACCOUNT))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))
                     .ForMember(dest => dest.FeatureName, opt => opt.MapFrom(src => src.FEATURE_NAME))
                     .ForMember(dest => dest.FeatureTag, opt => opt.MapFrom(src => src.FEATURE_TAG))
                     .ForMember(dest => dest.Operator, opt => opt.MapFrom(src => (AuthenticationType)src.OPERATOR))
                     .ReverseMap()
                     .ForPath(dest => dest.OPERATOR, opt => opt.MapFrom(src => (int)src.Operator))
                     .IgnoreAllNonExisting();

            }

        }

    }
}
