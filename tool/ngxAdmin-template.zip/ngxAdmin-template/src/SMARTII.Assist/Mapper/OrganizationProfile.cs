﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Organization;

namespace SMARTII.Assist.Mapper
{
    public static class OrganizationProfile
    {

        public class UserProfile : AutoMapper.Profile
        {
            public UserProfile()
            {

                CreateMap<USER, User>()
                     .ForMember(dest => dest.UserID, opt => opt.MapFrom(src => src.USER_ID))
                     .ForMember(dest => dest.Account, opt => opt.MapFrom(src => src.ACCOUNT))
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))
                     .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.EMAIL))
                     .ForMember(dest => dest.Gender, opt => opt.MapFrom(src => src.GENDER))
                     .ForMember(dest => dest.IsAD, opt => opt.MapFrom(src => src.IS_AD))
                     .ForMember(dest => dest.IsEnabled, opt => opt.MapFrom(src => src.IS_ENABLED))
                     .ForMember(dest => dest.LockoutDateTime, opt => opt.MapFrom(src => src.LOCKOUT_DATETIME))
                     .ForMember(dest => dest.LastChangePasswordDateTime, opt => opt.MapFrom(src => src.LAST_CHANGE_PASSWORD_DATETIME))
                     .ForMember(dest => dest.Telephone, opt => opt.MapFrom(src => src.TELEPHONE))
                     .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.NAME))
                     .ForMember(dest => dest.PushID, opt => opt.MapFrom(src => src.PUSH_ID))
                     .ForMember(dest => dest.ImagePath, opt => opt.MapFrom(src => src.IMAGE_PATH))
                     .ForMember(dest => dest.Password, opt => opt.MapFrom(src => src.PASSWORD))
                     .ForMember(dest => dest.UpdateDateTime, opt => opt.MapFrom(src => src.UPDATE_DATETIME))
                     .ForMember(dest => dest.UpdateUserName, opt => opt.MapFrom(src => src.UPDATE_USERNAME))
                     .ForMember(dest => dest.Roles, opt => opt.MapFrom(src => src.ROLE))
                     .ForMember(dest => dest.Feature, opt => opt.MapFrom(src => string.IsNullOrEmpty(src.FEATURE) ? 
                        new List<PageAuth>() : JsonConvert.DeserializeObject<List<PageAuth>>(src.FEATURE)))                     
                     .ForMember(dest => dest.PastPasswordQueue, opt => opt.MapFrom(src => string.IsNullOrEmpty(src.PAST_PASSWORD_RECORD) ?
                        new PasswordQueue() : new PasswordQueue(JsonConvert.DeserializeObject<string[]>(src.PAST_PASSWORD_RECORD))))
                     .ReverseMap()
                      .ForPath(dest => dest.FEATURE ,  opt => opt.MapFrom(src => src.Feature == null ?
                        JsonConvert.SerializeObject(new PageAuth[] { }) : JsonConvert.SerializeObject(src.Feature.ToArray())))
                     .ForPath(dest => dest.PAST_PASSWORD_RECORD, opt => opt.MapFrom(src => src.PastPasswordQueue == null ? 
                        JsonConvert.SerializeObject(new string[] { }) : JsonConvert.SerializeObject(src.PastPasswordQueue.ToArray())))
                     .IgnoreAllNonExisting();



            }

        }

        public class RoleProfile : AutoMapper.Profile
        {
            public RoleProfile()
            {

                CreateMap<ROLE, Role>()
                     .ForMember(dest => dest.UpdateDateTime, opt => opt.MapFrom(src => src.UPDATE_DATETIME))
                     .ForMember(dest => dest.UpdateUserName, opt => opt.MapFrom(src => src.UPDATE_USERNAME))
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))                 
                     .ForMember(dest => dest.IsEnabled, opt => opt.MapFrom(src => src.IS_ENABLED))                
                     .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.NAME))
                     .ForMember(dest => dest.Users, opt => opt.MapFrom(src => src.USER))
                     .ForMember(dest => dest.Feature, opt => opt.MapFrom(src => string.IsNullOrEmpty(src.FEATURE) ?
                        new List<PageAuth>() : JsonConvert.DeserializeObject<List<PageAuth>>(src.FEATURE)))
                     .ReverseMap()
                      .ForPath(dest => dest.FEATURE, opt => opt.MapFrom(src => src.Feature == null ?
                      JsonConvert.SerializeObject(new PageAuth[] { }) : JsonConvert.SerializeObject(src.Feature.ToArray())))
                     .IgnoreAllNonExisting();



            }

        }
    }
}
