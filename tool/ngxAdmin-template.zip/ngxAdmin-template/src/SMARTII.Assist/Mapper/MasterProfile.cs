﻿using SMARTII.Database.SMARTII;
using SMARTII.Domain.Master;
using SMARTII.Domain.Organization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Assist.Mapper
{
    public static class MasterProfile
    {

      
        public class QuestionClassificationProfile : AutoMapper.Profile
        {
            public QuestionClassificationProfile()
            {

                CreateMap<QUESTION_CLASSIFICATION, QuestionClassification>()
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))
                     .ForMember(dest => dest.HeaderQuarterNode, opt => opt.MapFrom(src => src.HEADQUARTERS_NODE))
                     .ForMember(dest => dest.ID, opt => opt.MapFrom(src => src.ID))
                     .ForMember(dest => dest.IsEnabled, opt => opt.MapFrom(src => src.IS_ENABLED))
                     .ForMember(dest => dest.Name, opt => opt.MapFrom(src => src.NAME))
                     .ForMember(dest => dest.NodeID, opt => opt.MapFrom(src => src.NODE_ID))
                     .ForMember(dest => dest.OrganizationType, opt => opt.MapFrom(src => (OrganizationType)src.ORGANIZATION_TYPE))
                     .ForMember(dest => dest.ParentID, opt => opt.MapFrom(src => src.PARENT_ID))
                     .ForMember(dest => dest.Children, opt => opt.MapFrom(src => src.QUESTION_CLASSIFICATION1))
                     .ForMember(dest => dest.Parent, opt => opt.MapFrom(src => src.QUESTION_CLASSIFICATION2))
                     .ForMember(dest => dest.QuesionClassificationAnswer, opt => opt.MapFrom(src => src.QUESTION_CLASSIFICATION_ANSWER))
                     .ForMember(dest => dest.UpdateDateTime, opt => opt.MapFrom(src => src.UPDATE_DATETIME))
                     .ForMember(dest => dest.UpdateUserName, opt => opt.MapFrom(src => src.UPDATE_USERNAME))
                     .ReverseMap()
                     .ForPath(dest => dest.ORGANIZATION_TYPE, opt => opt.MapFrom(src => (byte)src.OrganizationType))
                     .IgnoreAllNonExisting();



            }

        }


        public class QuestionClassificationAnswerProfile : AutoMapper.Profile
        {
            public QuestionClassificationAnswerProfile()
            {

                CreateMap<QUESTION_CLASSIFICATION_ANSWER, QuestionClassificationAnswer>()
                     .ForMember(dest => dest.CreateDateTime, opt => opt.MapFrom(src => src.CREATE_DATETIME))
                     .ForMember(dest => dest.CreateUserName, opt => opt.MapFrom(src => src.CREATE_USERNAME))
                     .ForMember(dest => dest.ID, opt => opt.MapFrom(src => src.ID))
                     .ForMember(dest => dest.IsEnabled, opt => opt.MapFrom(src => src.IS_ENABLED))
                     .ForMember(dest => dest.NodeID, opt => opt.MapFrom(src => src.NODE_ID))
                     .ForMember(dest => dest.OrganizationType, opt => opt.MapFrom(src => (OrganizationType)src.ORGANIZATION_TYPE))
                     .ForMember(dest => dest.UpdateDateTime, opt => opt.MapFrom(src => src.UPDATE_DATETIME))
                     .ForMember(dest => dest.UpdateUserName, opt => opt.MapFrom(src => src.UPDATE_USERNAME))
                     .ReverseMap()
                     .ForPath(dest => dest.ORGANIZATION_TYPE, opt => opt.MapFrom(src => (byte)src.OrganizationType))
                     .IgnoreAllNonExisting();



            }

        }

    }
}
