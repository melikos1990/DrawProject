﻿using System.Threading.Tasks;
using Ptc.Data.Condition2.Mssql.Class;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Organization;
using SMARTII.Domain.Thread;

namespace SMARTII.Assist.Authentication
{
    public class AccountBase
    {
        public LDAPHelper AD = new LDAPHelper();

  
        /// <summary>
        /// 是否為AD 使用者
        /// </summary>
        /// <param name="account"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool IsADUser(string account, string password)
        {
            var adUser = AD.IsAdUser(account, password);

            return !!adUser;
        }
    }
}
