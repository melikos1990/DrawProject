﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ptc.Data.Condition2.Mssql.Class;
using SMARTII.Database.SMARTII;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Organization;
using SMARTII.Domain.Security;
using SMARTII.Resource.Error;

namespace SMARTII.Assist.Authentication
{
    public class ADAccountFactory : AccountBase, IAccountFactory
    {
        public User Login(User user, string password)
        {
            if (IsADUser(user.Account, password) == false)
                throw new Exception(Error.AD_USER_NULL);


            return user;

 
        }
    }
}
