﻿using System.Security.Principal;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Organization;

namespace SMARTII.Assist.Authentication
{
    public class PrincipalManager : IPrincipalManager
    {
        private readonly ITokenManager _TokenManager;

        public PrincipalManager(ITokenManager TokenManager)
        {
            _TokenManager = TokenManager;
        }

        public IPrincipal Generator(string token)
        {
            var user = _TokenManager.Parse<User>(token);

            var identity = new UserIdentity(user, System.Threading.Thread.CurrentPrincipal.Identity);

            var principal = new GenericPrincipal(identity, null);

            return principal;
        }
    }
}
