﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Service;
using SMARTII.Domain.Data;
using SMARTII.Resource.Error;

namespace SMARTII.Assist.Authentication
{
    public class AuthenticationAttribute : AuthorizeAttribute
    {
        public IPrincipalManager _PrincipalManager { get; set; }

        public ITokenManager _TokenManager { get; set; }

        public IUserAuthenticationManager _UserAuthenticationValidator { get; set; }

        public override void OnAuthorization(HttpActionContext context)
        {
            try
            {
                var authorization = context.Request.Headers.Authorization;

                // 驗證token
                _TokenManager.DetectHeaderInfo(context);

                // 產生憑證資訊
                var principal = _PrincipalManager.Generator(authorization.Parameter);

                // TODO: 使用者認證
                //_UserAuthenticationValidator

                // 回填憑證
                System.Threading.Thread.CurrentPrincipal = principal;

                if (HttpContext.Current != null)
                    HttpContext.Current.User = principal;
            }
            catch (Microsoft.IdentityModel.Tokens.SecurityTokenExpiredException ex)
            {
                context.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                {
                    Content = new ObjectContent<IStandardResult>(new HttpJsonResult()
                    {
                        isSuccess = false,
                        message = $"{Error.AUTH_TOKEN_TIMOUT} , {ex.Message}"
                    },
                   new JsonMediaTypeFormatter())
                };

                return;
            }
            catch (Exception ex)
            {
                context.Response = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                {
                    Content = new ObjectContent<IStandardResult>(new HttpJsonResult()
                    {
                        isSuccess = false,
                        message = ex.Message
                    },
                    new JsonMediaTypeFormatter())
                };

                return;
            }
        }
    }
}
