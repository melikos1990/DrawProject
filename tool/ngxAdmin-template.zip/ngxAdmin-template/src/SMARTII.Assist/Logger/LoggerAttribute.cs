﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;
using SMARTII.Assist.Authentication;
using SMARTII.Domain.Authentication;
using SMARTII.Domain.Authentication.Object;
using SMARTII.Domain.Common;
using SMARTII.Domain.Data;
using SMARTII.Domain.System;
using SMARTII.Domain.Thread;
using SMARTII.Resource.Tag;

namespace SMARTII.Assist.Logger
{
    public class LoggerAttribute : ActionFilterAttribute
    {
        public readonly string FeatureTag;

        public ICommonAggregate _ICommonAggregateService { get; set; }

        public ISystemAggregate _ISystemAggregateService { get; set; }

        public LoggerAttribute()
        {
        }

        public LoggerAttribute(string featureTag)
        {
            FeatureTag = featureTag;
        }

        public override void OnActionExecuting(HttpActionContext context)
        {

            
            var featureName = Feature.ResourceManager.GetString(FeatureTag, new CultureInfo("zh-TW", false));

            Type controllerType = context.GetControllerType();

            var actionName = (context.ActionDescriptor as ReflectedHttpActionDescriptor).MethodInfo?.Name;

            MethodInfo methodInfo = controllerType.GetMethod(actionName);

            var attributes = methodInfo?.GetCustomAttributes<AuthenticationMethodAttribute>().ToList();

            var attribute = attributes.FirstOrDefault();

            var apiController = (context.ControllerContext.Controller as ApiController);

            var userInfo = apiController.User.Identity as UserIdentity;

            var log = new SystemLog()
            {
                CreateDateTime = DateTime.Now,
                CreateUserName = userInfo == null ? null : userInfo.Name,
                CreateUserAccount = userInfo == null ? null : userInfo.Account,
                FeatureTag = FeatureTag,
                FeatureName = featureName,
                Content = context.ActionArguments.DisplayFromHttpParamter(),
                Operator = attribute == null ? AuthenticationType.None : attribute.AuthenticationType,
            };

  
            _ISystemAggregateService.Async_SystemLog_T1_T2_.AddAsync(log);

            base.OnActionExecuting(context);
        }
    }
}
