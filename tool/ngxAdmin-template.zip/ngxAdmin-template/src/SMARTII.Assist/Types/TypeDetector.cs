﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Web;
using SMARTII.Assist.Logger;
using SMARTII.Domain.Cache;
using SMARTII.Resource.Tag;

namespace SMARTII.Assist.Types
{
    public static class TypeDetector
    {
        private static string GetServiceNameFromHttpHeader()
        {
            return HttpContext.Current.Request.Headers[GlobalizationCache.ServiceKey];
        }

        private static Type FindConcreteType(this Assembly assembly, Type type)
        {
            return assembly.GetTypes()
                           .First(p => p.IsInterface == false &&
                                       type.IsAssignableFrom(p));
        }

        private static Type FindConcreteType(this Assembly assembly, Type type, string name)
        {
            return assembly.GetTypes()
                           .First(p => p.IsInterface == false &&
                                       type.IsAssignableFrom(p) &&
                                       p.Name == name);
        }

        public static Type TryGetConcreteType(this Type type)
        {
            if (type.IsInterface == false || type.IsGenericType)
                return type;

            var serviceName = GetServiceNameFromHttpHeader();

            if (string.IsNullOrEmpty(serviceName))
                return type;

            if (GlobalizationCache
                .Instance
                .AssemblyDict
                .TryGetValue(serviceName, out Assembly serviceAssembly) == false)
                return type;

            var concrete = serviceAssembly.FindConcreteType(type);

            return concrete;
        }

        public static Dictionary<string, string> GetControllerTagDict(this Assembly[] assemblies)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();

            foreach (var assem in assemblies)
            {
                var controllerTypes = assem.GetExportedTypes()
                                     .Where(x => x.Name.Contains("Controller"));

                foreach (var type in controllerTypes)
                {
                    var methods = type.GetMethods();

                    methods.ToList().ForEach(x =>
                    {
                        var attr = x.GetCustomAttribute<LoggerAttribute>();

                        if (attr == null) return;

                        var name = Feature.ResourceManager.GetString(attr.FeatureTag,
                            new CultureInfo("zh-TW", false));

                        dict.Add(attr.FeatureTag, name);
                    });
                }
            }

            return dict;
        }
    }
}
