﻿using System.Web.Http;
using SMARTII.Assist.Authentication;
using SMARTII.Assist.Web;

namespace SMARTII.ASO.Controllers
{
    [Authentication]
    [RoutePrefix("Api/ASO")]
    public class ASO_MasterController : BaseApiController
    {

        public ASO_MasterController()
        {

        }

        
        [Route("Get")]
        [HttpGet]
        public void Get()
        {

            var user = this.UserIdentity.Instance;

        }
    }
}
