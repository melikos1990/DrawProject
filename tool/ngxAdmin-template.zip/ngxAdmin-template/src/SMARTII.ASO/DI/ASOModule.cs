﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Autofac;

namespace SMARTII.ASO.DI
{

    public class ASOModule : Autofac.Module
    {
        protected override void Load(ContainerBuilder builder)
        {

            var currentAssembly = System.Reflection.Assembly.GetExecutingAssembly();

            builder.RegisterAssemblyTypes(currentAssembly)
                   .AsImplementedInterfaces()
                   .InstancePerLifetimeScope();
        }

    }
}
