﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMARTII.Database.SMARTII
{
    public partial class SMARTIIEntities
    {
        public SMARTIIEntities(string conn) : base(conn)
        {

        }
    }
}
