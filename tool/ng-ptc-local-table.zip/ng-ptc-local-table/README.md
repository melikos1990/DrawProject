# ptc-local-Table

###`import { PtcLocalTableModule } from 'ptc-local-table'`



## 描述

**用途** 該套件為本地端渲染表格 , 具有分頁 , 排序 , 切換頁面長度 ...等功能 

**整合內容** 元件內部整合 meterial 樣式與 cdk tool

**參考文獻** 
> [mat-table](https://material.angular.io/components/table/overview "Title")  表格主體
> 
> [sort-header](https://material.angular.io/components/sort/overview) 排序表頭
> 
> [paginator](https://material.angular.io/components/sort/overview) 切頁功能



## 屬性
| 屬性定義           | 名稱 | 型態 | 預設值 | 描述
|--------------|:-----:|:-----:| :-------:|------------------------
| @Input()    |  column |  any[] |  [] | 物件內容如下 ： <br> `text` : 標頭名稱 <br> `name` : 表頭定義 <br>**`name不得重複`** <br> 目前定義兩種模式 (name） <br> `p-check` : 定義為勾選欄位 <br> `p-operator` : 定義為按鈕操作欄位 <br> `其他` : 一般文字輸出(預設)
| @Input()    | data |  any[] | [] | 資料清單可為任何物件之陣列  <br> **欄位屬性需與表頭定義`name`相同**
| @Input()   | pageIndex | number |  0 | 定義當前頁數    
| @Input()   | pageSize | number |  0 | 定義頁面長度
| @Input()   | pageSizeOptions | number[] | [] | 傳入頁面長度之選單 , 例如: ```[5,20,30]```
| @Input()   | isVisibleBtnSearch | boolean |  true |  於  `p-operator` 生效 <br> 是否顯示查詢按鈕
| @Input()   | isVisibleBtnDelete | boolean |  true |  於  `p-operator` 生效 <br> 是否顯示刪除按鈕
| @Input()   | isVisibleBtnEdit | boolean | true |  於  `p-operator` 生效 <br> 是否顯示編輯按鈕
| @Input()   | height | string |  null | 定義表格最高高度 , 若超出則scroll    
| @Input()   | noDataLabel | string |  '無資料'  | 無資料時呈現文字 
| @Input()   | lastPageLabel | string |  null  | 往最後一頁按鈕之tooltip 
| @Input()   | nextPageLabel | string |  null  | 往下一頁按鈕之tooltip 
| @Input()   | previousPageLabel | string |  null  | 往上一頁按鈕之tooltip 
| @Input()   | firstPageLabel | string |  null  | 往第一頁按鈕之tooltip 
| @Input()   | itemsPerPageLabel | string |  '分頁筆數'  | 分頁筆數呈現文字
| @Input()   | setRangeLabel | (page: `number`, pageSize: `umber`, length: `number`) => `string` |  {`起始筆數`} - {`最後筆數`} of {`總共筆數`}   | 呈現分頁資訊
| @Output()    | onBtnDelete | EventEmitter<`any`> |   | 於 `p-operator` 生效 <br> 按下刪除按鈕後回呼事件
| @Output()    | onBtnEdit | EventEmitter<`any`> |  | 於 `p-operator` 生效 <br> 按下編輯按鈕後回呼事件
| @Output()   | onBtnSearch | EventEmitter<`any`> |   | 於 `p-operator` 生效 <br> 按下查詢按鈕後回呼事件
| @Output()   | onPageChange | EventEmitter<`any`> |   | 當切換頁面大小時,觸發的回呼事件


## 方法

| 名稱 | 型態 | 描述 |
|:-----:|:-----:|-------|
| getSelectRows |  any[] | 於  `p-check` 生效 <br> 取得勾選之項目
| clearItems |  any[] | 於  `p-check` 生效 <br> 清除勾選之項目|

## 使用方式（範例）

> app.module.ts

```javascript
import { PtcLocalTableModule } from './core/ptc-local-table.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  
  imports: [  
	 ...
    PtcLocalTableModule //add this line.
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }


```

> app.component.ts

```javascript

import { PtcLocalTableModule } from 'ptc-local-table';

// 定義自訂資料格式
export interface TestClass {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

@Component({
  ...
})
export class AppComponent {
	
	//訂自資料來源
	data : TestClass[] = [
    { position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { position: 11, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
  ];
	
	// 定義表格渲染方式
	columns = [
    {
      text: '全選',
      name: 'p-check' // it will render checkbox.
    },
    {
      text: '序號',
      name: 'position',

    },
    {
      text: '名稱',
      name: 'name',

    },
    {
      text: '比重',
      name: 'weight',

    },
    {
      text: '前綴',
      name: 'symbol',

    },
    {
      text: '操作',
      name: 'p-operator', // it will render btn group.

    },
  ]
...

}


```

> app.component.html

```html

<!-- table -->
<app-ptc-local-table #ptcLocalTable            
                     [pageIndex]="1" 
                     [pageSize]="20"
                     [columns]="columns"
                     [pageSizeOptions] = "[5,20,30]"
                     [data]="data">                 
</app-ptc-local-table> 
<!-- end table -->

```

> index.html

``` html

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>TestCore</title>
  <base href="/">
  <!-- add this line-->
  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500" rel="stylesheet">
  <!-- add this line-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
</head>
<body>
  <app-root></app-root>
</body>
</html>


```

## 結果展示

![demo](http://tfs2:8080/tfs/SD4-Collection/d51ad450-3c10-43e1-9da4-bd10ee9747f9/_api/_versioncontrol/itemContent?repositoryId=7e451844-6292-47ea-84ca-816ae95b5288&path=%2FDemo1.gif&version=GBmaster&contentOnly=true&__v=5)
