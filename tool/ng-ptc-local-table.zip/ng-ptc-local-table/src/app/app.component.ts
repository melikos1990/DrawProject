import { Component, ViewChild, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { PtcLocalTableComponent } from './core/ptc-local-table/ptc-local-table.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  @ViewChild('ptcLocalTable') ptcLocalTable: PtcLocalTableComponent;

  data: TestClass[] = [
    { IsRowFocus: true, position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { IsRowFocus: true, position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { IsRowFocus: true, position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { IsRowFocus: true, position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { IsRowFocus: true, position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { IsRowFocus: true, position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { IsRowFocus: true, position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { IsRowFocus: true, position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { IsRowFocus: true, position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { IsRowFocus: true, position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: false, position: 11, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
  ];
  columns = [
    {
      text: '全選',
      name: 'p-check' // it will render checkbox
    },
    {
      text: '是否標示',
      name: 'IsRowFocus'
    },
    {
      text: '序號',
      name: 'position',

    },
    {
      text: '名稱',
      name: 'name',

    },
    {
      text: '比重',
      name: 'weight',

    },
    {
      text: '前綴',
      name: 'symbol',

    },
    {
      text: '前綴1',
      name: 'col2',
      customer: true,
    },
    {
      text: '操作',
      name: 'p-operator', // it will render btn group

    },
  ]

  pageSizeOptions = [5, 10, 20];
  pageSize = 5;
  pageIndex = 2;


  onPageChange($event) {
    alert('page-change' + JSON.stringify($event));
  }
  onBtnDelete($event) {
    alert('btn-delete' + JSON.stringify($event));
  }
  onBtnSearch($event) {
    alert('btn-serach' + JSON.stringify($event));
  }
  onBtnEdit($event) {
    alert('btn-edit' + JSON.stringify($event));
  }


  setRangeLabel(page: number, pageSize: number, length: number): string {
    if (length == 0 || pageSize == 0) {
      return `0 of ${length}`;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `第 ${startIndex + 1}筆 - 第 ${endIndex} 筆 , 共 ${length} 筆資料`;
  }

  test3() {
    this.data = [{ IsRowFocus: true, position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { IsRowFocus: false, position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { IsRowFocus: false, position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { IsRowFocus: false, position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { IsRowFocus: false, position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { IsRowFocus: false, position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { IsRowFocus: false, position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { IsRowFocus: false, position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { IsRowFocus: false, position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { IsRowFocus: false, position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: false, position: 11, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: true, position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { IsRowFocus: false, position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { IsRowFocus: false, position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { IsRowFocus: false, position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { IsRowFocus: false, position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { IsRowFocus: false, position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { IsRowFocus: false, position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { IsRowFocus: false, position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { IsRowFocus: false, position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { IsRowFocus: false, position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: false, position: 11, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: false, position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H' },
    { IsRowFocus: false, position: 2, name: 'Helium', weight: 4.0026, symbol: 'He' },
    { IsRowFocus: false, position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li' },
    { IsRowFocus: false, position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be' },
    { IsRowFocus: false, position: 5, name: 'Boron', weight: 10.811, symbol: 'B' },
    { IsRowFocus: false, position: 6, name: 'Carbon', weight: 12.0107, symbol: 'C' },
    { IsRowFocus: false, position: 7, name: 'Nitrogen', weight: 14.0067, symbol: 'N' },
    { IsRowFocus: false, position: 8, name: 'Oxygen', weight: 15.9994, symbol: 'O' },
    { IsRowFocus: false, position: 9, name: 'Fluorine', weight: 18.9984, symbol: 'F' },
    { IsRowFocus: false, position: 10, name: 'Neon', weight: 20.1797, symbol: 'Ne' },
    { IsRowFocus: false, position: 11, name: 'Neon', weight: 20.1797, symbol: 'Ne' },];

  }
  test4($event) {
    alert('get-selected' + JSON.stringify(this.ptcLocalTable.getSelectRows()))

  }

  test($event) {
    this.data = [{ IsRowFocus: true, position: 1, name: 'Anthony', weight: 1.0079, symbol: 'A' }];

  }

  test2($event) {
    this.data = [];

  }

  rowSelect($event) {
    console.log($event);
  }



}


export interface TestClass {
  IsRowFocus: boolean,
  name: string;
  position: number;
  weight: number;
  symbol: string;
}



