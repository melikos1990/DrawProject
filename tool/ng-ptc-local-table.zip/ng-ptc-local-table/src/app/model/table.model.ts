
export enum TableBtnOrderType {
    Search,
    Edit,
    Delete
}