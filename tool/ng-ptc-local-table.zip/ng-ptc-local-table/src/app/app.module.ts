import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { PtcLocalTableModule } from './core/ptc-local-table.module';
import { 
 MatChipsModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent,
  ],
  
  imports: [  
    MatChipsModule,
    BrowserModule,
    BrowserAnimationsModule,
    PtcLocalTableModule
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
