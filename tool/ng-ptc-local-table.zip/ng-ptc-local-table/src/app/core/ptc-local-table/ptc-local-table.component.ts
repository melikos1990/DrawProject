import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { MatSort, MatTableDataSource, MatPaginator, MatTable } from '@angular/material';
import { PtcBaseLocalTableComponent } from '../ptc-base-local-table/ptc-base-local-table.component';
import { SelectionModel } from '@angular/cdk/collections';
import { TableBtnOrderType } from '../../model/table.model';

@Component({
  selector: 'app-ptc-local-table',
  templateUrl: './ptc-local-table.component.html',
  styleUrls: ['./ptc-local-table.component.scss']
})
export class PtcLocalTableComponent extends PtcBaseLocalTableComponent implements OnInit {

  selection = new SelectionModel<any>(true, []);
  dataSource: MatTableDataSource<any> = null;

  @ViewChild(MatTable) table: MatTable<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;


  @Input() height: string;

  @Input() noDataLabel: string = '無資料'
  @Input() lastPageLabel: string;
  @Input() nextPageLabel: string;
  @Input() previousPageLabel: string;
  @Input() firstPageLabel: string;
  @Input() itemsPerPageLabel: string = '分頁筆數';
  @Input() templateRefs: any = {};
  @Input() setRangeLabel: (page: number, pageSize: number, length: number) => string;

  /**
   * 取得名稱定義
   */
  get columnDefList(): string[] {
    return this.columns.map(x => x.name);
  }


  /**
   * 取得總共頁數集合
   */
  get totalPageOptions(): number[] {

    let result = [];
    if (!this.paginator) return result;
    let total = (this.paginator.length / this.paginator.pageSize) + 1;
    for (let i = 1; i <= total; result.push(i), i++);

    return result;

  }

  constructor() {
    super();

  }

  /**
   * 設定控制字樣
   */
  private _setControlLabel() {
    this.paginator._intl.itemsPerPageLabel = this.itemsPerPageLabel;
    this.paginator._intl.lastPageLabel = this.lastPageLabel;
    this.paginator._intl.nextPageLabel = this.nextPageLabel;
    this.paginator._intl.previousPageLabel = this.previousPageLabel;
    this.paginator._intl.firstPageLabel = this.firstPageLabel;
  }

  /**
   * 設定顯示字樣
   * @param page 
   * @param pageSize 
   * @param length 
   */
  private _setRangeLabel(page: number, pageSize: number, length: number): string {
    if (length == 0 || pageSize == 0) {
      return `0 of ${length}`;
    }
    length = Math.max(length, 0);
    const startIndex = page * pageSize;
    const endIndex = startIndex < length ? Math.min(startIndex + pageSize, length) : startIndex + pageSize;
    return `${startIndex + 1} - ${endIndex} of ${length}`;
  }

  /**
   * 設定表頭Component
   */
  private _setSortHeader() {
    this.dataSource.sort = this.sort;
  }

  /**
   * 設定分頁字樣
   */
  private _setPagingator() {

    this._setControlLabel();
    this.paginator._intl.getRangeLabel =
      this.setRangeLabel || this._setRangeLabel;
    this.dataSource.paginator = this.paginator

  }

  /**
   * 設定資料來源
   */
  private _setTableSource() {
    this.dataSource = new MatTableDataSource(this.data);
  }

  /**
   * 設定當前頁數
   * ＊系統處理的是從0開始計算
   * @param value 
   */
  private _getSystemPageIndex(value): number {
    return value - 1
  }

  /**
   * 設定顯示頁數
   * ＊畫面顯示的是從1開始計算
   * @param value 
   */
  private _getUIPageIndex(value): number {
    return value + 1
  }

  /**
   * 取得第一欄之物件,顯示用
   */
  // private _getFirstCell(): any {

  //   return {
  //     name: this.cellFirst,
  //     text: this.cellFirst
  //   }

  // }

  /**
   * 檢核表頭名稱不得重複
   * @param name 
   */
  private _isExistHeader(name) {
    return this.columns.some(t => t.name == name);
  }

  /**
   * 與定義的第一欄做合併
   */
  // private _mergeWithFirstCell() {

  //   if (this.cellFirst != 'none') {

  //     let firstTerm = this._getFirstCell()
  //     let isExist = this._isExistHeader(this.cellFirst);

  //     if (isExist) return;

  //     this.columns = [firstTerm, ...this.columns];
  //   }
  // }



  /**
   * 檢查instance
   */
  private _isActiveElement() {
    return this.sort && this.paginator && this.table
  }

  private _build() {

    if (this._isActiveElement()) {

      this.clearSelectItems();
      this._setTableSource();
      this._setSortHeader();
      this._setPagingator();
    }
  }


  ngOnInit() {
    //this._mergeWithFirstCell();
    this._build();
  }


  /**
   * 選擇頁數
   * @param $event 
   */
  selectPage($event) {
    if ($event) {
      this.goToPage($event)
    }
  }

  /**
   * 進行換頁行為
   * @param pageIndex 
   */
  goToPage(pageIndex) {
    this.pageIndex = pageIndex;
    let currentPage = this._getSystemPageIndex(pageIndex);

    if (this._isActiveElement()) {
      this.paginator.pageIndex = currentPage;
      this.paginator.page.next({
        pageIndex: currentPage,
        pageSize: this.paginator.pageSize,
        length: this.paginator.length

      });
    }
  }

  /**
   * 當頁數改變時 , 回呼事件
   * @param $event 
   */
  pageChange($event) {
    this.pageIndex = this._getUIPageIndex($event.pageIndex);
    this.onPageChange.emit($event);
  }


  rowSelect($event) {
    this.onRowSelect.emit($event);
  }

  /**
   * 於 “p-operator” 時生效
   * 按下編輯按鈕回呼事件
   * @param $event 
   */
  btnEdit($event) {
    console.log($event);
    this.onBtnEdit.emit($event);
  }

  /**
  * 於 “p-operator” 時生效
  * 按下檢視按鈕回呼事件
  * @param $event 
  */
  btnSearch($event) {
    console.log($event);
    this.onBtnSearch.emit($event);
  }

  /**
   * 於 “p-operator” 時生效
   * 按下刪除按鈕回呼事件
   * @param $event 
   */
  btnDelete($event) {
    console.log($event);
    this.onBtnDelete.emit($event);
  }

  /**
   * 當轉入之資料源變化時 , 回呼事件
   * @param data 
   */
  dataChange(data: any[]) {
    this.goToPage(1);
    this._build();
  }

  /**
  * 於 “p-check 時生效
  * 檢核是否全選
  */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  /**
  * 於 “p-check 時生效
  * 勾選項目時加入物件控制
  */
  masterToggle() {
    this.isAllSelected() ?
      this.clearSelectItems() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }


  /**
  * 於 “p-check 時生效
  * 樣式變化
  */
  checkboxLabel(row?: any): string {
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.position + 1}`;
  }

  /**
   * 於 “p-check 時生效
   * 取得已選項目
   */
  getSelectRows(): any {
    return this.selection.selected;
  }
  /**
  * 於 “p-check 時生效
  * 清除勾選項目
  */
  clearSelectItems(): any {
    this.selection.clear();
  }

  /**
  * 設定按鈕位置
  * @param idx 
  */
  btnClassSetting(idx: any) {
    let classString: string;

    switch (idx) {
      case 0:
        classString = "btnLeft"
        break;
      case 1:
        classString = "btnCenter"
        break;
      case 2:
        classString = "btnRight"
        break;

      default:
        break;
    }
    return classString;
  }

  IsRowFocus(row) {
    if (!!row.IsRowFocus) {
      return "focusRow";
    }
    else {
      return "";
    }
  }

}





