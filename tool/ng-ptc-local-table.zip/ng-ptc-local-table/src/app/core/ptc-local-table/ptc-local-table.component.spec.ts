import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcLocalTableComponent } from './ptc-local-table.component';

describe('PtcLocalTableComponent', () => {
  let component: PtcLocalTableComponent;
  let fixture: ComponentFixture<PtcLocalTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcLocalTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcLocalTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
