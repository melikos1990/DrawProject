import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { PageEvent } from '@angular/material';
import { TableBtnOrderType } from '../../model/table.model';

@Component({
  selector: 'app-ptc-base-local-table',
  templateUrl: './ptc-base-local-table.component.html',
  styleUrls: ['./ptc-base-local-table.component.scss']
}) 
export class PtcBaseLocalTableComponent {

  public tableBtnOrderType = TableBtnOrderType;
  
  private _data: any[] = [];

  /**
   * 表格欄位定義
   */
  @Input() columns: any[] = [];

  /**
   * 資料來源定義
   */
  @Input()
  set data(data: any[]) {

    this._data = data;
    this.dataChange(this._data);
  }
  get data() {
    return this._data;
  }

  // /**
  //  * 第一欄之樣式
  //  */
  // @Input() cellFirst : 'p-check' | 'p-operator' | 'none' = 'none';

  /**
   * 目前頁數
   */
  @Input() pageIndex: number = 0;

  /**
   * 頁面長度
   */
  @Input() pageSize: number = 0;

  /**
   * 頁面長度可選清單
   */
  @Input() pageSizeOptions: number[] = [];

  /**
   * 頁面切換傳出事件
   */
  @Output() onPageChange: EventEmitter<any> = new EventEmitter();


  /**
   * 檢視按鈕傳出事件
   */
  @Output() onBtnSearch: EventEmitter<any> = new EventEmitter();

  /**
   * 是否顯示查詢按鈕
   */
  @Input() isVisibleBtnSearch: boolean = true;
 /**
   * 檢視按鈕字樣
   */
  @Input() btnSearchText : string = '檢視'
  /**
   * 刪除按鈕傳出事件
   */
  @Output() onBtnDelete: EventEmitter<any> = new EventEmitter();
  /**
   * 刪除按鈕字樣
   */
  @Input() btnDeleteText : string = '刪除'
  /**
    * 是否顯示刪除按鈕
    */
  @Input() isVisibleBtnDelete: boolean = true;

  /**
   * 編輯按鈕傳出事件
   */
  @Output() onBtnEdit: EventEmitter<any> = new EventEmitter();
   /**
   * 編輯按鈕字樣
   */
  @Input() btnEditText : string = '編輯'
  /**
    * 是否顯示編輯按鈕
    */
  @Input() isVisibleBtnEdit: boolean = true;

  /**
   * 是否顯示分頁區塊
   */
  @Input() isVisibleFooter : boolean = true;


  @Output() onRowSelect : EventEmitter<any> = new EventEmitter();

  /**
   * 按鈕排序
   */
  @Input() btnOrderSetting: TableBtnOrderType[] = [this.tableBtnOrderType.Search, this.tableBtnOrderType.Edit, this.tableBtnOrderType.Delete];

  
  constructor() { }

  dataChange(data: any[]) { }

  getSelectRows(): any[] {
    return null;
  }


}
