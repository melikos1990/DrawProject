import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcBaseLocalTableComponent } from './ptc-base-local-table.component';

describe('PtcBaseLocalTableComponent', () => {
  let component: PtcBaseLocalTableComponent;
  let fixture: ComponentFixture<PtcBaseLocalTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcBaseLocalTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcBaseLocalTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
