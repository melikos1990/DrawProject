import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CdkTableModule} from '@angular/cdk/table';
import { 
  MatButtonModule,
  MatCheckboxModule,
  MatIconModule,
  MatInputModule,
  MatPaginatorModule, 
  MatSelectModule, 
  MatSortModule, 
  MatTableModule,
} from '@angular/material';
import { PtcLocalTableComponent } from './ptc-local-table/ptc-local-table.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PtcBaseLocalTableComponent } from './ptc-base-local-table/ptc-base-local-table.component';


@NgModule({
  declarations: [
    PtcLocalTableComponent,
    PtcBaseLocalTableComponent
  ],
  exports:[
    PtcLocalTableComponent,
    PtcBaseLocalTableComponent
  ],
  imports: [
    MatCheckboxModule,
    MatSelectModule,
    MatSortModule,
    FormsModule,
    MatIconModule,
    CdkTableModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatInputModule,
    CommonModule
  ],

})
export class PtcLocalTableModule { }
