export * from "./app/core/ptc-local-table.module";
export * from "./app/model";
export * from "./app/core/ptc-local-table/ptc-local-table.component";
export * from "./app/core/ptc-base-local-table/ptc-base-local-table.component";