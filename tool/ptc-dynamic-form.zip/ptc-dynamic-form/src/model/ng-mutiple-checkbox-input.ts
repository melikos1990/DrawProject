import { NgInputBase } from './ng-input-base';

export class NgMutipleCheckboxInput extends NgInputBase {

    constructor(id , name , lable , validator) {
        super();
        this.id = id;
        this.name = name;
        this.lable = lable;
        this.validator = validator;
        this.component = 'NgMutipleCheckboxInputComponent'; 
    }

    options : any[] = [];

    singleCheck :  boolean  = true

}
