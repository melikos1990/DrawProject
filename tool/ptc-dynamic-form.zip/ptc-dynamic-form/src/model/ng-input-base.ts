export class NgInputBase {

    /**
     * set `id` attribute
     */
    id : string = '';

    /**
     * set `name` attribute 
     */
    name : string = '';

    /**
     * assign specific component for rendering
     */
    component : string = '';

    /**
     * set label's `ngClass` value
     */
    lableClass : any = '';

    /**
     * set input's `ngClass` value
     */
    inputClass : any = '';

    /**
     * set row's `ngClass` value
     */
    groupClass : any = '';

    /**
     * set lable text
     */
    lable : string = '';

     /**
     * set placeholder text
     */
    placeholder : string = '';

    /**
     * set conainer's css
     */
    containerClass : string = '';

    /**
     * input's validator
     */
    validator : {[key: string]: string | string[]};

}

