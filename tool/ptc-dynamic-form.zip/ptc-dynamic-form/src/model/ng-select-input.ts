import { NgInputBase } from './ng-input-base';

export class NgSelectInput extends NgInputBase {

    constructor(id , name , lable , validator) {
        super();
        this.id = id;
        this.name = name;
        this.lable = lable;
        this.validator = validator;
        this.component = 'NgSelectInputComponent'; 
    }

    options : any[] = [];
}
