import { NgInputBase } from './ng-input-base';

export class NgTextAreaInput extends NgInputBase {

    constructor(id , name , lable , validator) {
        super();
        this.id = id;
        this.name = name;
        this.lable = lable;
        this.validator = validator;
        this.component = 'NgTextAreaInputComponent'; 
    }

    cols : number = 3;

    rows : number = 3;

}
