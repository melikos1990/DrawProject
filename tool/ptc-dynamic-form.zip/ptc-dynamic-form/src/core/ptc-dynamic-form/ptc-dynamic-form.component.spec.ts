import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtcDynamicFormComponent } from './ptc-dynamic-form.component';

describe('PtcDynamicFormComponent', () => {
  let component: PtcDynamicFormComponent;
  let fixture: ComponentFixture<PtcDynamicFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtcDynamicFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtcDynamicFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
