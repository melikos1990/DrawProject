import { Component,Renderer2, OnInit, Input, ComponentFactoryResolver, ViewChild, Injector, InjectionToken, Inject } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { NgInputBase } from '../../model/ng-input-base';
import { NgInput, NgInputBaseComponent } from '../inputs/ng-input-base/ng-input-base.component';
import { NgFileInputComponent } from '../inputs/ng-file-input/ng-file-input.component';
import { NgGeneralInputComponent } from '../inputs/ng-general-input/ng-general-input.component';
import { NgSelectInputComponent } from '../inputs/ng-select-input/ng-select-input.component';
import { DynamicHostDirective } from '../components/dynamic-host.directive';
import { ComponentDef } from '@angular/core/src/render3';


export const DYNAMIC_INPUTS = new InjectionToken<{ key: string, component: any }[]>('DYNAMIC_INPUTS');


@Component({
  selector: 'ptc-dynamic-form',
  templateUrl: './ptc-dynamic-form.component.html',
  styleUrls: ['./ptc-dynamic-form.component.scss']
})
export class PtcDynamicFormComponent implements OnInit {

  @ViewChild(DynamicHostDirective) host: DynamicHostDirective;

  private _inputs: NgInputBase[] = [];

  @Input() bindingData: any = {}
  @Input() class : any;
  
  @Input() set inputs(inputs: NgInputBase[]){

    this._inputs = inputs;
    this.createComponents();
    
  }

  get inputs(): NgInputBase[] {
  
    return this._inputs;
  }

  @Input() form: FormGroup = new FormGroup({});

  componentRefArray : Array<NgInputBaseComponent> = [];
  componentTypeMapper: Map<string, NgInput> = new Map<string, NgInput>();

  constructor(private injector: Injector,
    private resolver: ComponentFactoryResolver,
    private render2 : Renderer2,
    @Inject(DYNAMIC_INPUTS) private dynamicInputs: { key: string, component: NgInput }[]) {

    this.setComponentTypeMapper();
  }

  ngOnInit() {
    this.createComponents();
  }

  createComponents() {

    const container = this.host.container;
    container.clear();

    this.inputs.forEach(x => {
 
      let componentType = this.componentTypeMapper.get(x.component);
      let component = this.resolver.resolveComponentFactory(componentType);
      let componentRef = container.createComponent(component, null, this.injector)
      let instance = componentRef.instance;

      instance.form = this.form;
      instance.bindingData = this.bindingData;
      instance.input = x;

      if(x.containerClass){
        this.render2.addClass(componentRef.location.nativeElement, x.containerClass);
      }
      this.componentRefArray.push(instance);
    });
  }

  setComponentTypeMapper() {
    this.dynamicInputs.forEach(pair => {
      this.componentTypeMapper.set(pair.key, pair.component)
    })
  }

 
}

