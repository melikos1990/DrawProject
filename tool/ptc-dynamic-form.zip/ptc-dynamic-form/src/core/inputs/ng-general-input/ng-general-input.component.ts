import { Component, OnInit, Input, Injector } from '@angular/core';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';
import { NgGeneralInput } from '../../../model/ng-general-input';

@Component({
  selector: 'app-ng-general-input',
  templateUrl: './ng-general-input.component.html',
  styleUrls: ['./ng-general-input.component.scss']
})
export class NgGeneralInputComponent extends NgInputBaseComponent implements OnInit {

  @Input() input: NgGeneralInput;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.setFromControl();
   
  }

}
