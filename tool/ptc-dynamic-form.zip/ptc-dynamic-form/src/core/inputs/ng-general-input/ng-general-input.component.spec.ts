import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgGeneralInputComponent } from './ng-general-input.component';

describe('NgGeneralInputComponent', () => {
  let component: NgGeneralInputComponent;
  let fixture: ComponentFixture<NgGeneralInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgGeneralInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgGeneralInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
