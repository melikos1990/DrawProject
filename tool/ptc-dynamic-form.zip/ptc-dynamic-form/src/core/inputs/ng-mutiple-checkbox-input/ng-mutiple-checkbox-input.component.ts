import { Component, OnInit, Input, Injector } from '@angular/core';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';
import { NgMutipleCheckboxInput } from '../../../model/ng-mutiple-checkbox-input';

@Component({
  selector: 'app-ng-mutiple-checkbox-input',
  templateUrl: './ng-mutiple-checkbox-input.component.html',
  styleUrls: ['./ng-mutiple-checkbox-input.component.scss']
})
export class NgMutipleCheckboxInputComponent extends NgInputBaseComponent implements OnInit {

  @Input() input: NgMutipleCheckboxInput;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.setFromControl();

  }
  parserArray() {
    if (Array.isArray(this.input.options)) {
      return this.input.options;
    }
    return JSON.parse(this.input.options);
  }

  onClick($event) {

    if (this.input.singleCheck) {
      let docs =  document.getElementsByName(this.input.name);
      console.log(docs);
      // docs.forEach(x=>{
      //   x.
      // })
    }

  }
}
