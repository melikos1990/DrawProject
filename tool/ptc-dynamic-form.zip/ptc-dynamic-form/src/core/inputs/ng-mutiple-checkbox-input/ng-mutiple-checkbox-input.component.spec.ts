import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgMutipleCheckboxInputComponent } from './ng-mutiple-checkbox-input.component';

describe('NgMutipleCheckboxInputComponent', () => {
  let component: NgMutipleCheckboxInputComponent;
  let fixture: ComponentFixture<NgMutipleCheckboxInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgMutipleCheckboxInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgMutipleCheckboxInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
