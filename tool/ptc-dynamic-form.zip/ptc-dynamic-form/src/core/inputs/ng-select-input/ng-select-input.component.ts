import { Component, OnInit, Injector, Input } from '@angular/core';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';
import { NgSelectInput } from '../../../model/ng-select-input';

@Component({
  selector: 'app-ng-select-input',
  templateUrl: './ng-select-input.component.html',
  styleUrls: ['./ng-select-input.component.scss']
})
export class NgSelectInputComponent extends NgInputBaseComponent implements OnInit {

  
  @Input() input: NgSelectInput;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.setFromControl();
  }

  parserArray(){
    if(Array.isArray(this.input.options)){
      return this.input.options;
    }
    return JSON.parse(this.input.options);
  }

}
