import { Component, OnInit, Input, Injector } from '@angular/core';
import { NgFileInput } from '../../../model/ng-file-input';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';


@Component({
  selector: 'app-ng-file-input',
  templateUrl: './ng-file-input.component.html',
  styleUrls: ['./ng-file-input.component.scss']
})
export class NgFileInputComponent extends NgInputBaseComponent implements OnInit  {
  

  @Input() input: NgFileInput;

  constructor(injector: Injector) {
    super(injector);
   

  }

  ngOnInit() {
   
    this.setFromControl();
  }




}
