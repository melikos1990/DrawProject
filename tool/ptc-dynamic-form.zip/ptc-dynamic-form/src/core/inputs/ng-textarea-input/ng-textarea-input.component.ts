import { Component, OnInit, Input, Injector } from '@angular/core';
import { NgSignleCheckboxInput } from '../../../model/ng-single-checkbox-input';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';
import { NgTextAreaInput } from 'src/model/ng-textarea-input';

@Component({
  selector: 'app-ng-textarea-input',
  templateUrl: './ng-textarea-input.component.html',
  styleUrls: ['./ng-textarea-input.component.scss']
})
export class NgTextAreaInputComponent extends NgInputBaseComponent  implements OnInit {

  @Input() input: NgTextAreaInput;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.setFromControl();
   
  }

}
