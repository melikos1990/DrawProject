import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgTextareaInputComponent } from './ng-textarea-input.component';

describe('NgTextareaInputComponent', () => {
  let component: NgTextareaInputComponent;
  let fixture: ComponentFixture<NgTextareaInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgTextareaInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgTextareaInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
