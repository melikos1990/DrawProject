import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgSingleCheckboxInputComponent } from './ng-single-checkbox-input.component';

describe('NgSingleCheckboxInputComponent', () => {
  let component: NgSingleCheckboxInputComponent;
  let fixture: ComponentFixture<NgSingleCheckboxInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgSingleCheckboxInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgSingleCheckboxInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
