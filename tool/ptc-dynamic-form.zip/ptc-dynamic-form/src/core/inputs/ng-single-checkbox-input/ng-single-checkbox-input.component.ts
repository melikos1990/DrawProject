import { Component, OnInit, Input, Injector } from '@angular/core';
import { NgSignleCheckboxInput } from '../../../model/ng-single-checkbox-input';
import { NgInputBaseComponent } from '../ng-input-base/ng-input-base.component';

@Component({
  selector: 'app-ng-single-checkbox-input',
  templateUrl: './ng-single-checkbox-input.component.html',
  styleUrls: ['./ng-single-checkbox-input.component.scss']
})
export class NgSingleCheckboxInputComponent extends NgInputBaseComponent  implements OnInit {

  @Input() input: NgSignleCheckboxInput;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {
    this.setFromControl();
   
  }
}
