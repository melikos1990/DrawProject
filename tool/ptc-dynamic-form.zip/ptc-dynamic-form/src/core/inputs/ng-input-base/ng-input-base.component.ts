import { Component, Input, Injector } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ValidatorService } from '../../../service/validator.service';


export type NgInput = { new(): NgInputBaseComponent }

@Component({
  selector: 'app-ng-input-base',
  templateUrl: './ng-input-base.component.html',
})
export class NgInputBaseComponent {

  validator: ValidatorService
  
  @Input() input : any;
  @Input() bindingData: any;
  @Input() form: FormGroup;

  constructor(injector: Injector) {
    this.validator = injector.get(ValidatorService);
  }

  setFromControl() {
    this.validator.injectValidator(this.input, this.form , this.bindingData)
  }
}


