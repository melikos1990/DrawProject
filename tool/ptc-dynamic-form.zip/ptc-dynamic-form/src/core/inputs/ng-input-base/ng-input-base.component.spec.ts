import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgInputBaseComponent } from './ng-input-base.component';

describe('NgInputBaseComponent', () => {
  let component: NgInputBaseComponent;
  let fixture: ComponentFixture<NgInputBaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgInputBaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgInputBaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
