import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PtcDynamicFormComponent } from './ptc-dynamic-form/ptc-dynamic-form.component';
import { NgFileInputComponent } from './inputs/ng-file-input/ng-file-input.component';
import { NgGeneralInputComponent } from './inputs/ng-general-input/ng-general-input.component';
import { NgSelectInputComponent } from './inputs/ng-select-input/ng-select-input.component';
import { NgInputBaseComponent } from './inputs/ng-input-base/ng-input-base.component';
import { DynamicHostDirective } from './components/dynamic-host.directive';
import { ValidatorService } from '../service/validator.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgTextAreaInputComponent } from './inputs/ng-textarea-input/ng-textarea-input.component';
import { NgSingleCheckboxInputComponent } from './inputs/ng-single-checkbox-input/ng-single-checkbox-input.component';
import { NgMutipleCheckboxInputComponent } from './inputs/ng-mutiple-checkbox-input/ng-mutiple-checkbox-input.component';

@NgModule({
  declarations: [
    PtcDynamicFormComponent, 
    NgFileInputComponent,
    NgGeneralInputComponent,
    NgSelectInputComponent, 
    NgInputBaseComponent, 
    DynamicHostDirective, 
    NgTextAreaInputComponent, 
    NgSingleCheckboxInputComponent, 
    NgMutipleCheckboxInputComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers : [
    ValidatorService
  ],
  entryComponents:[
    NgFileInputComponent,
    NgGeneralInputComponent,
    NgSelectInputComponent, 
    NgInputBaseComponent, 
    NgTextAreaInputComponent, 
    NgSingleCheckboxInputComponent,
    NgMutipleCheckboxInputComponent
  ],
  exports :[ 
    PtcDynamicFormComponent, 
    NgFileInputComponent,
    NgGeneralInputComponent,
    NgSelectInputComponent,  
    NgInputBaseComponent, 
    DynamicHostDirective,
    
  ]
})
export class PtcDynamicFormModule { }
