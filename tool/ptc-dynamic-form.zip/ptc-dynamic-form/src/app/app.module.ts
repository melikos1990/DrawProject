import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PtcDynamicFormModule } from 'src/core/ptc-dynamic-form.module';
import { DYNAMIC_INPUTS } from 'src/core/ptc-dynamic-form/ptc-dynamic-form.component';
import { NgFileInputComponent } from 'src/core/inputs/ng-file-input/ng-file-input.component';
import { NgGeneralInputComponent } from 'src/core/inputs/ng-general-input/ng-general-input.component';
import { NgSelectInputComponent } from 'src/core/inputs/ng-select-input/ng-select-input.component';
import { NgCheckboxInputComponent } from './customer/ng-checkbox-input/ng-checkbox-input.component';
import { CustomerValidatorService } from './service/validator.service';
import { ValidatorService } from '../service/validator.service';
import { NgSingleCheckboxInputComponent } from 'src/core/inputs/ng-single-checkbox-input/ng-single-checkbox-input.component';
import { NgTextAreaInputComponent } from 'src/core/inputs/ng-textarea-input/ng-textarea-input.component';
import { NgMutipleCheckboxInputComponent } from 'src/core/inputs/ng-mutiple-checkbox-input/ng-mutiple-checkbox-input.component';


@NgModule({
  declarations: [
    AppComponent,
    NgCheckboxInputComponent
    
  ],
  imports: [
    BrowserModule,
    PtcDynamicFormModule,
  ],
  entryComponents:[
    NgCheckboxInputComponent
  ],
  providers: [
    { provide: ValidatorService, useClass : CustomerValidatorService},
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgFileInputComponent' , component : NgFileInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgGeneralInputComponent' , component : NgGeneralInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgSelectInputComponent' , component : NgSelectInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgCheckboxInputComponent' , component : NgCheckboxInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgSingleCheckboxInputComponent' , component : NgSingleCheckboxInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgTextAreaInputComponent' , component : NgTextAreaInputComponent} , multi: true },
    { provide: DYNAMIC_INPUTS, useValue: {key : 'NgMutipleCheckboxInputComponent' , component : NgMutipleCheckboxInputComponent} , multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
