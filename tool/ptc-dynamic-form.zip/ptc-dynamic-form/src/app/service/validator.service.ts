import { Injectable } from '@angular/core';
import { NgInputBase } from 'src/model/ng-input-base';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Injectable()
export class CustomerValidatorService {

  constructor() { }

  injectValidator(input: NgInputBase, form: FormGroup, data: any) {

    // new formcontrol
    form.controls[input.id] = new FormControl(data[input.id]);

    // set validator
    let validator = input.validator;

    if (!validator) return;

    let validatorList: any[] = [];

    Object.keys(validator).forEach(key => {
      let val = <any>validator[key];
      switch (key) {
        case 'required':
          validatorList.push(Validators.required);
          break;
        case 'min':
          validatorList.push(Validators.min(val));
          break;
        case 'max':
          validatorList.push(Validators.max(val));
          break;
        case 'minLength':
          validatorList.push(Validators.minLength(val));
          break;
        case 'maxLength':
          validatorList.push(Validators.maxLength(val));
          break;
        case 'email':
          validatorList.push(Validators.email);
          break;
        case 'pattern':
          validatorList.push(Validators.pattern(val));
          break
      }
    });

    console.log('hahaha')
    form.controls[input.id].setValidators(validatorList);
    form.updateValueAndValidity();
  }
}
