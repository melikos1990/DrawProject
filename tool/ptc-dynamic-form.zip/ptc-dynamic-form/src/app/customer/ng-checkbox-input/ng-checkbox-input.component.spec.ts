import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgCheckboxInputComponent } from './ng-checkbox-input.component';

describe('NgCheckboxInputComponent', () => {
  let component: NgCheckboxInputComponent;
  let fixture: ComponentFixture<NgCheckboxInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgCheckboxInputComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgCheckboxInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
