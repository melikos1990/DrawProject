import { Component, OnInit, Injector, Input } from '@angular/core';
import { NgInputBaseComponent } from 'src/core/inputs/ng-input-base/ng-input-base.component';
import { NgCheckboxInput } from './ng-checkbox-input';

@Component({
  selector: 'app-ng-checkbox-input',
  templateUrl: './ng-checkbox-input.component.html',
  styleUrls: ['./ng-checkbox-input.component.scss']
})
export class NgCheckboxInputComponent extends NgInputBaseComponent implements OnInit {


  @Input() input: NgCheckboxInput ;

  constructor(injector: Injector) {
    super(injector);
  }

  ngOnInit() {

    console.log(this.input)

  }

}
