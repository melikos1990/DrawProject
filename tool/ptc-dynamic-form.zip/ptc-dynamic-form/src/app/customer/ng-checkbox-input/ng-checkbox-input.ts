import { NgInputBase } from 'src/model/ng-input-base';

export class NgCheckboxInput extends NgInputBase {


    constructor(id , name , lable , validator){
        super();
        this.id = id;
        this.name = name;
        this.lable = lable;
        this.validator = validator;
        this.component = 'NgCheckboxInputComponent';
    }

    options : string[];

}
