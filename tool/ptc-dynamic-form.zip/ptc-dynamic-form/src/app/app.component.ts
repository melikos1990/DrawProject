import { Component, OnInit } from '@angular/core';
import { NgInputBase } from 'src/model/ng-input-base';
import { FormGroup } from '@angular/forms';
import { NgFileInput } from 'src/model/ng-file-input';
import { NgGeneralInput } from 'src/model/ng-general-input';
import { NgSelectInput } from 'src/model/ng-select-input';
import { NgSingleCheckboxInputComponent } from 'src/core/inputs/ng-single-checkbox-input/ng-single-checkbox-input.component';
import { NgSignleCheckboxInput } from 'src/model/ng-single-checkbox-input';
import { NgTextAreaInput } from 'src/model/ng-textarea-input';
import { NgMutipleCheckboxInput } from 'src/model/ng-mutiple-checkbox-input';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {


  public inputs: NgInputBase[] = [];
  public form: FormGroup = new FormGroup({});
  public data: Member = new Member();

  constructor() {

    
  }


  jsonRule() {

    let json = `[
      {
        "id" : "files" , 
        "name" : "files",
        "lable" : "檔案上傳",
        "component" : "NgFileInputComponent",
        "mutiple" :  false,
        "validator" : 
          {
           "required" : true
          }
       },
       {
        "id" : "password" , 
        "name" : "password",
        "lable" : "密碼",
        "type" : "password" ,
        "component" : "NgGeneralInputComponent",
        "validator" : 
          {
           "minLength" : 2,
           "maxLength" : 10,
           "required" : true
          }
       },
       {
        "id" : "name" , 
        "name" : "name",
        "lable" : "姓名",
        "type" : "text" ,
        "component" : "NgGeneralInputComponent",
        "validator" : 
          {
           "minLength" : 10,
           "maxLength" : 20,
           "required" : true
          }
       },
      {
        "id" : "age" , 
        "name" : "hobby",
        "lable" : "歲數",
        "type" : "number" ,
        "component" : "NgGeneralInputComponent",
        "validator" : 
          {
           "min" : 2,
           "max" : 20,
           "required" : true
          }
       },
       {
        "id" : "hobby" , 
        "name" : "hobby",
        "lable" : "嗜好",
        "component" : "NgCheckboxInputComponent",
        "options" : ["1" , "2" , "3"],
        "validator" : 
          {
           "required" : true
          }
       }
      ]`

     let objects = <Array<NgInputBase>>JSON.parse(json)
     this.inputs = [...objects];
  }
  objectRule() {

    var fileInput = new NgFileInput('files', 'files', '上傳', {
      required: true,
    })

    fileInput.mutiple = true
    var genInput = new NgGeneralInput('account', 'account', '帳號', {
      maxLength: 30,
      minLength: 20,
      required: true,
    })

    var genInput1 = new NgGeneralInput('name', 'name', '姓名', {
      maxLength: 30,
      minLength: 20,
      required: true,
    })
    var genInput2 = new NgGeneralInput('password', 'password', '密碼', {
      maxLength: 30,
      minLength: 20,
      required: true,
    })

    var genInput3 = new NgSelectInput('hobby' , 'hobby' , '嗜好' ,{
      required: true,
    })
    var genInput4 = new NgSignleCheckboxInput('isEnable' , 'isEnable' , '啟用' ,{
      required: true,
    })
    var genInput5 = new NgTextAreaInput('remark' , 'remark' , '備註' ,{
      required: true,
    })
    var genInput6 = new NgMutipleCheckboxInput('color' , 'color' , '顏色' ,{
      required: true,
    })

    genInput5.rows = 3;
    genInput5.cols = 20;

    genInput3.options = [

      {text : '打球' , value : '1'},
      {text : '游泳' , value : '2'},
     
    ]

    genInput6.options = [
      {text : '黑色' , value : 'black'},
      {text : '白色' , value : 'white'},
      {text : '紅色' , value : 'red'},
      {text : '藍色' , value : 'blue'},
    ]

    genInput2.type = 'password';
    genInput.type = 'text';

    this.inputs.push(fileInput)
    this.inputs.push(genInput)
    this.inputs.push(genInput1)
    this.inputs.push(genInput2)
    this.inputs.push(genInput3)
    this.inputs.push(genInput4)
    this.inputs.push(genInput5)
    this.inputs.push(genInput6) 
  }
  ngOnInit(): void {

    //this.jsonRule();
    this.objectRule()
    this.data.isEnable = true;
    this.data.color = ['black','red'];
    // this.inputs.push(new NgGeneralInput())
    // this.inputs.push(new NgSelect2Input())
    // this.inputs.push(new NgSelectInput())
  }

  print(){
    console.log(this.data);
  }

}

export class Member {

  name: string;

  account: string;

  password: string;

  country: string;

  sex : boolean;

  age : number

  files: File[];

  hobby : number;

  isEnable: true;
  
  color : string[];
}